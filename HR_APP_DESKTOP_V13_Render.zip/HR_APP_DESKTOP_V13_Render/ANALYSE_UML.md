# Analyse rapide des diagrammes UML

## Cas d'utilisation

Le diagramme de cas d'utilisation montre trois acteurs métier : Employé, Manager et Responsable RH. Le libellé « Système » a été interprété comme un ensemble de traitements internes et non comme un acteur humain.

Les modules fonctionnels identifiés sont :

- Administration : informations personnelles, utilisateurs, rôles et accès.
- Congés & absences : consultation du solde, soumission, modification, consultation et traitement.
- Notes de frais : soumission, modification, consultation, traitement et changement de statut.
- Documents : demande, suivi, traitement, upload et récupération.
- Matériel & outils : demande, affectation et suivi.
- Tableaux de bord : consultation et filtrage.
- Historique : consultation des actions et changements de statut.

## Diagramme de classes

Le modèle a été traduit en tables SQLite et services Python autour des entités : Employe, Utilisateur, Role, Permission, Departement, Poste, Contrat, Demande, DemandeConge, DemandeDocument, DemandeMateriel, NoteDeFrais, Justificatif, Materiel, AffectationMateriel, Maintenance, SoldeConge et HistoriqueDemande.

La classe logique `Demande` est représentée par une table mère `demande` avec des tables spécialisées pour congés, documents et matériel. Cette structure permet de gérer les statuts, l'historique et les informations communes de façon cohérente.

## Diagrammes d'état

Les états suivants ont été intégrés :

- Congé : brouillon, soumise, en traitement, approuvée, refusée, annulée.
- Note de frais : brouillon, soumise, en vérification, validée, rejetée, remboursée.
- Document RH : créée, soumise, traitée, prête, rejetée, récupérée.
- Demande matériel : créée, soumise, en traitement, acceptée, refusée, affectée, annulée.
- Matériel : disponible, affecté, retourné, en maintenance.

## Séquences principales

Les scénarios de séquence ont été traduits en écrans et actions :

- Authentification puis redirection selon le rôle.
- Soumission d'une demande par l'employé.
- Consultation et traitement par le Manager ou RH.
- Changement de statut et inscription automatique dans l'historique.
- Affectation de matériel disponible à une demande validée.
- Upload d'un document RH local quand le document est prêt.

## Hypothèses de conception

- Application desktop locale, sans serveur, avec base SQLite.
- Interface en français, simple et moderne.
- Les droits sont appliqués dans l'interface selon le rôle connecté.
- Les documents ne sont pas générés automatiquement ; ils sont uploadés ou marqués comme prêts.
- Le retour matériel peut rester vide jusqu'à la restitution effective.
