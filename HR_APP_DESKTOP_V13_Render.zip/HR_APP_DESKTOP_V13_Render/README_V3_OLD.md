# SIRH H&Y Way — Application desktop RH & Matériel (V3)

Application de bureau Windows développée en Python, CustomTkinter et SQLite. Elle n'est pas une WebApp : elle fonctionne localement sans serveur distant.

## 1. Fonctionnalités incluses

- Authentification par email/mot de passe avec rôles : Employé, Manager, Responsable RH.
- Gestion des employés, postes, départements, contrats et utilisateurs.
- Gestion des congés : soumission, justificatif de congé, traitement, approbation, refus, annulation, calcul automatique des jours ouvrés et mise à jour du solde.
- Types de congés adaptés au contexte marocain : congé annuel, permission d’absence, congés maladie, accident du travail, maternité et congé sans solde.
- Gestion des notes de frais avec workflow corrigé :
  - Employé : soumet une note de frais.
  - Manager : peut soumettre ses propres notes et faire une validation préalable des notes de son équipe.
  - Responsable RH : réalise la validation finale puis marque la note comme remboursée.
- Gestion des documents RH : copie contrat de travail, bulletins de paie, attestation de travail, attestation de salaire et relevé CNSS.
- Upload limité aux bulletins de paie ; les autres documents sont marqués comme prêts puis récupérés physiquement.
- Gestion du matériel avec workflow corrigé :
  - Employé : pas d’accès au module matériel.
  - Manager : peut uniquement envoyer une demande d’attribution matériel au RH pour un employé de son équipe.
  - Responsable RH : traite la demande, accepte/refuse, affecte le matériel disponible, gère le retour et la maintenance.
- Tableau de bord selon rôle, avec pour l’employé la liste des 5 dernières demandes.
- Historique des changements de statut et actions importantes.
- Interface en cartes sélectionnables au lieu de tableaux lourds, avec exports CSV des listes.

## 2. Comptes de démonstration

Mot de passe commun : `123456`

| Rôle | Email |
|---|---|
| Employé | `employe@test.com` |
| Manager | `manager@test.com` |
| Responsable RH | `rh@test.com` |

## 3. Installation sur Windows

Dans le dossier du projet :

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

Ou double-cliquer sur `run_windows.bat` si Python est déjà installé.

## 4. Générer le fichier `.exe`

Dans le dossier du projet :

```bat
.venv\Scripts\activate
pyinstaller --noconfirm --onefile --windowed --name SIRH_HY_Way main.py
```

L'exécutable sera créé dans :

```text
dist\SIRH_HY_Way.exe
```

Un script `build_exe.bat` est fourni pour automatiser la génération.

## 5. Base de données et fichiers locaux

Au premier lancement, l'application crée automatiquement :

```text
data/sirh_hy_way.sqlite3
storage/justificatifs
storage/justificatifs_conges
storage/documents_rh
storage/contrats
exports
```

Les documents uploadés et justificatifs restent stockés localement.

## 6. Architecture

```text
HR_APP_DESKTOP_V3/
├─ main.py
├─ requirements.txt
├─ build_exe.bat
├─ run_windows.bat
├─ README.md
├─ ANALYSE_UML.md
├─ hr_app/
│  ├─ __init__.py
│  ├─ config.py
│  ├─ constants.py
│  ├─ db.py
│  ├─ security.py
│  ├─ services.py
│  ├─ ui.py
│  └─ utils.py
├─ data/
├─ storage/
│  ├─ justificatifs/
│  ├─ justificatifs_conges/
│  ├─ documents_rh/
│  └─ contrats/
└─ exports/
```

## 7. Hypothèses retenues

- Les jours de congé sont calculés en jours ouvrés du lundi au vendredi.
- Le Manager a les actions principales d’un employé : demande de congé, note de frais, demande de document RH.
- Un Manager ne valide pas ses propres notes de frais et ne traite pas ses propres congés ; ces éléments doivent passer par le RH.
- La note de frais suit le circuit : `soumise` → `en vérification` → `prévalidée manager` → `validée RH` → `remboursée`.
- Le matériel suit le circuit : demande d’attribution par le manager → traitement RH → acceptation/refus RH → affectation par le RH.
- Les documents RH ne sont pas générés automatiquement. Le RH peut uploader uniquement les bulletins de paie ; pour les autres documents, il marque la demande comme prête et l’employé passe récupérer le document physiquement.
- Le compte Employé ne voit plus le module Historique ni le module Matériel.
- La date de retour du matériel est facultative et renseignée seulement lors du retour effectif.
- Les mots de passe sont hashés avec PBKDF2-SHA256 et un sel aléatoire.

## 8. Pour réinitialiser la démo

Fermer l'application puis supprimer :

```text
data/sirh_hy_way.sqlite3
```

Au prochain lancement, les tables et les données de démonstration seront recréées.
