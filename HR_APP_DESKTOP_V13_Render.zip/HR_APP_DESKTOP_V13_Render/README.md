# SIRH H&Y Way — Application Desktop Windows V10

Application de bureau locale pour la gestion RH et la gestion du matériel interne.

## Nouveautés V10 — Correction du bon d’attribution matériel

Cette version corrige uniquement le **bon d’attribution matériel signé par l’employé**.

Lorsqu’un Responsable RH affecte un matériel à un employé, l’application génère automatiquement un PDF dans :

```text
storage/bons_attribution/
```

Le bon contient :

- logo H&Y Way ;
- nom de l’employé et matricule ;
- nom du matériel attribué ;
- numéro d’inventaire ;
- date d’attribution ;
- zone de signature employé ;
- pied de page professionnel inspiré du modèle fourni ;
- slogan : `The only way to succeed` ;
- informations juridiques de H&Y Way en pied de page, avec `SARL` comme forme juridique ;
- contact : `contact@hy-way.org` ;
- téléphone : `+212 6 66 88 79 56`.

Ces champs restent stockés dans l’application pour le suivi interne, mais ne figurent pas sur le bon PDF imprimable :

```text
confirmation_reception
date_confirmation
bon_pdf_path
bon_signe_path
```


Le bon PDF ne contient plus les champs techniques `confirmation_reception`, `date_confirmation`, `bon_pdf_path` et `bon_signe_path`. Ils restent uniquement disponibles dans l’application pour suivre chaque attribution.

Dans le module **Matériel**, le RH peut :

- ouvrir le bon PDF généré ;
- confirmer la réception du matériel ;
- joindre le bon signé scanné.

## Nouveautés V8

Cette version ajoute aussi la nouvelle règle de gestion des congés :

- Employé : acquisition automatique de **1,5 jour par mois**.
- Manager et Responsable RH : **27 jours accordés chaque année au 01/01**.
- Possibilité de demander une **demi-journée** de congé, comptabilisée comme `0,5 jour`.
- Les soldes sont recalculés automatiquement au démarrage et après chaque validation de congé.

## Import employés V6

Cette version ajoute l'import d'une liste d'employés depuis :

- un fichier Excel `.xlsx` ou `.xlsm` ;
- un fichier CSV `.csv` ;
- une base SQLite externe `.db`, `.sqlite`, `.sqlite3` ou `.bdd`.

L'import se fait depuis le compte **Responsable RH** :

```text
Employés > Importer Excel/BDD
```

Les employés existants sont mis à jour si le matricule ou l'email existe déjà. Les nouveaux employés sont créés automatiquement avec un solde de congé par défaut.

Colonnes recommandées pour Excel/CSV :

```text
matricule;nom;prenom;email;telephone;adresse;departement;poste;date_embauche;statut;manager_matricule;manager_email
```

Un bouton **Modèle import** permet de générer un modèle CSV prêt à remplir dans le dossier `exports/`.

## Comptes de démonstration

Mot de passe pour tous les comptes : `123456`

| Rôle | Email |
|---|---|
| Employé | `employe@test.com` |
| Manager | `manager@test.com` |
| Responsable RH | `rh@test.com` |

## Fonctionnalités principales

- Connexion avec rôles : Employé, Manager, Responsable RH
- Tableau de bord adapté au rôle connecté
- Gestion des employés
- Import employés depuis Excel, CSV ou base SQLite externe
- Gestion des utilisateurs et rôles
- Demandes de congés avec types adaptés au contexte marocain
- Ajout d'un justificatif pour les congés
- Calcul automatique du solde congés : 1,5 jour/mois pour les employés, 27 jours/an au 01/01 pour Managers et RH
- Demande possible en demi-journée
- Notes de frais avec validation préalable par le Manager puis validation finale par RH
- Demandes de documents RH
- Upload uniquement pour les bulletins de paie
- Documents physiques marqués comme prêts puis récupérés
- Demandes d'attribution matériel par le Manager
- Attribution effective du matériel uniquement par RH
- Génération automatique du bon d’attribution matériel PDF
- Confirmation de réception et rattachement optionnel du bon signé scanné
- Historique des actions et changements de statut
- Exports CSV

## Installation Windows

Ouvrir un terminal dans le dossier du projet :

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Si l'ancien message de connexion apparaît encore

Si tu as gardé une ancienne base locale dans le même dossier, tu peux supprimer ce fichier puis relancer :

```text
data\sirh_hy_way.sqlite3
```

L'application va recréer automatiquement une base propre avec les comptes de démonstration.

## Création du fichier .exe Windows

Lancer :

```bat
build_exe.bat
```

Le fichier `.exe` sera généré dans le dossier `dist`.

## Structure du projet

```text
HR_APP_DESKTOP_V9/
│
├── main.py
├── requirements.txt
├── build_exe.bat
├── run_windows.bat
├── README.md
├── ANALYSE_UML.md
│
├── hr_app/
│   ├── config.py
│   ├── constants.py
│   ├── db.py
│   ├── security.py
│   ├── services.py
│   ├── ui.py
│   ├── utils.py
│   └── assets/
│       └── hy_way_logo.png
│
├── data/
├── storage/
└── exports/
```

## Notes techniques

- Application desktop, pas WebApp
- Interface : CustomTkinter
- Base de données : SQLite locale
- Mot de passe : hash PBKDF2
- Import Excel : openpyxl
- Packaging : PyInstaller
- Données locales dans `data/`, `storage/` et `exports/`


## Correction V7 - Notes de frais

- Le justificatif est maintenant obligatoire pour toute nouvelle note de frais.
- Si l'utilisateur annule le choix du fichier, la note n'est pas créée.
- La liste des notes affiche maintenant si un justificatif est présent.

## Correction V8 - Congés

- Les employés acquièrent automatiquement 1,5 jour de congé par mois.
- Les Managers et Responsables RH disposent de 27 jours par année, disponibles au 01/01.
- Les demandes de congé peuvent maintenant porter sur une demi-journée.
- Les soldes affichent les jours acquis, pris et restants.
- La déduction du solde accepte les valeurs décimales, par exemple `0,5 jour`.


## Nouveautés V11 - Congés, alertes et import

Cette version ajoute uniquement les évolutions demandées sur la V10 :

- bouton **Paramètres congés** dans la vue Congés pour le Responsable RH ;
- paramétrage des règles de congés : jours/mois employés, jours annuels manager/RH, quota hebdomadaire par défaut ;
- gestion des quotas de congés par semaine et par département pour les employés uniquement ;
- possibilité pour le RH de dépasser un quota uniquement avec un motif obligatoire ;
- blocage des conflits de congés : solde insuffisant et chevauchement avec un congé déjà approuvé ;
- centre d’alertes interne avec bouton cloche **🔔 Alertes** indiquant les nouveaux messages ;
- prévisualisation avant import Excel/CSV/BDD des employés ;
- recherche et filtres avancés en mode hybride cartes + listes sur les vues principales ;
- tableau de bord enrichi avec indicateurs RH, manager et employé.

### Logique métier ajoutée

- Un employé ne peut pas soumettre une demande de congé si son solde est insuffisant.
- Une demande est bloquée si elle chevauche déjà un congé approuvé pour le même employé.
- Le quota hebdomadaire concerne les employés uniquement.
- Le manager ne peut pas dépasser le quota.
- Le Responsable RH peut dépasser le quota, mais doit saisir un motif ; l’action est enregistrée dans l’historique.
- Les alertes restent internes à l’application : pas d’email externe, conformément à la logique décidée.

## V12 - Interface inspirée OrangeHRM

Cette version conserve la logique métier de la V11 et améliore uniquement la présentation visuelle :

- palette orange/blanc inspirée des exemples OrangeHRM fournis ;
- barre latérale plus propre avec icônes textuelles ;
- barre supérieure orange avec cloche d'alertes et identité utilisateur ;
- boutons arrondis de type action ;
- cartes et panneaux plus modernes ;
- fond clair et espaces plus lisibles ;
- maintien de l'approche hybride : cartes pour la lecture rapide et listes/filtrage pour les écrans de gestion.

Les fonctionnalités métier de la V11 sont conservées : paramètres congés, quotas, alertes internes, import avec prévisualisation, filtres avancés, bons matériel, etc.


## V13 - Couleurs du logo H&Y Way

Cette version remplace la palette orange par une palette basée sur le logo H&Y Way :

- bleu foncé principal `#1F4E79` ;
- bleu clair d'accent `#3AA0E6` ;
- fonds très clairs bleu/gris ;
- boutons, barre supérieure, cartes sélectionnées et cloche d'alertes harmonisés avec l'identité visuelle H&Y Way.
