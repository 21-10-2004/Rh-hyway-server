# Corrections appliquées

Version corrigée sans ajout de nouvelle bibliothèque externe.

## Sécurité et règles métier
- Ajout du changement de mot de passe dans `AuthService`.
- Ajout d’un bouton `Changer mot de passe` dans le profil.
- Ajout du changement de mot de passe dans le menu utilisateur en haut à droite.
- Suppression du bouton `Déconnexion` de la barre latérale.
- Ajout de la déconnexion dans le menu utilisateur en haut à droite.
- Blocage complet du traitement des congés par un employé côté service.
- Blocage du traitement de ses propres congés par un manager.
- Limitation du manager au traitement des congés de son équipe.
- Validation stricte des statuts de congé.

## Notes de frais
- Refus des montants inférieurs ou égaux à 0 DH.
- Plafond de note de frais fixé à 10 000 DH.
- Objet obligatoire pour créer une note de frais.
- Contrôle côté interface et côté service.

## Fichiers joints
- Extensions autorisées : PDF, PNG, JPG, JPEG.
- Taille maximale : 5 Mo.
- Contrôle côté service pour éviter le contournement de l’interface.
- Filtre de sélection de justificatif limité aux formats autorisés.

## Remarques
- Aucune nouvelle dépendance n’a été ajoutée au fichier `requirements.txt`.
- Les corrections ont été appliquées dans les fichiers existants : `hr_app/services.py` et `hr_app/ui.py`.

## Mise à jour supplémentaire - gestion RH et utilisateurs

- Création utilisateur : remplacement de la saisie manuelle de l'ID employé par une liste de choix des employés actifs sans compte.
- Modification utilisateur : email, rôle, employé associé, activation et mot de passe peuvent être modifiés par le Responsable RH.
- Suppression utilisateur : le Responsable RH peut supprimer un compte utilisateur, sauf son propre compte connecté.
- Gestion employés : ajout des boutons Modifier employé et Supprimer employé.
- Suppression employé : si la fiche possède un historique RH, elle est archivée avec le statut `supprimé` et les comptes associés sont désactivés pour préserver l'intégrité de la base.
- Contrôles ajoutés : unicité matricule/email, interdiction de lier deux comptes au même employé, interdiction de supprimer son propre profil connecté.

## Correctifs complémentaires

- Sécurisation de `update_document_status` : un employé/manager ne peut plus marquer récupéré un document appartenant à un autre employé.
- Contrôle strict des statuts documents : seuls `soumise`, `traitée`, `prête`, `rejetée`, `récupérée` sont acceptés.
- Un document ne peut être marqué récupéré par l'employé/manager que s'il est déjà `prête`.
- Contrôle des fichiers uploadés dans les documents RH via extensions et taille maximale.
- Suppression de `Pillow` dans `requirements.txt` pour respecter la contrainte de ne pas ajouter de module.
- Ajout d'un serveur HTTP léger `server.py` basé uniquement sur la bibliothèque standard Python.
