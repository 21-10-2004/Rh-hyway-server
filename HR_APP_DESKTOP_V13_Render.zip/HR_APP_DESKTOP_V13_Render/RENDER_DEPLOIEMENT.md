# Déploiement Render - SIRH H&Y Way API

Cette version ajoute une configuration réelle pour Render.

## Fichiers ajoutés

- `render.yaml` : configuration Render.
- `requirements-render.txt` : dépendances du serveur Render.
- `Procfile` : commande de lancement compatible plateformes cloud.
- `.env.example` : exemple de variable secrète.

## Étapes de déploiement

1. Mets ce dossier projet sur GitHub.
2. Va sur Render.
3. Clique sur **New > Web Service**.
4. Connecte ton dépôt GitHub.
5. Render détectera `render.yaml`.
6. Dans **Environment**, ajoute :

```text
HR_APP_API_TOKEN=un_token_long_et_secret
```

7. Déploie le service.
8. Après déploiement, teste :

```text
https://ton-service.onrender.com/health
```

La réponse doit contenir :

```json
{
  "ok": true,
  "service": "SIRH H&Y Way API",
  "token_configured": true,
  "cloud_ready": true
}
```

## Important sur la base de données

Cette version utilise encore SQLite, donc elle fonctionne pour démonstration et test cloud.
Sur Render gratuit, le disque peut être réinitialisé lors d'un redéploiement. Pour une vraie production, il faut une base distante persistante comme PostgreSQL.

## Tester les endpoints protégés

Exemple avec curl :

```bash
curl -H "X-API-Token: TON_TOKEN" https://ton-service.onrender.com/api/dashboard
```

## Architecture obtenue

```text
PC 1 / PC 2 / PC 3  →  URL Render publique  →  server.py Render  →  SQLite cloud temporaire
```

Pour une synchronisation complète dans l'application desktop, il faudra ensuite modifier les écrans/services pour remplacer les accès SQLite locaux par des appels HTTP vers l'URL Render.
