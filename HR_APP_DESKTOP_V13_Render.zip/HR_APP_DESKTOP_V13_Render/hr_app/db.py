from __future__ import annotations

import sqlite3
from datetime import date
from pathlib import Path
from typing import Any, Iterable

from .config import DB_PATH, ensure_directories
from .constants import ROLE_EMPLOYE, ROLE_MANAGER, ROLE_PERMISSIONS, ROLE_RH, ROLES, PERMISSIONS
from .security import hash_password
from .utils import now_str


SCHEMA = r"""
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS role (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS permission (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS role_permission (
    role_id INTEGER NOT NULL,
    permission_id INTEGER NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES role(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permission(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS departement (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS poste (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    intitule TEXT NOT NULL,
    description TEXT,
    niveau TEXT
);

CREATE TABLE IF NOT EXISTS employe (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    matricule TEXT NOT NULL UNIQUE,
    nom TEXT NOT NULL,
    prenom TEXT NOT NULL,
    telephone TEXT,
    adresse TEXT,
    email_professionnel TEXT NOT NULL UNIQUE,
    date_embauche TEXT,
    statut TEXT DEFAULT 'actif',
    departement_id INTEGER,
    poste_id INTEGER,
    manager_id INTEGER,
    FOREIGN KEY (departement_id) REFERENCES departement(id),
    FOREIGN KEY (poste_id) REFERENCES poste(id),
    FOREIGN KEY (manager_id) REFERENCES employe(id)
);

CREATE TABLE IF NOT EXISTS utilisateur (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    actif INTEGER NOT NULL DEFAULT 1,
    role_id INTEGER NOT NULL,
    employe_id INTEGER,
    date_creation TEXT NOT NULL,
    derniere_connexion TEXT,
    FOREIGN KEY (role_id) REFERENCES role(id),
    FOREIGN KEY (employe_id) REFERENCES employe(id)
);

CREATE TABLE IF NOT EXISTS contrat (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_id INTEGER NOT NULL,
    type_contrat TEXT NOT NULL,
    date_debut TEXT,
    date_fin TEXT,
    salaire REAL DEFAULT 0,
    statut TEXT DEFAULT 'actif',
    fichier_contrat TEXT,
    FOREIGN KEY (employe_id) REFERENCES employe(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS solde_conge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_id INTEGER NOT NULL,
    annee INTEGER NOT NULL,
    jours_acquis REAL NOT NULL DEFAULT 0,
    jours_pris REAL NOT NULL DEFAULT 0,
    jours_restants REAL NOT NULL DEFAULT 0,
    UNIQUE(employe_id, annee),
    FOREIGN KEY (employe_id) REFERENCES employe(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS demande (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_id INTEGER NOT NULL,
    demandeur_id INTEGER,
    type_demande TEXT NOT NULL,
    statut TEXT NOT NULL,
    motif TEXT,
    date_creation TEXT NOT NULL,
    date_soumission TEXT,
    date_traitement TEXT,
    traite_par INTEGER,
    commentaire_traitement TEXT,
    FOREIGN KEY (employe_id) REFERENCES employe(id) ON DELETE CASCADE,
    FOREIGN KEY (demandeur_id) REFERENCES utilisateur(id),
    FOREIGN KEY (traite_par) REFERENCES utilisateur(id)
);

CREATE TABLE IF NOT EXISTS demande_conge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    demande_id INTEGER NOT NULL UNIQUE,
    date_debut TEXT NOT NULL,
    date_fin TEXT NOT NULL,
    nombre_jours REAL NOT NULL,
    type_conge TEXT NOT NULL,
    justificatif_conge TEXT,
    FOREIGN KEY (demande_id) REFERENCES demande(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS demande_document (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    demande_id INTEGER NOT NULL UNIQUE,
    type_document TEXT NOT NULL,
    fichier_document TEXT,
    document_recupere INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (demande_id) REFERENCES demande(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS demande_materiel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    demande_id INTEGER NOT NULL UNIQUE,
    type_materiel TEXT NOT NULL,
    description_besoin TEXT,
    date_besoin TEXT,
    materiel_id INTEGER,
    FOREIGN KEY (demande_id) REFERENCES demande(id) ON DELETE CASCADE,
    FOREIGN KEY (materiel_id) REFERENCES materiel(id)
);

CREATE TABLE IF NOT EXISTS note_de_frais (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_id INTEGER NOT NULL,
    objet TEXT NOT NULL,
    description TEXT,
    montant REAL NOT NULL,
    statut TEXT NOT NULL DEFAULT 'soumise',
    date_soumission TEXT NOT NULL,
    date_traitement TEXT,
    date_remboursement TEXT,
    traite_par INTEGER,
    commentaire_traitement TEXT,
    FOREIGN KEY (employe_id) REFERENCES employe(id) ON DELETE CASCADE,
    FOREIGN KEY (traite_par) REFERENCES utilisateur(id)
);

CREATE TABLE IF NOT EXISTS justificatif (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    note_id INTEGER NOT NULL,
    nom_fichier TEXT NOT NULL,
    type_fichier TEXT,
    chemin_fichier TEXT NOT NULL,
    date_ajout TEXT NOT NULL,
    FOREIGN KEY (note_id) REFERENCES note_de_frais(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS materiel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inventaire TEXT NOT NULL UNIQUE,
    designation TEXT NOT NULL,
    categorie TEXT,
    etat_physique TEXT NOT NULL DEFAULT 'en marche',
    statut_materiel TEXT NOT NULL DEFAULT 'disponible'
);

CREATE TABLE IF NOT EXISTS affectation_materiel (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    materiel_id INTEGER NOT NULL,
    employe_id INTEGER NOT NULL,
    demande_id INTEGER,
    date_affectation TEXT NOT NULL,
    date_retour_effective TEXT,
    etat_retour TEXT,
    statut_affectation TEXT NOT NULL DEFAULT 'active',
    confirmation_reception INTEGER NOT NULL DEFAULT 0,
    date_confirmation TEXT,
    bon_pdf_path TEXT,
    bon_signe_path TEXT,
    FOREIGN KEY (materiel_id) REFERENCES materiel(id) ON DELETE CASCADE,
    FOREIGN KEY (employe_id) REFERENCES employe(id) ON DELETE CASCADE,
    FOREIGN KEY (demande_id) REFERENCES demande(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS maintenance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    materiel_id INTEGER NOT NULL,
    date_demande TEXT NOT NULL,
    date_intervention TEXT,
    description_probleme TEXT,
    statut TEXT NOT NULL DEFAULT 'planifiée',
    rapport_intervention TEXT,
    FOREIGN KEY (materiel_id) REFERENCES materiel(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS historique_demande (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id INTEGER NOT NULL,
    ancien_statut TEXT,
    nouveau_statut TEXT,
    action TEXT NOT NULL,
    commentaire TEXT,
    utilisateur_id INTEGER,
    date_action TEXT NOT NULL,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id)
);

CREATE TABLE IF NOT EXISTS conge_parametre (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cle TEXT NOT NULL UNIQUE,
    valeur TEXT NOT NULL,
    description TEXT,
    date_modification TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS quota_absence_hebdo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    departement_id INTEGER NOT NULL,
    semaine_debut TEXT NOT NULL,
    semaine_fin TEXT NOT NULL,
    quota_max INTEGER NOT NULL DEFAULT 2,
    quota_utilise INTEGER NOT NULL DEFAULT 0,
    population TEXT NOT NULL DEFAULT 'employe',
    commentaire TEXT,
    UNIQUE(departement_id, semaine_debut, population),
    FOREIGN KEY (departement_id) REFERENCES departement(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS alerte_interne (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    utilisateur_id INTEGER NOT NULL,
    titre TEXT NOT NULL,
    message TEXT NOT NULL,
    type_alerte TEXT NOT NULL DEFAULT 'information',
    lien_module TEXT,
    lu INTEGER NOT NULL DEFAULT 0,
    date_creation TEXT NOT NULL,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE
);
"""


class Database:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        ensure_directories()
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")

    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        cursor = self.conn.execute(sql, tuple(params))
        self.conn.commit()
        return cursor

    def executemany(self, sql: str, params: Iterable[Iterable[Any]]) -> sqlite3.Cursor:
        cursor = self.conn.executemany(sql, params)
        self.conn.commit()
        return cursor

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        return list(self.conn.execute(sql, tuple(params)).fetchall())

    def query_one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, tuple(params)).fetchone()

    def close(self) -> None:
        self.conn.close()


def initialize_database() -> Database:
    db = Database()
    db.conn.executescript(SCHEMA)
    db.conn.commit()
    apply_migrations(db)
    seed_database(db)
    ensure_demo_baseline(db)
    sync_leave_balances(db)
    return db


def apply_migrations(db: Database) -> None:
    """Petites migrations pour les anciennes bases locales déjà créées."""
    ensure_default_leave_parameters(db)
    columns = [row["name"] for row in db.query("PRAGMA table_info(demande_conge)")]
    if "justificatif_conge" not in columns:
        db.execute("ALTER TABLE demande_conge ADD COLUMN justificatif_conge TEXT")

    demande_columns = [row["name"] for row in db.query("PRAGMA table_info(demande)")]
    if "demandeur_id" not in demande_columns:
        db.execute("ALTER TABLE demande ADD COLUMN demandeur_id INTEGER")

    affectation_columns = [row["name"] for row in db.query("PRAGMA table_info(affectation_materiel)")]
    if "confirmation_reception" not in affectation_columns:
        db.execute("ALTER TABLE affectation_materiel ADD COLUMN confirmation_reception INTEGER NOT NULL DEFAULT 0")
    if "date_confirmation" not in affectation_columns:
        db.execute("ALTER TABLE affectation_materiel ADD COLUMN date_confirmation TEXT")
    if "bon_pdf_path" not in affectation_columns:
        db.execute("ALTER TABLE affectation_materiel ADD COLUMN bon_pdf_path TEXT")
    if "bon_signe_path" not in affectation_columns:
        db.execute("ALTER TABLE affectation_materiel ADD COLUMN bon_signe_path TEXT")

    # Synchronise les permissions si l'utilisateur ouvre une base V1/V2 déjà existante.
    for perm in PERMISSIONS:
        db.execute(
            "INSERT OR IGNORE INTO permission(nom, description) VALUES (?, ?)",
            (perm, perm.replace("_", " ").capitalize()),
        )
    for role, permissions in ROLE_PERMISSIONS.items():
        role_row = db.query_one("SELECT id FROM role WHERE nom=?", (role,))
        if not role_row:
            db.execute("INSERT INTO role(nom, description) VALUES (?, ?)", (role, f"Rôle {role}"))
            role_row = db.query_one("SELECT id FROM role WHERE nom=?", (role,))
        for perm in permissions:
            perm_row = db.query_one("SELECT id FROM permission WHERE nom=?", (perm,))
            db.execute(
                "INSERT OR IGNORE INTO role_permission(role_id, permission_id) VALUES (?, ?)",
                (role_row["id"], perm_row["id"]),
            )


def seed_database(db: Database) -> None:
    already_seeded = db.query_one("SELECT COUNT(*) AS total FROM role")
    if already_seeded and already_seeded["total"] > 0:
        return

    for role in ROLES:
        db.execute("INSERT INTO role(nom, description) VALUES (?, ?)", (role, f"Rôle {role}"))

    for perm in PERMISSIONS:
        db.execute("INSERT INTO permission(nom, description) VALUES (?, ?)", (perm, perm.replace("_", " ").capitalize()))

    for role, permissions in ROLE_PERMISSIONS.items():
        role_id = db.query_one("SELECT id FROM role WHERE nom=?", (role,))["id"]
        for perm in permissions:
            perm_id = db.query_one("SELECT id FROM permission WHERE nom=?", (perm,))["id"]
            db.execute("INSERT INTO role_permission(role_id, permission_id) VALUES (?, ?)", (role_id, perm_id))

    db.executemany(
        "INSERT INTO departement(nom, description) VALUES (?, ?)",
        [
            ("Direction", "Pilotage général"),
            ("Ressources Humaines", "Gestion RH et administrative"),
            ("Opérations", "Activités opérationnelles"),
            ("Finance", "Suivi financier et notes de frais"),
        ],
    )
    db.executemany(
        "INSERT INTO poste(intitule, description, niveau) VALUES (?, ?, ?)",
        [
            ("Responsable RH", "Responsable de la gestion RH", "Cadre"),
            ("Manager Opérations", "Manager d'équipe", "Manager"),
            ("Employé administratif", "Collaborateur interne", "Employé"),
            ("Comptable", "Gestion comptable", "Employé"),
        ],
    )

    dept_direction = db.query_one("SELECT id FROM departement WHERE nom='Direction'")["id"]
    dept_rh = db.query_one("SELECT id FROM departement WHERE nom='Ressources Humaines'")["id"]
    dept_ops = db.query_one("SELECT id FROM departement WHERE nom='Opérations'")["id"]
    poste_rh = db.query_one("SELECT id FROM poste WHERE intitule='Responsable RH'")["id"]
    poste_manager = db.query_one("SELECT id FROM poste WHERE intitule='Manager Opérations'")["id"]
    poste_emp = db.query_one("SELECT id FROM poste WHERE intitule='Employé administratif'")["id"]

    db.execute(
        """INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel, date_embauche, statut, departement_id, poste_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("RH001", "RH", "Demo", "0600000001", "Marrakech", "rh@test.com", "2024-01-10", "actif", dept_rh, poste_rh),
    )
    rh_emp_id = db.query_one("SELECT id FROM employe WHERE matricule='RH001'")["id"]

    db.execute(
        """INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel, date_embauche, statut, departement_id, poste_id, manager_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("MGR001", "Manager", "Demo", "0600000002", "Casablanca", "manager@test.com", "2024-02-05", "actif", dept_direction, poste_manager, rh_emp_id),
    )
    manager_emp_id = db.query_one("SELECT id FROM employe WHERE matricule='MGR001'")["id"]

    db.execute(
        """INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel, date_embauche, statut, departement_id, poste_id, manager_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        ("EMP001", "Employé", "Demo", "0600000003", "Agadir", "employe@test.com", "2024-03-20", "actif", dept_ops, poste_emp, manager_emp_id),
    )
    emp_emp_id = db.query_one("SELECT id FROM employe WHERE matricule='EMP001'")["id"]

    users = [
        ("employe@test.com", ROLE_EMPLOYE, emp_emp_id),
        ("manager@test.com", ROLE_MANAGER, manager_emp_id),
        ("rh@test.com", ROLE_RH, rh_emp_id),
    ]
    for email, role_name, employe_id in users:
        role_id = db.query_one("SELECT id FROM role WHERE nom=?", (role_name,))["id"]
        db.execute(
            "INSERT INTO utilisateur(email, password_hash, actif, role_id, employe_id, date_creation) VALUES (?, ?, 1, ?, ?, ?)",
            (email, hash_password("123456"), role_id, employe_id, now_str()),
        )

    current_year = date.today().year
    for employee_id in [rh_emp_id, manager_emp_id, emp_emp_id]:
        db.execute(
            "INSERT INTO solde_conge(employe_id, annee, jours_acquis, jours_pris, jours_restants) VALUES (?, ?, 0, 0, 0)",
            (employee_id, current_year),
        )

    db.executemany(
        "INSERT INTO materiel(inventaire, designation, categorie, etat_physique, statut_materiel) VALUES (?, ?, ?, ?, ?)",
        [
            ("INV-PC-001", "PC portable Dell Latitude", "Informatique", "en marche", "disponible"),
            ("INV-SM-001", "Smartphone Samsung", "Téléphonie", "en marche", "disponible"),
            ("INV-PR-001", "Imprimante HP", "Bureautique", "en maintenance", "en maintenance"),
            ("INV-AC-001", "Casque audio", "Accessoire", "en marche", "disponible"),
        ],
    )

    # Some demo business data.
    user_emp = db.query_one("SELECT id FROM utilisateur WHERE email='employe@test.com'")["id"]
    db.execute(
        "INSERT INTO demande(employe_id, demandeur_id, type_demande, statut, motif, date_creation, date_soumission) VALUES (?, ?, 'CONGE', 'soumise', ?, ?, ?)",
        (emp_emp_id, user_emp, "Congé annuel", now_str(), now_str()),
    )
    demande_id = db.query_one("SELECT last_insert_rowid() AS id")["id"]
    db.execute(
        "INSERT INTO demande_conge(demande_id, date_debut, date_fin, nombre_jours, type_conge, justificatif_conge) VALUES (?, ?, ?, ?, ?, ?)",
        (demande_id, f"{current_year}-06-10", f"{current_year}-06-12", 3, "Congé annuel", ""),
    )
    db.execute(
        "INSERT INTO historique_demande(entity_type, entity_id, ancien_statut, nouveau_statut, action, commentaire, utilisateur_id, date_action) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        ("demande", demande_id, None, "soumise", "Création demande congé", "Donnée de démonstration", user_emp, now_str()),
    )

    db.execute(
        "INSERT INTO note_de_frais(employe_id, objet, description, montant, statut, date_soumission) VALUES (?, ?, ?, ?, 'soumise', ?)",
        (emp_emp_id, "Taxi client", "Déplacement professionnel", 85.00, now_str()),
    )

    db.execute(
        "INSERT INTO contrat(employe_id, type_contrat, date_debut, salaire, statut) VALUES (?, ?, ?, ?, ?)",
        (emp_emp_id, "CDI", "2024-03-20", 5500, "actif"),
    )



def _get_or_create_department(db: Database, nom: str, description: str) -> int:
    row = db.query_one("SELECT id FROM departement WHERE nom=?", (nom,))
    if row:
        return row["id"]
    db.execute("INSERT INTO departement(nom, description) VALUES (?, ?)", (nom, description))
    return db.query_one("SELECT id FROM departement WHERE nom=?", (nom,))["id"]


def _get_or_create_poste(db: Database, intitule: str, description: str, niveau: str) -> int:
    row = db.query_one("SELECT id FROM poste WHERE intitule=?", (intitule,))
    if row:
        return row["id"]
    db.execute(
        "INSERT INTO poste(intitule, description, niveau) VALUES (?, ?, ?)",
        (intitule, description, niveau),
    )
    return db.query_one("SELECT id FROM poste WHERE intitule=?", (intitule,))["id"]


def _get_or_create_employee(
    db: Database,
    matricule: str,
    nom: str,
    prenom: str,
    telephone: str,
    adresse: str,
    email: str,
    date_embauche: str,
    departement_id: int,
    poste_id: int,
    manager_id: int | None = None,
) -> int:
    row = db.query_one("SELECT id FROM employe WHERE matricule=? OR email_professionnel=?", (matricule, email))
    if row:
        emp_id = row["id"]
        db.execute(
            """
            UPDATE employe
            SET matricule=?, nom=?, prenom=?, telephone=?, adresse=?, email_professionnel=?,
                date_embauche=?, statut='actif', departement_id=?, poste_id=?, manager_id=?
            WHERE id=?
            """,
            (matricule, nom, prenom, telephone, adresse, email, date_embauche, departement_id, poste_id, manager_id, emp_id),
        )
        return emp_id
    db.execute(
        """
        INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel,
                            date_embauche, statut, departement_id, poste_id, manager_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'actif', ?, ?, ?)
        """,
        (matricule, nom, prenom, telephone, adresse, email, date_embauche, departement_id, poste_id, manager_id),
    )
    return db.query_one("SELECT id FROM employe WHERE matricule=?", (matricule,))["id"]


def ensure_default_leave_parameters(db: Database) -> None:
    """Paramètres RH modifiables depuis l'interface."""
    defaults = {
        "employe_jours_par_mois": ("1.5", "Jours acquis par mois pour les employés"),
        "manager_jours_annuels": ("27", "Jours annuels pour les managers au 01/01"),
        "rh_jours_annuels": ("27", "Jours annuels pour les responsables RH au 01/01"),
        "demi_journee_autorisee": ("1", "Autoriser les demandes en demi-journée"),
        "quota_absence_hebdo_defaut": ("2", "Quota hebdomadaire d'absences par département pour les employés"),
    }
    for cle, (valeur, description) in defaults.items():
        db.execute(
            "INSERT OR IGNORE INTO conge_parametre(cle, valeur, description, date_modification) VALUES (?, ?, ?, ?)",
            (cle, valeur, description, now_str()),
        )


def _get_leave_param_float(db: Database, key: str, default: float) -> float:
    row = db.query_one("SELECT valeur FROM conge_parametre WHERE cle=?", (key,))
    if not row:
        return default
    try:
        return float(str(row["valeur"]).replace(",", "."))
    except (TypeError, ValueError):
        return default


def _ensure_demo_user(db: Database, email: str, role_name: str, employe_id: int) -> None:
    role_id = db.query_one("SELECT id FROM role WHERE nom=?", (role_name,))["id"]
    password_hash = hash_password("123456")
    row = db.query_one("SELECT id FROM utilisateur WHERE lower(email)=lower(?)", (email,))
    if row:
        db.execute(
            """
            UPDATE utilisateur
            SET email=?, password_hash=?, actif=1, role_id=?, employe_id=?
            WHERE id=?
            """,
            (email, password_hash, role_id, employe_id, row["id"]),
        )
    else:
        db.execute(
            "INSERT INTO utilisateur(email, password_hash, actif, role_id, employe_id, date_creation) VALUES (?, ?, 1, ?, ?, ?)",
            (email, password_hash, role_id, employe_id, now_str()),
        )


def ensure_demo_baseline(db: Database) -> None:
    """Répare automatiquement les données minimales et les comptes démo.

    Une version précédente pouvait laisser une base locale partiellement initialisée
    avec les rôles créés mais sans employés/utilisateurs. Dans ce cas, le seed
    classique ne se relançait pas, ce qui provoquait une erreur de connexion.
    Cette fonction est volontairement idempotente : elle peut être appelée à
    chaque lancement sans dupliquer les données importantes.
    """
    ensure_default_leave_parameters(db)

    # Rôles, permissions et liaisons rôle-permission.
    for role in ROLES:
        db.execute("INSERT OR IGNORE INTO role(nom, description) VALUES (?, ?)", (role, f"Rôle {role}"))
    for perm in PERMISSIONS:
        db.execute(
            "INSERT OR IGNORE INTO permission(nom, description) VALUES (?, ?)",
            (perm, perm.replace("_", " ").capitalize()),
        )
    for role, permissions in ROLE_PERMISSIONS.items():
        role_row = db.query_one("SELECT id FROM role WHERE nom=?", (role,))
        for perm in permissions:
            perm_row = db.query_one("SELECT id FROM permission WHERE nom=?", (perm,))
            if role_row and perm_row:
                db.execute(
                    "INSERT OR IGNORE INTO role_permission(role_id, permission_id) VALUES (?, ?)",
                    (role_row["id"], perm_row["id"]),
                )

    # Données de référence.
    dept_direction = _get_or_create_department(db, "Direction", "Pilotage général")
    dept_rh = _get_or_create_department(db, "Ressources Humaines", "Gestion RH et administrative")
    dept_ops = _get_or_create_department(db, "Opérations", "Activités opérationnelles")
    _get_or_create_department(db, "Finance", "Suivi financier et notes de frais")

    poste_rh = _get_or_create_poste(db, "Responsable RH", "Responsable de la gestion RH", "Cadre")
    poste_manager = _get_or_create_poste(db, "Manager Opérations", "Manager d'équipe", "Manager")
    poste_emp = _get_or_create_poste(db, "Employé administratif", "Collaborateur interne", "Employé")
    _get_or_create_poste(db, "Comptable", "Gestion comptable", "Employé")

    # Employés et comptes démo.
    rh_emp_id = _get_or_create_employee(
        db, "RH001", "RH", "Demo", "0600000001", "Marrakech", "rh@test.com", "2024-01-10", dept_rh, poste_rh
    )
    manager_emp_id = _get_or_create_employee(
        db, "MGR001", "Manager", "Demo", "0600000002", "Casablanca", "manager@test.com", "2024-02-05",
        dept_direction, poste_manager, rh_emp_id
    )
    emp_emp_id = _get_or_create_employee(
        db, "EMP001", "Employé", "Demo", "0600000003", "Agadir", "employe@test.com", "2024-03-20",
        dept_ops, poste_emp, manager_emp_id
    )

    _ensure_demo_user(db, "employe@test.com", ROLE_EMPLOYE, emp_emp_id)
    _ensure_demo_user(db, "manager@test.com", ROLE_MANAGER, manager_emp_id)
    _ensure_demo_user(db, "rh@test.com", ROLE_RH, rh_emp_id)

    # Soldes de congés de l'année courante.
    current_year = date.today().year
    for employee_id in [rh_emp_id, manager_emp_id, emp_emp_id]:
        db.execute(
            """
            INSERT OR IGNORE INTO solde_conge(employe_id, annee, jours_acquis, jours_pris, jours_restants)
            VALUES (?, ?, 0, 0, 0)
            """,
            (employee_id, current_year),
        )

    # Matériel de démonstration.
    db.executemany(
        "INSERT OR IGNORE INTO materiel(inventaire, designation, categorie, etat_physique, statut_materiel) VALUES (?, ?, ?, ?, ?)",
        [
            ("INV-PC-001", "PC portable Dell Latitude", "Informatique", "en marche", "disponible"),
            ("INV-SM-001", "Smartphone Samsung", "Téléphonie", "en marche", "disponible"),
            ("INV-PR-001", "Imprimante HP", "Bureautique", "en maintenance", "en maintenance"),
            ("INV-AC-001", "Casque audio", "Accessoire", "en marche", "disponible"),
        ],
    )

    # Une petite donnée métier uniquement si la base n'a encore aucune demande.
    total_demandes = db.query_one("SELECT COUNT(*) AS total FROM demande")["total"]
    if total_demandes == 0:
        user_emp = db.query_one("SELECT id FROM utilisateur WHERE email='employe@test.com'")["id"]
        db.execute(
            "INSERT INTO demande(employe_id, demandeur_id, type_demande, statut, motif, date_creation, date_soumission) VALUES (?, ?, 'CONGE', 'soumise', ?, ?, ?)",
            (emp_emp_id, user_emp, "Congé annuel", now_str(), now_str()),
        )
        demande_id = db.query_one("SELECT last_insert_rowid() AS id")["id"]
        db.execute(
            "INSERT INTO demande_conge(demande_id, date_debut, date_fin, nombre_jours, type_conge, justificatif_conge) VALUES (?, ?, ?, ?, ?, ?)",
            (demande_id, f"{current_year}-06-10", f"{current_year}-06-12", 3, "Congé annuel", ""),
        )
        db.execute(
            "INSERT INTO historique_demande(entity_type, entity_id, ancien_statut, nouveau_statut, action, commentaire, utilisateur_id, date_action) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("demande", demande_id, None, "soumise", "Création demande congé", "Donnée de démonstration", user_emp, now_str()),
        )

    total_notes = db.query_one("SELECT COUNT(*) AS total FROM note_de_frais")["total"]
    if total_notes == 0:
        db.execute(
            "INSERT INTO note_de_frais(employe_id, objet, description, montant, statut, date_soumission) VALUES (?, ?, ?, ?, 'soumise', ?)",
            (emp_emp_id, "Taxi client", "Déplacement professionnel", 85.00, now_str()),
        )

    total_contrats = db.query_one("SELECT COUNT(*) AS total FROM contrat WHERE employe_id=?", (emp_emp_id,))["total"]
    if total_contrats == 0:
        db.execute(
            "INSERT INTO contrat(employe_id, type_contrat, date_debut, salaire, statut) VALUES (?, ?, ?, ?, ?)",
            (emp_emp_id, "CDI", "2024-03-20", 5500, "actif"),
        )



def _role_for_employee(db: Database, employe_id: int) -> str:
    """Retourne le rôle applicatif principal lié à un employé.

    Priorité utilisée : Responsable RH > Manager > Employé.
    Si l'employé importé n'a pas encore de compte utilisateur, il est traité comme Employé.
    """
    rows = db.query(
        """
        SELECT r.nom
        FROM utilisateur u
        JOIN role r ON r.id = u.role_id
        WHERE u.employe_id=? AND u.actif=1
        """,
        (employe_id,),
    )
    roles = {row["nom"] for row in rows}
    if ROLE_RH in roles:
        return ROLE_RH
    if ROLE_MANAGER in roles:
        return ROLE_MANAGER
    return ROLE_EMPLOYE


def _months_acquired_for_employee(date_embauche: str | None, current: date) -> int:
    """Nombre de mois donnant droit à 1,5 jour pour un employé simple."""
    start_month = 1
    start_year = current.year
    if date_embauche:
        try:
            hire = date.fromisoformat(date_embauche[:10])
            if hire.year > current.year:
                return 0
            if hire.year == current.year:
                start_month = hire.month
        except ValueError:
            # Si la date est mal formatée, on reste sur une règle simple année courante.
            start_month = 1
    return max(current.month - start_month + 1, 0)


def _leave_entitlement(db: Database, role_name: str, date_embauche: str | None, current: date) -> float:
    """Calcule les droits acquis selon les paramètres RH.

    - Employé : valeur mensuelle paramétrable.
    - Manager et Responsable RH : solde annuel paramétrable au 01/01.
    """
    if role_name == ROLE_MANAGER:
        return _get_leave_param_float(db, "manager_jours_annuels", 27.0)
    if role_name == ROLE_RH:
        return _get_leave_param_float(db, "rh_jours_annuels", 27.0)
    monthly = _get_leave_param_float(db, "employe_jours_par_mois", 1.5)
    return round(_months_acquired_for_employee(date_embauche, current) * monthly, 2)


def sync_leave_balances(db: Database) -> None:
    """Recalcule automatiquement les soldes de congés de l'année courante.

    Cette fonction est appelée au démarrage et après les validations de congés.
    Elle permet d'avoir des soldes fiables même si une ancienne base locale existe déjà.
    """
    current = date.today()
    year = current.year
    employees = db.query("SELECT id, date_embauche FROM employe")
    for emp in employees:
        role_name = _role_for_employee(db, emp["id"])
        jours_acquis = _leave_entitlement(db, role_name, emp["date_embauche"], current)
        pris_row = db.query_one(
            """
            SELECT COALESCE(SUM(c.nombre_jours), 0) AS total
            FROM demande d
            JOIN demande_conge c ON c.demande_id = d.id
            WHERE d.employe_id=?
              AND d.type_demande='CONGE'
              AND d.statut='approuvée'
              AND substr(c.date_debut, 1, 4)=?
            """,
            (emp["id"], str(year)),
        )
        jours_pris = float(pris_row["total"] or 0)
        jours_restants = max(round(jours_acquis - jours_pris, 2), 0)
        db.execute(
            """
            INSERT INTO solde_conge(employe_id, annee, jours_acquis, jours_pris, jours_restants)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(employe_id, annee) DO UPDATE SET
                jours_acquis=excluded.jours_acquis,
                jours_pris=excluded.jours_pris,
                jours_restants=excluded.jours_restants
            """,
            (emp["id"], year, jours_acquis, jours_pris, jours_restants),
        )
