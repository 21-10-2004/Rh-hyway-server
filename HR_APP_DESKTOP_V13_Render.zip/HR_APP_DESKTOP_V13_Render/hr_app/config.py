from pathlib import Path
import os
import sys

APP_NAME = "SIRH H&Y Way"


def _default_base_dir() -> Path:
    """Dossier racine utilisé pour data/, storage/ et exports/.

    - En mode script : dossier du projet.
    - En mode .exe PyInstaller : dossier où se trouve le .exe.
    - Si HR_APP_BASE_DIR est défini : cette variable est prioritaire.
    """
    override = os.environ.get("HR_APP_BASE_DIR")
    if override:
        return Path(override).resolve()
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


BASE_DIR = _default_base_dir()
DATA_DIR = BASE_DIR / "data"
STORAGE_DIR = BASE_DIR / "storage"
EXPORT_DIR = BASE_DIR / "exports"
DB_PATH = DATA_DIR / "sirh_hy_way.sqlite3"

STORAGE_SUBDIRS = [
    STORAGE_DIR / "justificatifs",
    STORAGE_DIR / "justificatifs_conges",
    STORAGE_DIR / "documents_rh",
    STORAGE_DIR / "contrats",
    STORAGE_DIR / "bons_attribution",
]


def ensure_directories() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    for directory in STORAGE_SUBDIRS:
        directory.mkdir(parents=True, exist_ok=True)
