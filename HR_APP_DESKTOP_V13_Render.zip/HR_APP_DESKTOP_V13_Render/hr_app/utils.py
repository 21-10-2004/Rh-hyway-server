from __future__ import annotations

import csv
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, Sequence

from .config import EXPORT_DIR

DATE_FMT = "%Y-%m-%d"


def today_str() -> str:
    return date.today().isoformat()


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def parse_date(value: str) -> date:
    return datetime.strptime(value.strip(), DATE_FMT).date()


def business_days_inclusive(start: str, end: str) -> int:
    """Calculate weekdays from start to end, inclusive. Weekends are not counted."""
    d1 = parse_date(start)
    d2 = parse_date(end)
    if d2 < d1:
        raise ValueError("La date de fin doit être supérieure ou égale à la date de début.")
    days = 0
    current = d1
    while current <= d2:
        if current.weekday() < 5:
            days += 1
        current += timedelta(days=1)
    return max(days, 1)


def safe_filename(filename: str) -> str:
    keep = []
    for char in Path(filename).name:
        keep.append(char if char.isalnum() or char in "._-" else "_")
    return "".join(keep)[:120]


def copy_to_storage(source_path: str, target_dir: Path, prefix: str = "") -> str:
    src = Path(source_path)
    if not src.exists():
        raise FileNotFoundError(source_path)
    target_dir.mkdir(parents=True, exist_ok=True)
    suffix = safe_filename(src.name)
    name = f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{suffix}" if prefix else f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{suffix}"
    dst = target_dir / name
    shutil.copy2(src, dst)
    return str(dst)


def export_rows_to_csv(filename: str, headers: Sequence[str], rows: Iterable[Sequence[object]]) -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    output = EXPORT_DIR / safe_filename(filename)
    if not output.name.lower().endswith(".csv"):
        output = output.with_suffix(".csv")
    with output.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(headers)
        writer.writerows(rows)
    return output
