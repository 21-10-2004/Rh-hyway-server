from __future__ import annotations

import os
import sys
import tkinter as tk
from datetime import date, timedelta
from tkinter import filedialog, messagebox, simpledialog, ttk
from pathlib import Path
from typing import Any, Callable

try:
    from PIL import Image
except Exception:  # pragma: no cover - fallback si Pillow indisponible
    Image = None

try:
    import customtkinter as ctk
except ImportError as exc:  # pragma: no cover - user-facing import check
    raise SystemExit("CustomTkinter n'est pas installé. Lancez : pip install -r requirements.txt") from exc

from .config import APP_NAME, STORAGE_DIR, ensure_directories
from .constants import (
    ROLE_EMPLOYE, ROLE_MANAGER, ROLE_RH, ROLES, ETAT_PHYSIQUE_MATERIEL,
    TYPES_CONGE_MAROC, TYPES_DOCUMENT_RH, DOCUMENTS_UPLOAD_AUTORISES
)
from .db import Database, initialize_database
from .services import AuthService, HRService
from .utils import copy_to_storage, export_rows_to_csv, now_str, parse_date, today_str

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Palette basée sur les couleurs du logo H&Y Way.
COLOR_PRIMARY = "#1F4E79"
COLOR_PRIMARY_HOVER = "#183E61"
COLOR_PRIMARY_SOFT = "#EAF4FD"
COLOR_SUCCESS = "#3AA0E6"
COLOR_SUCCESS_HOVER = "#2F88C7"
COLOR_DANGER = "#dc2626"
COLOR_DANGER_HOVER = "#b91c1c"
COLOR_BG = "#F3F7FB"
COLOR_PANEL = "#ffffff"
COLOR_BORDER = "#D9E7F3"
COLOR_TEXT = "#1F4E79"
COLOR_MUTED = "#5E7893"
COLOR_HEADER_TABLE = "#EAF4FD"


class CardListFrame(ctk.CTkFrame):
    """Liste moderne en cartes sélectionnables, compatible avec l'ancienne logique des tableaux."""
    def __init__(self, master: tk.Widget, columns: list[tuple[str, str, int]], height: int = 14):
        super().__init__(master, fg_color="transparent")
        self.columns = columns
        self.rows: list[tuple[Any, ...]] = []
        self.selected_index: int | None = None
        self.cards: list[ctk.CTkFrame] = []
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.grid(row=0, column=0, sticky="nsew")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

    def set_rows(self, rows: list[tuple[Any, ...]]) -> None:
        for child in self.scroll.winfo_children():
            child.destroy()
        self.rows = [tuple(r) for r in rows]
        self.selected_index = None
        self.cards = []
        if not rows:
            empty = ctk.CTkFrame(self.scroll, corner_radius=14, fg_color=COLOR_PANEL)
            empty.grid(row=0, column=0, sticky="ew", padx=6, pady=6)
            ctk.CTkLabel(empty, text="Aucun élément à afficher.", text_color=COLOR_MUTED).pack(anchor="w", padx=16, pady=18)
            self.scroll.grid_columnconfigure(0, weight=1)
            return

        self.scroll.grid_columnconfigure(0, weight=1)
        for idx, row in enumerate(self.rows):
            card = ctk.CTkFrame(self.scroll, corner_radius=14, fg_color=COLOR_PANEL, border_width=1, border_color=COLOR_BORDER)
            card.grid(row=idx, column=0, sticky="ew", padx=6, pady=6)
            card.grid_columnconfigure(1, weight=1)
            self.cards.append(card)

            title_value = str(row[1]) if len(row) > 1 else f"Élément {row[0]}"
            ctk.CTkLabel(
                card,
                text=f"#{row[0]}  •  {title_value}",
                font=("Segoe UI", 13, "bold"),
                anchor="w",
            ).grid(row=0, column=0, columnspan=2, sticky="ew", padx=14, pady=(12, 6))

            detail_row = 1
            for col_idx, (_, label, _) in enumerate(self.columns[2:], start=2):
                value = row[col_idx] if col_idx < len(row) else ""
                ctk.CTkLabel(card, text=f"{label} :", text_color=COLOR_MUTED, anchor="w").grid(
                    row=detail_row, column=0, sticky="nw", padx=(14, 8), pady=2
                )
                ctk.CTkLabel(card, text=str(value), anchor="w", wraplength=760, justify="left").grid(
                    row=detail_row, column=1, sticky="ew", padx=(0, 14), pady=2
                )
                detail_row += 1

            ctk.CTkLabel(card, text="Cliquez sur la carte pour la sélectionner", text_color="#7a7a7a", font=("Segoe UI", 10)).grid(
                row=detail_row, column=0, columnspan=2, sticky="w", padx=14, pady=(4, 12)
            )
            self._bind_select(card, idx)

    def _bind_select(self, widget: tk.Widget, idx: int) -> None:
        widget.bind("<Button-1>", lambda _event, i=idx: self._select(i))
        for child in widget.winfo_children():
            self._bind_select(child, idx)

    def _select(self, idx: int) -> None:
        self.selected_index = idx
        for i, card in enumerate(self.cards):
            if i == idx:
                card.configure(fg_color=COLOR_PRIMARY_SOFT, border_color=COLOR_PRIMARY)
            else:
                card.configure(fg_color=COLOR_PANEL, border_color="#e3e6ee")

    def selected_id(self) -> int | None:
        if self.selected_index is None:
            return None
        try:
            return int(self.rows[self.selected_index][0])
        except (ValueError, TypeError, IndexError):
            return None

    def all_rows(self) -> list[tuple[Any, ...]]:
        return list(self.rows)


class LoginWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        ensure_directories()
        self.db = initialize_database()
        self.auth = AuthService(self.db)
        self.title(f"Connexion - {APP_NAME}")
        self.geometry("460x430")
        self.resizable(False, False)
        self._build()

    def _build(self) -> None:
        self.configure(fg_color=COLOR_BG)
        container = ctk.CTkFrame(self, corner_radius=24, fg_color=COLOR_PANEL, border_width=1, border_color=COLOR_BORDER)
        container.pack(fill="both", expand=True, padx=34, pady=34)

        ctk.CTkFrame(container, height=8, fg_color=COLOR_PRIMARY, corner_radius=8).pack(fill="x", padx=22, pady=(22, 12))
        ctk.CTkLabel(container, text="H&Y Way", font=("Segoe UI", 30, "bold"), text_color=COLOR_PRIMARY).pack(pady=(2, 0))
        ctk.CTkLabel(container, text="SIRH desktop • RH & Matériel", font=("Segoe UI", 13), text_color=COLOR_MUTED).pack(pady=(0, 24))

        self.email_entry = ctk.CTkEntry(container, width=330, height=42, corner_radius=12, placeholder_text="Email")
        self.email_entry.pack(pady=8)
        self.email_entry.insert(0, "rh@test.com")

        self.password_entry = ctk.CTkEntry(container, width=330, height=42, corner_radius=12, placeholder_text="Mot de passe", show="*")
        self.password_entry.pack(pady=8)
        self.password_entry.insert(0, "123456")
        self.password_entry.bind("<Return>", lambda _: self.login())

        ctk.CTkButton(
            container, text="Se connecter", width=330, height=42, corner_radius=18,
            fg_color=COLOR_PRIMARY, hover_color=COLOR_PRIMARY_HOVER, command=self.login
        ).pack(pady=(18, 10))

        demo = "Comptes démo : employe@test.com / manager@test.com / rh@test.com\nMot de passe : 123456"
        ctk.CTkLabel(container, text=demo, justify="center", text_color=COLOR_MUTED).pack(pady=18)

    def login(self) -> None:
        user = self.auth.authenticate(self.email_entry.get(), self.password_entry.get())
        if not user:
            messagebox.showerror("Connexion refusée", "Email, mot de passe ou compte inactif invalide.")
            return
        self.withdraw()
        MainWindow(self.db, user, on_logout=self._show_again).mainloop()

    def _show_again(self) -> None:
        self.deiconify()


class MainWindow(ctk.CTkToplevel):
    def __init__(self, db: Database, user: dict[str, Any], on_logout: Callable[[], None]):
        super().__init__()
        self.db = db
        self.user = user
        self.service = HRService(db)
        self.service.sync_leave_balances()
        self.on_logout = on_logout
        self.title(APP_NAME)
        self.geometry("1260x760")
        self.minsize(1100, 650)
        self.protocol("WM_DELETE_WINDOW", self.logout)
        self.current_table: CardListFrame | None = None
        self._build_shell()
        self.show_dashboard()

    # ---------- shell ----------
    def _build_shell(self) -> None:
        self.configure(fg_color=COLOR_BG)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        sidebar = ctk.CTkFrame(self, corner_radius=0, width=230, fg_color=COLOR_PANEL)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)

        role = self.user["role_nom"]
        full_name = f"{self.user.get('employe_prenom') or ''} {self.user.get('employe_nom') or ''}".strip() or self.user["email"]

        logo_box = ctk.CTkFrame(sidebar, fg_color="transparent")
        logo_box.pack(fill="x", padx=18, pady=(24, 18))
        logo_path = Path(__file__).resolve().parent / "assets" / "hy_way_logo.png"
        self._logo_image = None
        if Image is not None and logo_path.exists():
            try:
                self._logo_image = ctk.CTkImage(light_image=Image.open(logo_path), size=(126, 86))
                ctk.CTkLabel(logo_box, image=self._logo_image, text="").pack(anchor="w")
            except Exception:
                ctk.CTkLabel(logo_box, text="H&Y Way", font=("Segoe UI", 24, "bold"), text_color=COLOR_PRIMARY).pack(anchor="w")
        else:
            ctk.CTkLabel(logo_box, text="H&Y Way", font=("Segoe UI", 24, "bold"), text_color=COLOR_PRIMARY).pack(anchor="w")
        ctk.CTkLabel(logo_box, text="The only way to succeed", font=("Segoe UI", 11), text_color=COLOR_MUTED).pack(anchor="w", pady=(4, 0))

        self._nav(sidebar, "🏠  Tableau de bord", self.show_dashboard)
        self._nav(sidebar, "👤  Mon profil", self.show_profile)
        self._nav(sidebar, "🌴  Congés", self.show_conges)
        self._nav(sidebar, "💳  Notes de frais", self.show_expenses)
        if role in (ROLE_EMPLOYE, ROLE_MANAGER, ROLE_RH):
            self._nav(sidebar, "📄  Documents RH", self.show_documents)
        if role != ROLE_EMPLOYE:
            self._nav(sidebar, "💻  Matériel", self.show_material)
        if role == ROLE_RH:
            self._nav(sidebar, "👥  Employés", self.show_employees)
            self._nav(sidebar, "🔐  Utilisateurs & rôles", self.show_users)
        if role != ROLE_EMPLOYE:
            self._nav(sidebar, "🕘  Historique", self.show_history)

        shell = ctk.CTkFrame(self, corner_radius=0, fg_color=COLOR_BG)
        shell.grid(row=0, column=1, sticky="nsew")
        shell.grid_columnconfigure(0, weight=1)
        shell.grid_rowconfigure(1, weight=1)

        topbar = ctk.CTkFrame(shell, corner_radius=0, fg_color=COLOR_PRIMARY, height=72)
        topbar.grid(row=0, column=0, sticky="ew")
        topbar.grid_propagate(False)
        topbar.grid_columnconfigure(1, weight=1)
        self.page_title = ctk.CTkLabel(topbar, text=APP_NAME, font=("Segoe UI", 17, "bold"), text_color="#ffffff")
        self.page_title.grid(row=0, column=0, sticky="w", padx=26)

        self.alert_button = ctk.CTkButton(
            topbar, text="🔔", width=58, height=40, corner_radius=20,
            fg_color="#ffffff", hover_color="#EAF4FD", text_color=COLOR_PRIMARY, command=self.show_alerts
        )
        self.alert_button.grid(row=0, column=2, padx=(6, 8))
        self.user_button = ctk.CTkButton(
            topbar, text=f"{full_name}  •  {role}  ▾", height=40, corner_radius=22,
            fg_color="#3AA0E6", hover_color="#2F8FD0", text_color="#ffffff",
            font=("Segoe UI", 12, "bold"), command=self._show_user_menu
        )
        self.user_button.grid(row=0, column=3, padx=(0, 24), pady=14)

        self.content = ctk.CTkFrame(shell, corner_radius=0, fg_color=COLOR_BG)
        self.content.grid(row=1, column=0, sticky="nsew")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(1, weight=1)
        self._refresh_alert_button()

    def _nav(self, parent: tk.Widget, label: str, command: Callable[[], None]) -> None:
        ctk.CTkButton(
            parent, text=label, anchor="w", height=42, corner_radius=20, command=command,
            fg_color="transparent", hover_color=COLOR_PRIMARY_SOFT, text_color=COLOR_TEXT,
            font=("Segoe UI", 13, "bold")
        ).pack(fill="x", padx=12, pady=4)

    def _clear(self, title: str, subtitle: str = "") -> ctk.CTkFrame:
        self._refresh_alert_button()
        if hasattr(self, "page_title"):
            self.page_title.configure(text=title)
        for child in self.content.winfo_children():
            child.destroy()
        header = ctk.CTkFrame(self.content, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=34, pady=(22, 8))
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text=title, font=("Segoe UI", 24, "bold"), text_color=COLOR_TEXT, anchor="w").grid(row=0, column=0, sticky="w")
        if subtitle:
            ctk.CTkLabel(header, text=subtitle, text_color=COLOR_MUTED, anchor="w").grid(row=1, column=0, sticky="w", pady=(2, 0))
        body = ctk.CTkFrame(self.content, corner_radius=24, fg_color=COLOR_PANEL, border_width=1, border_color=COLOR_BORDER)
        body.grid(row=1, column=0, sticky="nsew", padx=34, pady=(0, 26))
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(1, weight=1)
        self.current_table = None
        return body

    def _show_user_menu(self) -> None:
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Mon profil", command=self.show_profile)
        menu.add_command(label="Changer mot de passe", command=self.change_my_password)
        menu.add_separator()
        menu.add_command(label="Déconnexion", command=self.logout)
        try:
            x = self.user_button.winfo_rootx()
            y = self.user_button.winfo_rooty() + self.user_button.winfo_height()
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def change_my_password(self) -> None:
        data = self._simple_form("Changer le mot de passe", [
            ("old", "Ancien mot de passe", ""),
            ("new", "Nouveau mot de passe", ""),
            ("confirm", "Confirmer le nouveau mot de passe", ""),
        ], "Modifier")
        if not data:
            return
        if data["new"] != data["confirm"]:
            self._error("La confirmation ne correspond pas au nouveau mot de passe.")
            return
        try:
            AuthService(self.db).change_password(self.user["id"], data["old"], data["new"])
            self._info("Mot de passe modifié avec succès.")
        except Exception as exc:
            self._error(exc)

    def logout(self) -> None:
        self.destroy()
        self.on_logout()

    # ---------- helpers ----------
    def _fmt_days(self, value: Any) -> str:
        try:
            number = float(value or 0)
        except (TypeError, ValueError):
            return str(value)
        if number.is_integer():
            return str(int(number))
        return str(number).replace(".", ",")

    def _info(self, text: str) -> None:
        messagebox.showinfo("Information", text)

    def _error(self, exc: Exception | str) -> None:
        messagebox.showerror("Erreur", str(exc))

    def _confirm(self, question: str) -> bool:
        return messagebox.askyesno("Confirmation", question)

    def _ask_comment(self, title: str = "Commentaire") -> str:
        return simpledialog.askstring(title, "Commentaire ou motif :", parent=self) or ""

    def _selected_required(self, table: CardListFrame | None = None) -> int | None:
        table = table or self.current_table
        selected = table.selected_id() if table else None
        if not selected:
            self._info("Sélectionnez une ligne dans le tableau.")
        return selected

    def _export_current(self, filename: str) -> None:
        if not self.current_table:
            return
        headers = [col[1] for col in self.current_table.columns]
        path = export_rows_to_csv(filename, headers, self.current_table.all_rows())
        self._info(f"Export CSV créé :\n{path}")

    def _make_button_bar(self, parent: tk.Widget) -> ctk.CTkFrame:
        bar = ctk.CTkFrame(parent, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", padx=18, pady=18)
        return bar

    def _button(self, parent: tk.Widget, text: str, cmd: Callable[[], None], danger: bool = False) -> None:
        if danger:
            kwargs = {"fg_color": "#fff5f5", "hover_color": "#fee2e2", "text_color": COLOR_DANGER}
        else:
            kwargs = {"fg_color": COLOR_SUCCESS, "hover_color": COLOR_SUCCESS_HOVER, "text_color": "#ffffff"}
        ctk.CTkButton(parent, text=text, command=cmd, height=34, corner_radius=17, font=("Segoe UI", 12, "bold"), **kwargs).pack(side="left", padx=5)

    def _simple_form(self, title: str, fields: list[tuple[str, str, str]], submit_label: str = "Enregistrer") -> dict[str, str] | None:
        """Modal form. fields = [(key, label, default)]."""
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.geometry("520x" + str(145 + len(fields) * 48))
        win.grab_set()
        win.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(win, text=title, font=("Segoe UI", 18, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(20, 10))
        entries: dict[str, ctk.CTkEntry] = {}
        for idx, (key, label, default) in enumerate(fields, start=1):
            ctk.CTkLabel(win, text=label).grid(row=idx, column=0, sticky="w", padx=20, pady=6)
            entry = ctk.CTkEntry(win)
            entry.insert(0, default or "")
            entry.grid(row=idx, column=1, sticky="ew", padx=(5, 20), pady=6)
            entries[key] = entry
        result: dict[str, str] | None = None

        def submit() -> None:
            nonlocal result
            result = {k: e.get().strip() for k, e in entries.items()}
            win.destroy()

        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.grid(row=len(fields) + 1, column=0, columnspan=2, sticky="e", padx=20, pady=16)
        ctk.CTkButton(actions, text="Annuler", fg_color="#8792a5", command=win.destroy).pack(side="right", padx=4)
        ctk.CTkButton(actions, text=submit_label, command=submit).pack(side="right", padx=4)
        self.wait_window(win)
        return result

    def _choice_form(
        self,
        title: str,
        text_fields: list[tuple[str, str, str]],
        choice_fields: list[tuple[str, str, list[str], str]],
        submit_label: str = "Enregistrer",
    ) -> dict[str, str] | None:
        """Formulaire modal avec champs texte et listes de choix."""
        total = len(text_fields) + len(choice_fields)
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.geometry("620x" + str(155 + total * 50))
        win.grab_set()
        win.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(win, text=title, font=("Segoe UI", 18, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(20, 10))
        entries: dict[str, ctk.CTkEntry] = {}
        vars_: dict[str, tk.StringVar] = {}
        row_i = 1
        for key, label, default in text_fields:
            ctk.CTkLabel(win, text=label).grid(row=row_i, column=0, sticky="w", padx=20, pady=6)
            entry = ctk.CTkEntry(win)
            entry.insert(0, default or "")
            entry.grid(row=row_i, column=1, sticky="ew", padx=(5, 20), pady=6)
            entries[key] = entry
            row_i += 1
        for key, label, values, default in choice_fields:
            ctk.CTkLabel(win, text=label).grid(row=row_i, column=0, sticky="w", padx=20, pady=6)
            vals = values or [""]
            var = tk.StringVar(value=default if default in vals else vals[0])
            ctk.CTkOptionMenu(win, values=vals, variable=var).grid(row=row_i, column=1, sticky="ew", padx=(5, 20), pady=6)
            vars_[key] = var
            row_i += 1
        result: dict[str, str] | None = None

        def submit() -> None:
            nonlocal result
            result = {k: e.get().strip() for k, e in entries.items()}
            result.update({k: v.get().strip() for k, v in vars_.items()})
            win.destroy()

        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.grid(row=row_i, column=0, columnspan=2, sticky="e", padx=20, pady=16)
        ctk.CTkButton(actions, text="Annuler", fg_color="#8792a5", command=win.destroy).pack(side="right", padx=4)
        ctk.CTkButton(actions, text=submit_label, command=submit).pack(side="right", padx=4)
        self.wait_window(win)
        return result

    def _employee_choice_values(self, include_employe_id: int | None = None, allow_none: bool = True) -> tuple[list[str], dict[str, int | None]]:
        rows = self.service.list_employees_without_user(include_employe_id)
        mapping: dict[str, int | None] = {}
        values: list[str] = []
        if allow_none:
            values.append("Aucun employé associé")
            mapping[values[-1]] = None
        for e in rows:
            label = f"{e['id']} - {e['matricule']} - {e['nom']} ({e['email_professionnel']})"
            values.append(label)
            mapping[label] = int(e["id"])
        if not values:
            values = ["Aucun employé disponible"]
            mapping[values[0]] = None
        return values, mapping

    def _refresh_alert_button(self) -> None:
        if not hasattr(self, "alert_button"):
            return
        count = self.service.unread_alert_count(self.user["id"])
        if count:
            self.alert_button.configure(text=f"🔔 {count}", fg_color="#ffffff", hover_color="#EAF4FD", text_color=COLOR_DANGER)
        else:
            self.alert_button.configure(text="🔔", fg_color="#ffffff", hover_color="#EAF4FD", text_color=COLOR_PRIMARY)

    def show_alerts(self) -> None:
        body = self._clear("Centre d’alertes", "Messages internes visibles après connexion")
        bar = self._make_button_bar(body)
        self._button(bar, "Marquer comme lues", self.mark_alerts_read)
        table = CardListFrame(body, [
            ("id", "ID", 50), ("date", "Date", 150), ("titre", "Titre", 190),
            ("message", "Message", 420), ("type", "Type", 110), ("etat", "État", 90)
        ])
        table.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.current_table = table
        rows = self.service.list_alerts(self.user["id"])
        table.set_rows([(r["id"], r["date_creation"], r["titre"], r["message"], r["type_alerte"], r["etat"]) for r in rows])

    def mark_alerts_read(self) -> None:
        self.service.mark_alerts_read(self.user["id"])
        self._refresh_alert_button()
        self.show_alerts()

    # ---------- dashboard ----------
    def show_dashboard(self) -> None:
        self.service.sync_leave_balances()
        body = self._clear("Tableau de bord", "Vue synthétique adaptée au rôle connecté")
        body.grid_rowconfigure(2, weight=1)
        grid = ctk.CTkFrame(body, fg_color="transparent")
        grid.grid(row=0, column=0, sticky="ew", padx=18, pady=18)
        for i in range(4):
            grid.grid_columnconfigure(i, weight=1)

        stats = self._dashboard_stats()
        for i, (label, value) in enumerate(stats):
            card = ctk.CTkFrame(grid, corner_radius=14, fg_color=COLOR_PANEL, border_width=1, border_color=COLOR_BORDER)
            card.grid(row=i // 4, column=i % 4, sticky="ew", padx=8, pady=8)
            ctk.CTkLabel(card, text=str(value), font=("Segoe UI", 28, "bold")).pack(anchor="w", padx=16, pady=(16, 0))
            ctk.CTkLabel(card, text=label, text_color=COLOR_MUTED).pack(anchor="w", padx=16, pady=(0, 16))

        if self.user["role_nom"] == ROLE_EMPLOYE:
            title = "Mes 5 dernières demandes"
            rows = self.db.query("""
                SELECT id, date_creation AS date_action,
                       CASE type_demande
                           WHEN 'CONGE' THEN 'Demande de congé'
                           WHEN 'DOCUMENT' THEN 'Demande document RH'
                           WHEN 'MATERIEL' THEN 'Demande matériel'
                           ELSE type_demande
                       END AS type_element,
                       statut,
                       COALESCE(motif, '') AS details
                FROM demande
                WHERE employe_id=?
                UNION ALL
                SELECT id, date_soumission AS date_action,
                       'Note de frais' AS type_element,
                       statut,
                       objet || ' - ' || printf('%.2f DH', montant) AS details
                FROM note_de_frais
                WHERE employe_id=?
                ORDER BY date_action DESC
                LIMIT 5
            """, (self.user["employe_id"], self.user["employe_id"]))
            columns = [
                ("id", "ID", 50), ("date", "Date", 150), ("type", "Type", 180),
                ("statut", "Statut", 130), ("details", "Détails", 360)
            ]
        else:
            title = "Activité récente"
            rows = self.db.query("""
                SELECT h.id, h.date_action, h.action, h.entity_type || ' #' || h.entity_id AS entity,
                       COALESCE(h.ancien_statut,''), COALESCE(h.nouveau_statut,''), COALESCE(h.commentaire,'')
                FROM historique_demande h
                ORDER BY h.id DESC LIMIT 10
            """)
            columns = [
                ("id", "ID", 50), ("date", "Date", 150), ("action", "Action", 180),
                ("entity", "Objet", 90), ("old", "Ancien", 100), ("new", "Nouveau", 100), ("comment", "Commentaire", 240)
            ]

        recent_title = ctk.CTkLabel(body, text=title, font=("Segoe UI", 16, "bold"))
        recent_title.grid(row=1, column=0, sticky="w", padx=20, pady=(5, 5))
        cards = CardListFrame(body, columns, height=9)
        cards.grid(row=2, column=0, sticky="nsew", padx=18, pady=(0, 18))
        cards.set_rows([tuple(r) for r in rows])

    def _dashboard_stats(self) -> list[tuple[str, Any]]:
        role = self.user["role_nom"]
        emp_id = self.user["employe_id"]
        q = self.db.query_one
        balance = self.service.get_leave_balance(emp_id)
        solde_resume = f"{self._fmt_days(balance['jours_restants'])} j"
        if role == ROLE_EMPLOYE:
            return [
                ("Solde restant", solde_resume),
                ("Dernières demandes avec statut", q("SELECT COUNT(*) total FROM (SELECT id FROM demande WHERE employe_id=? UNION ALL SELECT id FROM note_de_frais WHERE employe_id=?)", (emp_id, emp_id))["total"]),
                ("Documents prêts", q("SELECT COUNT(*) total FROM demande d JOIN demande_document dd ON dd.demande_id=d.id WHERE d.employe_id=? AND d.type_demande='DOCUMENT' AND d.statut='prête'", (emp_id,))["total"]),
                ("Notes de frais en cours", q("SELECT COUNT(*) total FROM note_de_frais WHERE employe_id=? AND statut NOT IN ('remboursée','rejetée')", (emp_id,))["total"]),
            ]
        if role == ROLE_MANAGER:
            today = date.today()
            week_start = (today - timedelta(days=today.weekday())).isoformat()
            week_end = (today + timedelta(days=6 - today.weekday())).isoformat()
            return [
                ("Demandes congés de mon équipe", q("SELECT COUNT(*) total FROM demande d JOIN employe e ON e.id=d.employe_id WHERE d.type_demande='CONGE' AND e.manager_id=?", (emp_id,))["total"]),
                ("Notes de frais à prévalider", q("SELECT COUNT(*) total FROM note_de_frais n JOIN employe e ON e.id=n.employe_id WHERE e.manager_id=? AND n.statut IN ('soumise','en vérification')", (emp_id,))["total"]),
                ("Demandes matériel envoyées", q("SELECT COUNT(*) total FROM demande WHERE type_demande='MATERIEL' AND demandeur_id=?", (self.user["id"],))["total"]),
                ("Absences équipe cette semaine", q("SELECT COUNT(*) total FROM demande d JOIN demande_conge c ON c.demande_id=d.id JOIN employe e ON e.id=d.employe_id WHERE d.type_demande='CONGE' AND d.statut='approuvée' AND e.manager_id=? AND c.date_debut<=? AND c.date_fin>=?", (emp_id, week_end, week_start))["total"]),
            ]
        return [
            ("Congés en attente", q("SELECT COUNT(*) total FROM demande WHERE type_demande='CONGE' AND statut IN ('soumise','en traitement')")["total"]),
            ("Notes de frais à valider", q("SELECT COUNT(*) total FROM note_de_frais WHERE statut='prévalidée manager'")["total"]),
            ("Documents à préparer", q("SELECT COUNT(*) total FROM demande WHERE type_demande='DOCUMENT' AND statut IN ('soumise','traitée')")["total"]),
            ("Demandes matériel à traiter", q("SELECT COUNT(*) total FROM demande WHERE type_demande='MATERIEL' AND statut IN ('soumise','en traitement')")["total"]),
        ]

    # ---------- profile ----------
    def show_profile(self) -> None:
        body = self._clear("Mon profil", "Consultation et modification des informations autorisées")
        row = self.db.query_one("""
            SELECT e.*, d.nom AS departement, p.intitule AS poste
            FROM employe e
            LEFT JOIN departement d ON d.id=e.departement_id
            LEFT JOIN poste p ON p.id=e.poste_id
            WHERE e.id=?
        """, (self.user["employe_id"],))
        panel = ctk.CTkFrame(body, corner_radius=14)
        panel.grid(row=0, column=0, sticky="new", padx=20, pady=20)
        panel.grid_columnconfigure(1, weight=1)
        labels = [
            ("Matricule", row["matricule"]), ("Nom", row["nom"]), ("Prénom", row["prenom"]),
            ("Email professionnel", row["email_professionnel"]), ("Téléphone", row["telephone"] or ""),
            ("Adresse", row["adresse"] or ""), ("Département", row["departement"] or ""),
            ("Poste", row["poste"] or ""), ("Date embauche", row["date_embauche"] or ""), ("Statut", row["statut"]),
        ]
        for i, (k, v) in enumerate(labels):
            ctk.CTkLabel(panel, text=f"{k} :", font=("Segoe UI", 12, "bold")).grid(row=i, column=0, sticky="w", padx=20, pady=6)
            ctk.CTkLabel(panel, text=str(v), anchor="w").grid(row=i, column=1, sticky="w", padx=20, pady=6)
        actions = ctk.CTkFrame(panel, fg_color="transparent")
        actions.grid(row=len(labels), column=0, columnspan=2, sticky="w", padx=20, pady=16)
        ctk.CTkButton(actions, text="Modifier téléphone/adresse", command=self.edit_my_profile).pack(side="left", padx=(0, 8))
        ctk.CTkButton(actions, text="Changer mot de passe", command=self.change_my_password).pack(side="left")

    def edit_my_profile(self) -> None:
        row = self.db.query_one("SELECT telephone, adresse FROM employe WHERE id=?", (self.user["employe_id"],))
        data = self._simple_form("Modifier mes informations", [
            ("telephone", "Téléphone", row["telephone"] or ""),
            ("adresse", "Adresse", row["adresse"] or ""),
        ])
        if not data:
            return
        self.db.execute("UPDATE employe SET telephone=?, adresse=? WHERE id=?", (data["telephone"], data["adresse"], self.user["employe_id"]))
        self.service.history.record("employe", self.user["employe_id"], None, None, "Modification profil", self.user["id"], "Téléphone/adresse")
        self.show_profile()

    # ---------- congés ----------
    def show_conges(self) -> None:
        self.service.sync_leave_balances()
        body = self._clear("Gestion des congés", "Soumission, suivi, quotas et traitement des demandes")
        bar = self._make_button_bar(body)
        balance = self.service.get_leave_balance(self.user["employe_id"])
        ctk.CTkLabel(
            bar,
            text=f"Solde : acquis {self._fmt_days(balance['jours_acquis'])} j | pris {self._fmt_days(balance['jours_pris'])} j | restant {self._fmt_days(balance['jours_restants'])} j",
            text_color=COLOR_TEXT,
            font=("Segoe UI", 12, "bold"),
        ).pack(side="right", padx=8)
        if self.user["role_nom"] in (ROLE_EMPLOYE, ROLE_MANAGER):
            self._button(bar, "Nouvelle demande", self.add_leave_request)
            self._button(bar, "Annuler ma demande", lambda: self.change_leave("annulée"), danger=True)
        if self.user["role_nom"] in (ROLE_MANAGER, ROLE_RH):
            self._button(bar, "En traitement", lambda: self.change_leave("en traitement"))
            self._button(bar, "Approuver", lambda: self.change_leave("approuvée"))
            self._button(bar, "Refuser", lambda: self.change_leave("refusée"), danger=True)
        if self.user["role_nom"] == ROLE_RH:
            self._button(bar, "Paramètres congés", self.show_leave_settings)
        self._button(bar, "Exporter CSV", lambda: self._export_current("conges.csv"))

        filter_frame = ctk.CTkFrame(body, fg_color=COLOR_PANEL, corner_radius=14)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 10))
        filter_frame.grid_columnconfigure(1, weight=1)
        filter_frame.grid_columnconfigure(3, weight=1)
        search_var = tk.StringVar()
        status_var = tk.StringVar(value="Tous")
        type_var = tk.StringVar(value="Tous")
        ctk.CTkLabel(filter_frame, text="Recherche").grid(row=0, column=0, padx=(12, 5), pady=10, sticky="w")
        ctk.CTkEntry(filter_frame, textvariable=search_var, placeholder_text="Employé, motif...").grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Statut").grid(row=0, column=2, padx=(12, 5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, variable=status_var, values=["Tous", "soumise", "en traitement", "approuvée", "refusée", "annulée"]).grid(row=0, column=3, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Type").grid(row=0, column=4, padx=(12, 5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, variable=type_var, values=["Tous"] + TYPES_CONGE_MAROC).grid(row=0, column=5, padx=(5, 12), pady=10, sticky="ew")

        table = CardListFrame(body, [
            ("id", "ID", 50), ("employe", "Employé", 170), ("debut", "Début", 100), ("fin", "Fin", 100),
            ("jours", "Jours", 70), ("type", "Type", 220), ("statut", "Statut", 120),
            ("justif", "Justificatif", 220), ("motif", "Motif", 230)
        ])
        table.grid(row=2, column=0, sticky="nsew", padx=16, pady=(0, 16))
        body.grid_rowconfigure(2, weight=1)
        self.current_table = table

        def load_rows() -> None:
            base_params: list[Any] = []
            conditions = ["d.type_demande='CONGE'"]
            if self.user["role_nom"] == ROLE_EMPLOYE:
                conditions.append("d.employe_id=?")
                base_params.append(self.user["employe_id"])
            elif self.user["role_nom"] == ROLE_MANAGER:
                conditions.append("(d.employe_id=? OR e.manager_id=?)")
                base_params.extend([self.user["employe_id"], self.user["employe_id"]])
            if status_var.get() != "Tous":
                conditions.append("d.statut=?")
                base_params.append(status_var.get())
            if type_var.get() != "Tous":
                conditions.append("c.type_conge=?")
                base_params.append(type_var.get())
            term = search_var.get().strip()
            if term:
                conditions.append("(lower(e.nom || ' ' || e.prenom) LIKE lower(?) OR lower(d.motif) LIKE lower(?))")
                like = f"%{term}%"
                base_params.extend([like, like])
            where = "WHERE " + " AND ".join(conditions)
            rows = self.db.query(f"""
                SELECT d.id, e.prenom || ' ' || e.nom AS employe, c.date_debut, c.date_fin,
                       c.nombre_jours, c.type_conge, d.statut,
                       CASE WHEN COALESCE(c.justificatif_conge,'') != '' THEN c.justificatif_conge ELSE 'Aucun' END,
                       COALESCE(d.motif,'')
                FROM demande d
                JOIN demande_conge c ON c.demande_id=d.id
                JOIN employe e ON e.id=d.employe_id
                {where}
                ORDER BY d.id DESC
            """, tuple(base_params))
            formatted_rows = []
            for r in rows:
                item = list(tuple(r))
                item[4] = self._fmt_days(item[4])
                formatted_rows.append(tuple(item))
            table.set_rows(formatted_rows)

        ctk.CTkButton(filter_frame, text="Filtrer", command=load_rows).grid(row=0, column=6, padx=(4, 12), pady=10)
        load_rows()

    def show_leave_settings(self) -> None:
        if self.user["role_nom"] != ROLE_RH:
            self._error("Seul le Responsable RH peut accéder aux paramètres de congés.")
            return
        win = ctk.CTkToplevel(self)
        win.title("Paramètres congés")
        win.geometry("900x700")
        win.grab_set()
        win.grid_columnconfigure(0, weight=1)
        win.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(win, text="Paramètres des règles de congés", font=("Segoe UI", 20, "bold")).grid(row=0, column=0, sticky="w", padx=20, pady=(18, 8))

        params = self.service.get_leave_parameters()
        form = ctk.CTkFrame(win, corner_radius=14)
        form.grid(row=1, column=0, sticky="ew", padx=20, pady=(0, 12))
        for i in range(4):
            form.grid_columnconfigure(i, weight=1)
        entries: dict[str, ctk.CTkEntry] = {}
        fields = [
            ("employe_jours_par_mois", "Employés : jours/mois"),
            ("manager_jours_annuels", "Managers : jours/an"),
            ("rh_jours_annuels", "RH : jours/an"),
            ("quota_absence_hebdo_defaut", "Quota hebdo défaut"),
        ]
        for i, (key, label) in enumerate(fields):
            ctk.CTkLabel(form, text=label).grid(row=0, column=i, sticky="w", padx=12, pady=(12, 4))
            entry = ctk.CTkEntry(form)
            entry.insert(0, params.get(key, ""))
            entry.grid(row=1, column=i, sticky="ew", padx=12, pady=(0, 12))
            entries[key] = entry

        def save_params() -> None:
            try:
                self.service.set_leave_parameters({k: e.get().strip() for k, e in entries.items()}, self.user)
                self._info("Paramètres de congés enregistrés.")
                self.show_conges()
            except Exception as exc:
                self._error(exc)

        ctk.CTkButton(form, text="Enregistrer paramètres", command=save_params).grid(row=2, column=0, columnspan=4, sticky="e", padx=12, pady=(0, 12))

        quotas_panel = ctk.CTkFrame(win, corner_radius=14)
        quotas_panel.grid(row=2, column=0, sticky="nsew", padx=20, pady=(0, 20))
        quotas_panel.grid_columnconfigure(0, weight=1)
        quotas_panel.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(quotas_panel, text="Quotas de congés par semaine et par département — employés uniquement", font=("Segoe UI", 15, "bold")).grid(row=0, column=0, sticky="w", padx=14, pady=(14, 8))

        departments = self.service.get_departments()
        if not departments:
            ctk.CTkLabel(quotas_panel, text="Aucun département disponible.").grid(row=1, column=0, sticky="w", padx=14, pady=10)
            return
        dep_names = [f"{d['id']} - {d['nom']}" for d in departments]
        dep_var = tk.StringVar(value=dep_names[0])
        top = ctk.CTkFrame(quotas_panel, fg_color="transparent")
        top.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 8))
        ctk.CTkLabel(top, text="Département").pack(side="left", padx=(0, 8))
        ctk.CTkOptionMenu(top, values=dep_names, variable=dep_var).pack(side="left", padx=4)

        scroll = ctk.CTkScrollableFrame(quotas_panel, fg_color="transparent")
        scroll.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 12))
        quota_entries: dict[str, ctk.CTkEntry] = {}

        def selected_dep_id() -> int:
            return int(dep_var.get().split(" - ", 1)[0])

        def load_quotas() -> None:
            for child in scroll.winfo_children():
                child.destroy()
            quota_entries.clear()
            quotas = self.service.get_weekly_quotas(selected_dep_id())
            scroll.grid_columnconfigure(1, weight=1)
            for i, q in enumerate(quotas):
                ctk.CTkLabel(scroll, text=f"Semaine {q['semaine_debut']} → {q['semaine_fin']}").grid(row=i, column=0, sticky="w", padx=8, pady=5)
                entry = ctk.CTkEntry(scroll, width=90)
                entry.insert(0, str(q['quota_max']))
                entry.grid(row=i, column=1, sticky="w", padx=8, pady=5)
                ctk.CTkLabel(scroll, text=f"Utilisé : {q['quota_utilise']}", text_color=COLOR_MUTED).grid(row=i, column=2, sticky="w", padx=8, pady=5)
                quota_entries[q['semaine_debut']] = entry

        def save_quotas() -> None:
            try:
                values = {week: int(entry.get()) for week, entry in quota_entries.items()}
                self.service.set_weekly_quotas(selected_dep_id(), values, self.user)
                self._info("Quotas hebdomadaires enregistrés.")
                load_quotas()
            except Exception as exc:
                self._error(exc)

        ctk.CTkButton(top, text="Afficher", command=load_quotas).pack(side="left", padx=4)
        ctk.CTkButton(top, text="Enregistrer quotas", command=save_quotas).pack(side="left", padx=4)
        load_quotas()

    def add_leave_request(self) -> None:
        win = ctk.CTkToplevel(self)
        win.title("Nouvelle demande de congé")
        win.geometry("660x440")
        win.grab_set()
        win.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(win, text="Nouvelle demande de congé", font=("Segoe UI", 18, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(20, 12)
        )

        ctk.CTkLabel(win, text="Date début (AAAA-MM-JJ)").grid(row=1, column=0, sticky="w", padx=20, pady=6)
        date_debut = ctk.CTkEntry(win)
        date_debut.insert(0, today_str())
        date_debut.grid(row=1, column=1, sticky="ew", padx=(5, 20), pady=6)

        ctk.CTkLabel(win, text="Date fin (AAAA-MM-JJ)").grid(row=2, column=0, sticky="w", padx=20, pady=6)
        date_fin = ctk.CTkEntry(win)
        date_fin.insert(0, today_str())
        date_fin.grid(row=2, column=1, sticky="ew", padx=(5, 20), pady=6)

        demi_var = tk.BooleanVar(value=False)
        demi_check = ctk.CTkCheckBox(
            win,
            text="Demi-journée (0,5 jour) — utiliser une seule date",
            variable=demi_var,
        )
        demi_check.grid(row=3, column=1, sticky="w", padx=(5, 20), pady=6)

        ctk.CTkLabel(win, text="Type de congé").grid(row=4, column=0, sticky="w", padx=20, pady=6)
        type_var = tk.StringVar(value=TYPES_CONGE_MAROC[0])
        type_menu = ctk.CTkOptionMenu(win, values=TYPES_CONGE_MAROC, variable=type_var)
        type_menu.grid(row=4, column=1, sticky="ew", padx=(5, 20), pady=6)

        ctk.CTkLabel(win, text="Motif").grid(row=5, column=0, sticky="w", padx=20, pady=6)
        motif = ctk.CTkEntry(win)
        motif.grid(row=5, column=1, sticky="ew", padx=(5, 20), pady=6)

        selected_file = {"path": ""}
        file_label = ctk.CTkLabel(win, text="Aucun justificatif joint", text_color=COLOR_MUTED, anchor="w")
        file_label.grid(row=6, column=1, sticky="w", padx=(5, 20), pady=6)

        def choose_file() -> None:
            chosen = filedialog.askopenfilename(title="Choisir un justificatif de congé")
            if chosen:
                selected_file["path"] = chosen
                file_label.configure(text=Path(chosen).name)

        ctk.CTkLabel(win, text="Justificatif").grid(row=6, column=0, sticky="w", padx=20, pady=6)
        ctk.CTkButton(win, text="Joindre un fichier", command=choose_file).grid(row=7, column=1, sticky="w", padx=(5, 20), pady=6)

        result = {"submitted": False, "date_debut": "", "date_fin": "", "type_conge": "", "motif": "", "justificatif_source": "", "demi_journee": False}

        def submit() -> None:
            # Important : récupérer les valeurs AVANT de fermer la fenêtre.
            # Sinon Tkinter/CustomTkinter détruit les champs et .get() provoque
            # l'erreur "invalid command name ...ctkentry.!entry".
            debut_value = date_debut.get().strip()
            is_half_day = bool(demi_var.get())
            result.update({
                "submitted": True,
                "date_debut": debut_value,
                "date_fin": debut_value if is_half_day else date_fin.get().strip(),
                "type_conge": type_var.get(),
                "motif": motif.get().strip(),
                "justificatif_source": selected_file["path"],
                "demi_journee": is_half_day,
            })
            win.destroy()

        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.grid(row=8, column=0, columnspan=2, sticky="e", padx=20, pady=18)
        ctk.CTkButton(actions, text="Annuler", fg_color="#8792a5", command=win.destroy).pack(side="right", padx=4)
        ctk.CTkButton(actions, text="Soumettre", command=submit).pack(side="right", padx=4)
        self.wait_window(win)

        if not result["submitted"]:
            return
        try:
            justificatif = ""
            if result["justificatif_source"]:
                justificatif = copy_to_storage(result["justificatif_source"], STORAGE_DIR / "justificatifs_conges", "conge")
            self.service.create_leave_request(
                self.user,
                result["date_debut"],
                result["date_fin"],
                result["type_conge"],
                result["motif"],
                justificatif,
                result["demi_journee"],
            )
            self.show_conges()
        except Exception as exc:
            self._error(exc)

    def change_leave(self, status: str) -> None:
        demande_id = self._selected_required()
        if not demande_id:
            return
        if status in ("approuvée", "refusée", "annulée") and not self._confirm(f"Confirmer le statut : {status} ?"):
            return
        try:
            self.service.update_leave_status(demande_id, status, self.user, self._ask_comment())
            self.show_conges()
        except Exception as exc:
            self._error(exc)

    # ---------- notes de frais ----------
    def show_expenses(self) -> None:
        body = self._clear("Notes de frais", "Soumission, prévalidation manager, validation finale RH et remboursement")
        bar = self._make_button_bar(body)
        if self.user["role_nom"] in (ROLE_EMPLOYE, ROLE_MANAGER):
            self._button(bar, "Nouvelle note", self.add_expense)
        if self.user["role_nom"] == ROLE_MANAGER:
            self._button(bar, "En vérification", lambda: self.change_expense("en vérification"))
            self._button(bar, "Prévalider", lambda: self.change_expense("prévalidée manager"))
            self._button(bar, "Rejeter", lambda: self.change_expense("rejetée"), danger=True)
        if self.user["role_nom"] == ROLE_RH:
            self._button(bar, "Valider final RH", lambda: self.change_expense("validée RH"))
            self._button(bar, "Rejeter", lambda: self.change_expense("rejetée"), danger=True)
            self._button(bar, "Marquer remboursée", lambda: self.change_expense("remboursée"))
        self._button(bar, "Exporter CSV", lambda: self._export_current("notes_de_frais.csv"))

        filter_frame = ctk.CTkFrame(body, fg_color=COLOR_PANEL, corner_radius=14)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 10))
        filter_frame.grid_columnconfigure(1, weight=1)
        filter_frame.grid_columnconfigure(3, weight=1)
        search_var = tk.StringVar()
        status_var = tk.StringVar(value="Tous")
        ctk.CTkLabel(filter_frame, text="Recherche").grid(row=0, column=0, padx=(12,5), pady=10, sticky="w")
        ctk.CTkEntry(filter_frame, textvariable=search_var, placeholder_text="Employé, objet...").grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Statut").grid(row=0, column=2, padx=(12,5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, variable=status_var, values=["Tous", "soumise", "en vérification", "prévalidée manager", "validée RH", "rejetée", "remboursée"]).grid(row=0, column=3, padx=5, pady=10, sticky="ew")

        table = CardListFrame(body, [
            ("id", "ID", 50), ("employe", "Employé", 170), ("objet", "Objet", 160), ("montant", "Montant", 90),
            ("statut", "Statut", 160), ("date", "Soumission", 150), ("justif", "Justificatif", 110), ("desc", "Description", 280)
        ])
        table.grid(row=2, column=0, sticky="nsew", padx=16, pady=(0, 16))
        body.grid_rowconfigure(2, weight=1)
        self.current_table = table

        def load_rows() -> None:
            conditions = []
            params: list[Any] = []
            if self.user["role_nom"] == ROLE_EMPLOYE:
                conditions.append("n.employe_id=?")
                params.append(self.user["employe_id"])
            elif self.user["role_nom"] == ROLE_MANAGER:
                conditions.append("(n.employe_id=? OR e.manager_id=?)")
                params.extend([self.user["employe_id"], self.user["employe_id"]])
            if status_var.get() != "Tous":
                conditions.append("n.statut=?")
                params.append(status_var.get())
            term = search_var.get().strip()
            if term:
                conditions.append("(lower(e.nom || ' ' || e.prenom) LIKE lower(?) OR lower(n.objet) LIKE lower(?))")
                like = f"%{term}%"
                params.extend([like, like])
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = self.db.query(f"""
                SELECT n.id, e.prenom || ' ' || e.nom, n.objet, printf('%.2f', n.montant), n.statut,
                       n.date_soumission,
                       CASE WHEN COUNT(j.id) > 0 THEN 'Oui' ELSE 'Non' END AS justificatif,
                       COALESCE(n.description,'')
                FROM note_de_frais n
                JOIN employe e ON e.id=n.employe_id
                LEFT JOIN justificatif j ON j.note_id = n.id
                {where}
                GROUP BY n.id
                ORDER BY n.id DESC
            """, tuple(params))
            table.set_rows([tuple(r) for r in rows])

        ctk.CTkButton(filter_frame, text="Filtrer", command=load_rows).grid(row=0, column=4, padx=(4,12), pady=10)
        load_rows()

    def add_expense(self) -> None:
        data = self._simple_form("Nouvelle note de frais", [
            ("objet", "Objet", ""),
            ("montant", "Montant", "0"),
            ("description", "Description", ""),
        ], "Soumettre")
        if not data:
            return
        try:
            amount = float(data["montant"].replace(",", "."))
            if amount <= 0:
                raise ValueError("Le montant doit être supérieur à 0 DH.")
            if amount > 10000:
                raise ValueError("Le montant dépasse le plafond autorisé de 10 000 DH.")
            messagebox.showinfo(
                "Justificatif obligatoire",
                "Pour soumettre une note de frais, vous devez obligatoirement joindre un justificatif."
            )
            selected = filedialog.askopenfilename(
                title="Choisir le justificatif obligatoire",
                filetypes=[
                    ("Documents justificatifs", "*.pdf *.png *.jpg *.jpeg"),
                    ("Tous les fichiers", "*.*"),
                ],
            )
            if not selected:
                messagebox.showwarning(
                    "Soumission annulée",
                    "La note de frais n'a pas été créée : le justificatif est obligatoire."
                )
                return
            receipt = copy_to_storage(selected, STORAGE_DIR / "justificatifs", "note")
            self.service.create_expense(self.user, data["objet"], data["description"], amount, receipt)
            self.show_expenses()
        except Exception as exc:
            self._error(exc)

    def change_expense(self, status: str) -> None:
        note_id = self._selected_required()
        if not note_id:
            return
        if status in ("prévalidée manager", "validée RH", "rejetée", "remboursée") and not self._confirm(f"Confirmer : {status} ?"):
            return
        try:
            self.service.update_expense_status(note_id, status, self.user, self._ask_comment())
            self.show_expenses()
        except Exception as exc:
            self._error(exc)

    # ---------- documents RH ----------
    def show_documents(self) -> None:
        body = self._clear("Documents RH", "Demande, préparation, upload des bulletins de paie et récupération physique")
        bar = self._make_button_bar(body)
        if self.user["role_nom"] in (ROLE_EMPLOYE, ROLE_MANAGER):
            self._button(bar, "Demander document", self.add_document_request)
            self._button(bar, "Marquer récupéré", lambda: self.change_document("récupérée"))
        if self.user["role_nom"] == ROLE_RH:
            self._button(bar, "Traiter", lambda: self.change_document("traitée"))
            self._button(bar, "Marquer prêt", lambda: self.change_document("prête"))
            self._button(bar, "Uploader bulletin de paie", self.upload_document)
            self._button(bar, "Rejeter", lambda: self.change_document("rejetée"), danger=True)
            self._button(bar, "Document récupéré", lambda: self.change_document("récupérée"))
        self._button(bar, "Exporter CSV", lambda: self._export_current("documents_rh.csv"))

        filter_frame = ctk.CTkFrame(body, fg_color=COLOR_PANEL, corner_radius=14)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 10))
        filter_frame.grid_columnconfigure(1, weight=1)
        search_var = tk.StringVar()
        status_var = tk.StringVar(value="Tous")
        type_var = tk.StringVar(value="Tous")
        ctk.CTkLabel(filter_frame, text="Recherche").grid(row=0, column=0, padx=(12,5), pady=10, sticky="w")
        ctk.CTkEntry(filter_frame, textvariable=search_var, placeholder_text="Employé, motif...").grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Statut").grid(row=0, column=2, padx=(12,5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, variable=status_var, values=["Tous", "soumise", "traitée", "prête", "rejetée", "récupérée"]).grid(row=0, column=3, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Type").grid(row=0, column=4, padx=(12,5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, variable=type_var, values=["Tous"] + TYPES_DOCUMENT_RH).grid(row=0, column=5, padx=5, pady=10, sticky="ew")

        table = CardListFrame(body, [
            ("id", "ID", 50), ("employe", "Employé", 170), ("type", "Document", 180), ("statut", "Statut", 120),
            ("fichier", "Fichier", 260), ("recup", "Récupéré", 90), ("motif", "Motif", 230)
        ])
        table.grid(row=2, column=0, sticky="nsew", padx=16, pady=(0, 16))
        body.grid_rowconfigure(2, weight=1)
        self.current_table = table

        def load_rows() -> None:
            conditions = ["d.type_demande='DOCUMENT'"]
            params: list[Any] = []
            if self.user["role_nom"] in (ROLE_EMPLOYE, ROLE_MANAGER):
                conditions.append("d.employe_id=?")
                params.append(self.user["employe_id"])
            if status_var.get() != "Tous":
                conditions.append("d.statut=?")
                params.append(status_var.get())
            if type_var.get() != "Tous":
                conditions.append("dd.type_document=?")
                params.append(type_var.get())
            term = search_var.get().strip()
            if term:
                conditions.append("(lower(e.nom || ' ' || e.prenom) LIKE lower(?) OR lower(d.motif) LIKE lower(?))")
                like = f"%{term}%"
                params.extend([like, like])
            where = "WHERE " + " AND ".join(conditions)
            rows = self.db.query(f"""
                SELECT d.id, e.prenom || ' ' || e.nom, dd.type_document, d.statut,
                       COALESCE(dd.fichier_document,''), CASE WHEN dd.document_recupere=1 THEN 'Oui' ELSE 'Non' END,
                       COALESCE(d.motif,'')
                FROM demande d
                JOIN demande_document dd ON dd.demande_id=d.id
                JOIN employe e ON e.id=d.employe_id
                {where}
                ORDER BY d.id DESC
            """, tuple(params))
            table.set_rows([tuple(r) for r in rows])

        ctk.CTkButton(filter_frame, text="Filtrer", command=load_rows).grid(row=0, column=6, padx=(4,12), pady=10)
        load_rows()

    def add_document_request(self) -> None:
        win = ctk.CTkToplevel(self)
        win.title("Demander un document RH")
        win.geometry("620x260")
        win.grab_set()
        win.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(win, text="Demander un document RH", font=("Segoe UI", 18, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(20, 12)
        )

        ctk.CTkLabel(win, text="Type document").grid(row=1, column=0, sticky="w", padx=20, pady=6)
        type_var = tk.StringVar(value=TYPES_DOCUMENT_RH[0])
        ctk.CTkOptionMenu(win, values=TYPES_DOCUMENT_RH, variable=type_var).grid(
            row=1, column=1, sticky="ew", padx=(5, 20), pady=6
        )

        ctk.CTkLabel(win, text="Motif").grid(row=2, column=0, sticky="w", padx=20, pady=6)
        motif = ctk.CTkEntry(win)
        motif.grid(row=2, column=1, sticky="ew", padx=(5, 20), pady=6)

        result = {"submitted": False, "type_document": "", "motif": ""}

        def submit() -> None:
            # Récupérer les valeurs avant destruction de la fenêtre modale.
            result.update({
                "submitted": True,
                "type_document": type_var.get(),
                "motif": motif.get().strip(),
            })
            win.destroy()

        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.grid(row=3, column=0, columnspan=2, sticky="e", padx=20, pady=18)
        ctk.CTkButton(actions, text="Annuler", fg_color="#8792a5", command=win.destroy).pack(side="right", padx=4)
        ctk.CTkButton(actions, text="Soumettre", command=submit).pack(side="right", padx=4)
        self.wait_window(win)

        if not result["submitted"]:
            return
        try:
            self.service.create_document_request(self.user, result["type_document"], result["motif"])
            self.show_documents()
        except Exception as exc:
            self._error(exc)

    def change_document(self, status: str) -> None:
        demande_id = self._selected_required()
        if not demande_id:
            return
        try:
            self.service.update_document_status(demande_id, status, self.user, self._ask_comment())
            self.show_documents()
        except Exception as exc:
            self._error(exc)

    def upload_document(self) -> None:
        demande_id = self._selected_required()
        if not demande_id:
            return
        row = self.db.query_one("""
            SELECT dd.type_document
            FROM demande_document dd
            WHERE dd.demande_id=?
        """, (demande_id,))
        if not row:
            self._error("Demande document introuvable.")
            return
        if row["type_document"] not in DOCUMENTS_UPLOAD_AUTORISES:
            self._error("L'upload est autorisé uniquement pour les bulletins de paie. Pour les autres documents, utilisez simplement « Marquer prêt ».")
            return
        selected = filedialog.askopenfilename(title="Choisir le bulletin de paie")
        if not selected:
            return
        try:
            path = copy_to_storage(selected, STORAGE_DIR / "documents_rh", "bulletin_paie")
            self.service.update_document_status(demande_id, "prête", self.user, "Bulletin de paie uploadé", path)
            self.show_documents()
        except Exception as exc:
            self._error(exc)

    # ---------- matériel ----------
    def show_material(self) -> None:
        if self.user["role_nom"] == ROLE_EMPLOYE:
            body = self._clear("Matériel", "Ce module est réservé au Manager et au Responsable RH")
            ctk.CTkLabel(body, text="Le compte employé n'a pas accès aux demandes ni aux affectations de matériel.", text_color=COLOR_MUTED).grid(
                row=0, column=0, sticky="w", padx=20, pady=20
            )
            return

        if self.user["role_nom"] == ROLE_MANAGER:
            body = self._clear(
                "Demandes d’attribution matériel",
                "Le manager peut uniquement demander l’attribution d’un matériel à un employé. La décision et l’affectation finale sont faites par le RH."
            )
            body.grid_rowconfigure(1, weight=1)
            self._material_requests_tab(body)
            return

        body = self._clear("Matériel & affectations", "Demandes, inventaire, affectation, retour et maintenance")
        notebook = ctk.CTkTabview(body)
        notebook.grid(row=0, column=0, sticky="nsew", padx=16, pady=16)
        body.grid_rowconfigure(0, weight=1)
        demandes_tab = notebook.add("Demandes")
        stock_tab = notebook.add("Inventaire")
        self._material_requests_tab(demandes_tab)
        self._material_stock_tab(stock_tab)

    def _material_requests_tab(self, tab: tk.Widget) -> None:
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)
        bar = ctk.CTkFrame(tab, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", padx=8, pady=8)
        if self.user["role_nom"] == ROLE_MANAGER:
            self._button(bar, "Demander attribution", self.add_material_request)
        elif self.user["role_nom"] == ROLE_RH:
            self._button(bar, "En traitement", lambda: self.change_material_request("en traitement"))
            self._button(bar, "Accepter RH", lambda: self.change_material_request("acceptée RH"))
            self._button(bar, "Refuser RH", lambda: self.change_material_request("refusée RH"), danger=True)
            self._button(bar, "Affecter matériel disponible", self.assign_selected_material)
        self._button(bar, "Exporter CSV", lambda: self._export_current("demandes_materiel.csv"))
        table = CardListFrame(tab, [
            ("id", "ID", 50), ("employe", "Employé concerné", 170), ("type", "Type", 160), ("besoin", "Besoin", 230),
            ("date", "Date besoin", 110), ("statut", "Statut", 140), ("demandeur", "Demandée par", 180), ("materiel", "Matériel affecté", 180)
        ], height=12)
        table.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.current_table = table
        if self.user["role_nom"] == ROLE_MANAGER:
            where = "WHERE d.type_demande='MATERIEL' AND d.demandeur_id=?"
            params = (self.user["id"],)
        else:
            where = "WHERE d.type_demande='MATERIEL'"
            params = ()
        rows = self.db.query(f"""
            SELECT d.id, e.prenom || ' ' || e.nom, dm.type_materiel, COALESCE(dm.description_besoin,''),
                   COALESCE(dm.date_besoin,''), d.statut, COALESCE(u.email, ''),
                   COALESCE(m.inventaire || ' - ' || m.designation, '')
            FROM demande d
            JOIN demande_materiel dm ON dm.demande_id=d.id
            JOIN employe e ON e.id=d.employe_id
            LEFT JOIN utilisateur u ON u.id=d.demandeur_id
            LEFT JOIN materiel m ON m.id=dm.materiel_id
            {where}
            ORDER BY d.id DESC
        """, params)
        table.set_rows([tuple(r) for r in rows])
    def _material_stock_tab(self, tab: tk.Widget) -> None:
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)
        bar = ctk.CTkFrame(tab, fg_color="transparent")
        bar.grid(row=0, column=0, sticky="ew", padx=8, pady=8)
        if self.user["role_nom"] == ROLE_RH:
            self._button(bar, "Ajouter matériel", self.add_material)
            self._button(bar, "Retour matériel", self.return_selected_material)
            self._button(bar, "Mettre en maintenance", self.maintenance_selected_material)
            self._button(bar, "Ouvrir bon PDF", self.open_assignment_pdf)
            self._button(bar, "Confirmer réception", self.confirm_material_reception)
            self._button(bar, "Joindre bon signé", self.attach_signed_assignment_form)
        self._button(bar, "Exporter CSV", lambda: self._export_current("inventaire_materiel.csv"))
        table = CardListFrame(tab, [
            ("id", "ID", 50), ("inventaire", "Inventaire", 140), ("designation", "Désignation", 220),
            ("categorie", "Catégorie", 130), ("etat", "État physique", 130), ("statut", "Statut", 130),
            ("reception", "Réception", 130), ("date_conf", "Date confirmation", 150), ("bon_signe", "Bon signé", 100)
        ], height=12)
        table.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))
        self.material_stock_table = table
        rows = self.db.query("""
            SELECT m.id, m.inventaire, m.designation, COALESCE(m.categorie,''), m.etat_physique, m.statut_materiel,
                   CASE
                       WHEN a.confirmation_reception=1 THEN 'confirmée'
                       WHEN a.id IS NOT NULL THEN 'à confirmer'
                       ELSE ''
                   END AS reception,
                   COALESCE(a.date_confirmation, '') AS date_confirmation,
                   CASE WHEN COALESCE(a.bon_signe_path,'') <> '' THEN 'Oui' ELSE 'Non' END AS bon_signe
            FROM materiel m
            LEFT JOIN affectation_materiel a
                   ON a.materiel_id=m.id AND a.statut_affectation='active'
            ORDER BY m.id DESC
        """)
        table.set_rows([tuple(r) for r in rows])

    def add_material_request(self) -> None:
        if self.user["role_nom"] == ROLE_MANAGER:
            team = self.db.query(
                "SELECT id, prenom || ' ' || nom AS nom, matricule FROM employe WHERE manager_id=? ORDER BY nom",
                (self.user["employe_id"],),
            )
            if not team:
                self._info("Aucun employé n'est rattaché à votre compte manager.")
                return
            team_text = "\n".join([f"{e['id']} - {e['nom']} ({e['matricule']})" for e in team])
            target_id = simpledialog.askinteger(
                "Employé concerné",
                f"Entrez l'ID de l'employé concerné :\n\n{team_text}",
                parent=self,
            )
            if not target_id:
                return
            data = self._simple_form("Demande d’attribution matériel", [
                ("type_materiel", "Type matériel", "PC portable"),
                ("description", "Description du besoin", ""),
                ("date_besoin", "Date besoin (AAAA-MM-JJ)", today_str()),
            ], "Envoyer au RH")
            if not data:
                return
            try:
                self.service.create_material_request(
                    self.user,
                    data["type_materiel"],
                    data["description"],
                    data["date_besoin"],
                    target_id,
                )
                self.show_material()
            except Exception as exc:
                self._error(exc)
            return

        data = self._simple_form("Demander du matériel", [
            ("type_materiel", "Type matériel", "PC portable"),
            ("description", "Description du besoin", ""),
            ("date_besoin", "Date besoin (AAAA-MM-JJ)", today_str()),
        ], "Soumettre")
        if not data:
            return
        try:
            self.service.create_material_request(self.user, data["type_materiel"], data["description"], data["date_besoin"])
            self.show_material()
        except Exception as exc:
            self._error(exc)
    def change_material_request(self, status: str) -> None:
        demande_id = self._selected_required()
        if not demande_id:
            return
        try:
            self.service.update_material_request_status(demande_id, status, self.user, self._ask_comment())
            self.show_material()
        except Exception as exc:
            self._error(exc)

    def assign_selected_material(self) -> None:
        demande_id = self._selected_required()
        if not demande_id:
            return
        available = self.db.query("SELECT id, inventaire, designation FROM materiel WHERE statut_materiel='disponible' ORDER BY inventaire")
        if not available:
            self._info("Aucun matériel disponible.")
            return
        choices = "\n".join([f"{r['id']} - {r['inventaire']} - {r['designation']}" for r in available])
        materiel_id = simpledialog.askinteger("Affecter matériel", f"Entrez l'ID du matériel disponible :\n\n{choices}", parent=self)
        if not materiel_id:
            return
        try:
            pdf_path = self.service.assign_material(demande_id, materiel_id, self.user, self._ask_comment())
            self.show_material()
            self._info(f"Matériel affecté. Bon d'attribution PDF généré :\n{pdf_path}")
        except Exception as exc:
            self._error(exc)

    def _open_path(self, path: str) -> None:
        if not path:
            self._info("Aucun fichier disponible.")
            return
        file_path = Path(path)
        if not file_path.exists():
            self._error(f"Fichier introuvable : {file_path}")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(file_path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                import subprocess
                subprocess.Popen(["open", str(file_path)])
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(file_path)])
        except Exception as exc:
            self._error(exc)

    def _active_assignment_for_selected_material(self) -> dict[str, Any] | None:
        table = getattr(self, "material_stock_table", None)
        materiel_id = self._selected_required(table)
        if not materiel_id:
            return None
        row = self.db.query_one(
            """
            SELECT * FROM affectation_materiel
            WHERE materiel_id=? AND statut_affectation='active'
            ORDER BY id DESC LIMIT 1
            """,
            (materiel_id,),
        )
        if not row:
            self._info("Aucune affectation active trouvée pour ce matériel.")
            return None
        return dict(row)

    def open_assignment_pdf(self) -> None:
        aff = self._active_assignment_for_selected_material()
        if not aff:
            return
        self._open_path(aff.get("bon_pdf_path") or "")

    def confirm_material_reception(self) -> None:
        table = getattr(self, "material_stock_table", None)
        materiel_id = self._selected_required(table)
        if not materiel_id:
            return
        if not self._confirm("Confirmer que l'employé a reçu le matériel sélectionné ?"):
            return
        signed_path = ""
        if self._confirm("Voulez-vous joindre maintenant le bon signé scanné ?"):
            selected = filedialog.askopenfilename(
                title="Choisir le bon signé",
                filetypes=[("Documents", "*.pdf *.png *.jpg *.jpeg"), ("Tous les fichiers", "*.*")],
            )
            if selected:
                signed_path = copy_to_storage(selected, STORAGE_DIR / "bons_attribution", prefix="bon_signe")
        try:
            self.service.confirm_material_reception(materiel_id, self.user, signed_path or None)
            self.show_material()
            self._info("Réception du matériel confirmée.")
        except Exception as exc:
            self._error(exc)

    def attach_signed_assignment_form(self) -> None:
        table = getattr(self, "material_stock_table", None)
        materiel_id = self._selected_required(table)
        if not materiel_id:
            return
        selected = filedialog.askopenfilename(
            title="Choisir le bon d'attribution signé",
            filetypes=[("Documents", "*.pdf *.png *.jpg *.jpeg"), ("Tous les fichiers", "*.*")],
        )
        if not selected:
            return
        try:
            stored_path = copy_to_storage(selected, STORAGE_DIR / "bons_attribution", prefix="bon_signe")
            self.service.attach_signed_assignment_form(materiel_id, self.user, stored_path)
            self.show_material()
            self._info("Bon signé ajouté et réception confirmée.")
        except Exception as exc:
            self._error(exc)

    def add_material(self) -> None:
        data = self._simple_form("Ajouter matériel", [
            ("inventaire", "Numéro inventaire", "INV-"),
            ("designation", "Désignation", ""),
            ("categorie", "Catégorie", "Informatique"),
            ("etat", "État physique", "en marche"),
        ])
        if not data:
            return
        if data["etat"] not in ETAT_PHYSIQUE_MATERIEL:
            self._error("État physique invalide. Utilisez : en marche, endommagé ou en maintenance.")
            return
        statut = "en maintenance" if data["etat"] == "en maintenance" else "disponible"
        try:
            self.db.execute(
                "INSERT INTO materiel(inventaire, designation, categorie, etat_physique, statut_materiel) VALUES (?, ?, ?, ?, ?)",
                (data["inventaire"], data["designation"], data["categorie"], data["etat"], statut),
            )
            mat_id = self.db.query_one("SELECT last_insert_rowid() AS id")["id"]
            self.service.history.record("materiel", mat_id, None, statut, "Création matériel", self.user["id"], data["designation"])
            self.show_material()
        except Exception as exc:
            self._error(exc)

    def return_selected_material(self) -> None:
        table = getattr(self, "material_stock_table", None)
        materiel_id = self._selected_required(table)
        if not materiel_id:
            return
        etat = simpledialog.askstring("Retour matériel", "État retour : en marche / endommagé / en maintenance", parent=self, initialvalue="en marche") or "en marche"
        try:
            self.service.return_material(materiel_id, self.user, etat, self._ask_comment())
            self.show_material()
        except Exception as exc:
            self._error(exc)

    def maintenance_selected_material(self) -> None:
        table = getattr(self, "material_stock_table", None)
        materiel_id = self._selected_required(table)
        if not materiel_id:
            return
        problem = simpledialog.askstring("Maintenance", "Décrire le problème :", parent=self) or "Maintenance demandée"
        try:
            self.service.send_material_to_maintenance(materiel_id, self.user, problem)
            self.show_material()
        except Exception as exc:
            self._error(exc)

    # ---------- employés ----------
    def show_employees(self) -> None:
        body = self._clear("Employés", "Gestion des informations professionnelles")
        bar = self._make_button_bar(body)
        self._button(bar, "Ajouter employé", self.add_employee)
        self._button(bar, "Modifier employé", self.edit_employee)
        self._button(bar, "Supprimer employé", self.delete_employee, danger=True)
        self._button(bar, "Importer Excel/BDD", self.import_employees_file)
        self._button(bar, "Modèle import", self.export_employee_import_template)
        self._button(bar, "Exporter CSV", lambda: self._export_current("employes.csv"))

        filter_frame = ctk.CTkFrame(body, fg_color=COLOR_PANEL, corner_radius=14)
        filter_frame.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 10))
        filter_frame.grid_columnconfigure(1, weight=1)
        filter_frame.grid_columnconfigure(3, weight=1)
        search_var = tk.StringVar()
        dept_var = tk.StringVar(value="Tous")
        departments = ["Tous"] + [d["nom"] for d in self.service.get_departments()]
        ctk.CTkLabel(filter_frame, text="Recherche").grid(row=0, column=0, padx=(12, 5), pady=10, sticky="w")
        ctk.CTkEntry(filter_frame, textvariable=search_var, placeholder_text="Nom, matricule, email...").grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkLabel(filter_frame, text="Département").grid(row=0, column=2, padx=(12, 5), pady=10, sticky="w")
        ctk.CTkOptionMenu(filter_frame, values=departments, variable=dept_var).grid(row=0, column=3, padx=5, pady=10, sticky="ew")

        table = CardListFrame(body, [
            ("id", "ID", 50), ("matricule", "Matricule", 100), ("nom", "Nom", 120), ("prenom", "Prénom", 120),
            ("email", "Email", 190), ("tel", "Téléphone", 120), ("dept", "Département", 150), ("poste", "Poste", 160), ("statut", "Statut", 90)
        ])
        table.grid(row=2, column=0, sticky="nsew", padx=16, pady=(0, 16))
        body.grid_rowconfigure(2, weight=1)
        self.current_table = table

        def load_rows() -> None:
            conditions = []
            params: list[Any] = []
            term = search_var.get().strip()
            if term:
                conditions.append("(lower(e.nom) LIKE lower(?) OR lower(e.prenom) LIKE lower(?) OR lower(e.matricule) LIKE lower(?) OR lower(e.email_professionnel) LIKE lower(?))")
                like = f"%{term}%"
                params.extend([like, like, like, like])
            if dept_var.get() != "Tous":
                conditions.append("d.nom=?")
                params.append(dept_var.get())
            where = "WHERE " + " AND ".join(conditions) if conditions else ""
            rows = self.db.query(f"""
                SELECT e.id, e.matricule, e.nom, e.prenom, e.email_professionnel, COALESCE(e.telephone,''),
                       COALESCE(d.nom,''), COALESCE(p.intitule,''), e.statut
                FROM employe e
                LEFT JOIN departement d ON d.id=e.departement_id
                LEFT JOIN poste p ON p.id=e.poste_id
                {where}
                ORDER BY e.id DESC
            """, tuple(params))
            table.set_rows([tuple(r) for r in rows])

        ctk.CTkButton(filter_frame, text="Filtrer", command=load_rows).grid(row=0, column=4, padx=(4, 12), pady=10)
        load_rows()

    def add_employee(self) -> None:
        data = self._choice_form("Ajouter employé", [
            ("matricule", "Matricule", "EMP"), ("nom", "Nom", ""), ("prenom", "Prénom", ""),
            ("email", "Email professionnel", ""), ("telephone", "Téléphone", ""), ("adresse", "Adresse", ""),
            ("departement", "Département", "Opérations"), ("poste", "Poste", "Employé administratif"),
        ], [("statut", "Statut", ["actif", "inactif"], "actif")])
        if not data:
            return
        try:
            dept_id = self.service.create_or_get_department(data["departement"])
            poste_id = self.service.create_or_get_poste(data["poste"])
            self.db.execute(
                """INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel, date_embauche, statut, departement_id, poste_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (data["matricule"], data["nom"], data["prenom"], data["telephone"], data["adresse"], data["email"].lower(), today_str(), data["statut"], dept_id, poste_id),
            )
            emp_id = self.db.query_one("SELECT last_insert_rowid() AS id")["id"]
            self.db.execute("INSERT INTO solde_conge(employe_id, annee, jours_acquis, jours_pris, jours_restants) VALUES (?, ?, 18, 0, 18)", (emp_id, int(today_str()[:4])))
            self.service.history.record("employe", emp_id, None, data["statut"], "Création employé", self.user["id"], data["email"])
            self.show_employees()
        except Exception as exc:
            self._error(exc)

    def edit_employee(self) -> None:
        employe_id = self._selected_required()
        if not employe_id:
            return
        row = self.db.query_one("""
            SELECT e.*, COALESCE(d.nom, '') AS departement, COALESCE(p.intitule, '') AS poste
            FROM employe e
            LEFT JOIN departement d ON d.id=e.departement_id
            LEFT JOIN poste p ON p.id=e.poste_id
            WHERE e.id=?
        """, (employe_id,))
        if not row:
            self._error("Employé introuvable.")
            return
        data = self._choice_form("Modifier employé", [
            ("matricule", "Matricule", row["matricule"] or ""), ("nom", "Nom", row["nom"] or ""), ("prenom", "Prénom", row["prenom"] or ""),
            ("email", "Email professionnel", row["email_professionnel"] or ""), ("telephone", "Téléphone", row["telephone"] or ""),
            ("adresse", "Adresse", row["adresse"] or ""), ("departement", "Département", row["departement"] or ""),
            ("poste", "Poste", row["poste"] or ""),
        ], [("statut", "Statut", ["actif", "inactif", "suspendu", "supprimé"], row["statut"] or "actif")])
        if not data:
            return
        try:
            self.service.update_employee(employe_id, data)
            self.service.history.record("employe", employe_id, row["statut"], data["statut"], "Modification employé", self.user["id"], data["email"])
            self.show_employees()
        except Exception as exc:
            self._error(exc)

    def delete_employee(self) -> None:
        employe_id = self._selected_required()
        if not employe_id:
            return
        if not messagebox.askyesno("Confirmation", "Supprimer cet employé ? S'il possède un historique, il sera archivé au lieu d'être effacé."):
            return
        try:
            msg = self.service.delete_employee(employe_id, self.user.get("employe_id"))
            self.service.history.record("employe", employe_id, None, "supprimé", "Suppression/archivage employé", self.user["id"], msg)
            self._info(msg)
            self.show_employees()
        except Exception as exc:
            self._error(exc)


    def import_employees_file(self) -> None:
        file_path = filedialog.askopenfilename(
            title="Importer une liste d'employés",
            filetypes=[
                ("Fichiers employés", "*.xlsx *.xlsm *.csv *.db *.sqlite *.sqlite3 *.bdd"),
                ("Excel", "*.xlsx *.xlsm"),
                ("CSV", "*.csv"),
                ("Base SQLite", "*.db *.sqlite *.sqlite3 *.bdd"),
                ("Tous les fichiers", "*.*"),
            ],
        )
        if not file_path:
            return
        try:
            preview = self.service.preview_employees_import(file_path, self.user)
        except Exception as exc:
            self._error(exc)
            return

        win = ctk.CTkToplevel(self)
        win.title("Prévisualisation import employés")
        win.geometry("820x620")
        win.grab_set()
        win.grid_columnconfigure(0, weight=1)
        win.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(win, text="Prévisualisation avant import", font=("Segoe UI", 20, "bold")).grid(row=0, column=0, sticky="w", padx=20, pady=(20, 8))

        cards = ctk.CTkFrame(win, fg_color="transparent")
        cards.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 10))
        for i in range(4):
            cards.grid_columnconfigure(i, weight=1)
        indicators = [
            ("Lignes lues", preview['total_lu']),
            ("À créer", preview['a_creer']),
            ("À mettre à jour", preview['a_mettre_a_jour']),
            ("Erreurs / ignorées", len(preview.get('erreurs', [])) + preview.get('ignores', 0)),
        ]
        for i, (label, value) in enumerate(indicators):
            card = ctk.CTkFrame(cards, corner_radius=14, fg_color=COLOR_PANEL, border_width=1, border_color=COLOR_BORDER)
            card.grid(row=0, column=i, sticky="ew", padx=6)
            ctk.CTkLabel(card, text=str(value), font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=14, pady=(12, 0))
            ctk.CTkLabel(card, text=label, text_color=COLOR_MUTED).pack(anchor="w", padx=14, pady=(0, 12))

        details = ctk.CTkScrollableFrame(win, corner_radius=14)
        details.grid(row=2, column=0, sticky="nsew", padx=20, pady=(0, 12))
        lines = [
            f"Source : {preview['source']}",
            f"Départements à créer : {', '.join(preview.get('departements_a_creer') or []) or 'Aucun'}",
            f"Postes à créer : {', '.join(preview.get('postes_a_creer') or []) or 'Aucun'}",
            f"Managers non trouvés : {preview.get('managers_non_trouves', 0)}",
            "",
            "Exemples de lignes reconnues :",
            *(preview.get('exemples') or ["Aucun exemple disponible"]),
            "",
            "Erreurs détectées :",
            *(preview.get('erreurs') or ["Aucune erreur détectée"]),
        ]
        for i, line in enumerate(lines):
            ctk.CTkLabel(details, text=line, anchor="w", justify="left", wraplength=730).grid(row=i, column=0, sticky="w", padx=12, pady=3)

        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.grid(row=3, column=0, sticky="e", padx=20, pady=(0, 18))
        confirmed = {"value": False}
        def confirm() -> None:
            confirmed["value"] = True
            win.destroy()
        ctk.CTkButton(actions, text="Annuler", fg_color="#8792a5", command=win.destroy).pack(side="right", padx=4)
        ctk.CTkButton(actions, text="Confirmer l’import", command=confirm).pack(side="right", padx=4)
        self.wait_window(win)

        if not confirmed["value"]:
            return
        try:
            result = self.service.import_employees_from_file(file_path, self.user)
            msg = (
                f"Import terminé depuis : {result['source']}\n\n"
                f"Lignes lues : {result['total_lu']}\n"
                f"Employés créés : {result['crees']}\n"
                f"Employés mis à jour : {result['mis_a_jour']}\n"
                f"Managers rattachés : {result.get('managers_rattaches', 0)}\n"
                f"Lignes ignorées : {result['ignores']}"
            )
            errors = result.get("erreurs") or []
            if errors:
                preview_errors = "\n".join(errors[:8])
                if len(errors) > 8:
                    preview_errors += f"\n... et {len(errors) - 8} autre(s) erreur(s)."
                msg += "\n\nDétails :\n" + preview_errors
            messagebox.showinfo("Import employés", msg)
            self.show_employees()
        except Exception as exc:
            self._error(exc)

    def export_employee_import_template(self) -> None:
        headers = [
            "matricule", "nom", "prenom", "email", "telephone", "adresse",
            "departement", "poste", "date_embauche", "statut",
            "manager_matricule", "manager_email",
        ]
        sample_rows = [
            ["EMP002", "El Amrani", "Sara", "sara.elamrani@entreprise.ma", "0600000004", "Marrakech", "Opérations", "Assistante administrative", today_str(), "actif", "MGR001", "manager@test.com"],
            ["EMP003", "Ait Said", "Youssef", "youssef.aitsaid@entreprise.ma", "0600000005", "Casablanca", "Finance", "Comptable", today_str(), "actif", "MGR001", "manager@test.com"],
        ]
        path = export_rows_to_csv("modele_import_employes.csv", headers, sample_rows)
        self._info(
            "Modèle CSV créé :\n"
            f"{path}\n\n"
            "Tu peux aussi utiliser un fichier Excel .xlsx avec les mêmes colonnes."
        )

    # ---------- utilisateurs ----------
    def show_users(self) -> None:
        body = self._clear("Utilisateurs & rôles", "Création, activation, désactivation et association employé")
        bar = self._make_button_bar(body)
        self._button(bar, "Créer utilisateur", self.add_user)
        self._button(bar, "Modifier utilisateur", self.edit_user)
        self._button(bar, "Supprimer utilisateur", self.delete_user, danger=True)
        self._button(bar, "Activer/Désactiver", self.toggle_user)
        self._button(bar, "Exporter CSV", lambda: self._export_current("utilisateurs.csv"))
        table = CardListFrame(body, [
            ("id", "ID", 50), ("email", "Email", 220), ("role", "Rôle", 150), ("employe", "Employé", 170),
            ("actif", "Actif", 70), ("date", "Création", 150), ("last", "Dernière connexion", 150)
        ])
        table.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.current_table = table
        rows = self.db.query("""
            SELECT u.id, u.email, r.nom, COALESCE(e.prenom || ' ' || e.nom, ''),
                   CASE WHEN u.actif=1 THEN 'Oui' ELSE 'Non' END, u.date_creation, COALESCE(u.derniere_connexion,'')
            FROM utilisateur u
            JOIN role r ON r.id=u.role_id
            LEFT JOIN employe e ON e.id=u.employe_id
            ORDER BY u.id DESC
        """)
        table.set_rows([tuple(r) for r in rows])

    def add_user(self) -> None:
        employee_values, employee_map = self._employee_choice_values()
        data = self._choice_form("Créer utilisateur", [
            ("email", "Email", ""), ("password", "Mot de passe", "123456"),
        ], [
            ("role", "Rôle", list(ROLES), ROLE_EMPLOYE),
            ("employee_choice", "Employé associé", employee_values, employee_values[0]),
            ("active", "Actif", ["Oui", "Non"], "Oui"),
        ])
        if not data:
            return
        try:
            emp_id = employee_map.get(data["employee_choice"])
            self.service.create_user(data["email"], data["password"], data["role"], emp_id, data["active"] == "Oui")
            self.service.history.record("utilisateur", 0, None, "créé", "Création utilisateur", self.user["id"], data["email"])
            self.show_users()
        except Exception as exc:
            self._error(exc)

    def edit_user(self) -> None:
        user_id = self._selected_required()
        if not user_id:
            return
        row = self.db.query_one("""
            SELECT u.*, r.nom AS role_nom
            FROM utilisateur u JOIN role r ON r.id=u.role_id
            WHERE u.id=?
        """, (user_id,))
        if not row:
            self._error("Utilisateur introuvable.")
            return
        employee_values, employee_map = self._employee_choice_values(row["employe_id"], allow_none=True)
        current_choice = "Aucun employé associé"
        if row["employe_id"]:
            for label, emp_id in employee_map.items():
                if emp_id == row["employe_id"]:
                    current_choice = label
                    break
        data = self._choice_form("Modifier utilisateur", [
            ("email", "Email", row["email"] or ""),
            ("password", "Nouveau mot de passe (laisser vide pour conserver)", ""),
        ], [
            ("role", "Rôle", list(ROLES), row["role_nom"]),
            ("employee_choice", "Employé associé", employee_values, current_choice),
            ("active", "Actif", ["Oui", "Non"], "Oui" if row["actif"] else "Non"),
        ])
        if not data:
            return
        try:
            emp_id = employee_map.get(data["employee_choice"])
            self.service.update_user(user_id, data["email"], data["role"], emp_id, data["active"] == "Oui", data["password"])
            self.service.history.record("utilisateur", user_id, None, None, "Modification utilisateur", self.user["id"], data["email"])
            self.show_users()
        except Exception as exc:
            self._error(exc)

    def delete_user(self) -> None:
        user_id = self._selected_required()
        if not user_id:
            return
        if not messagebox.askyesno("Confirmation", "Supprimer définitivement cet utilisateur ?"):
            return
        try:
            self.service.delete_user(user_id, self.user["id"])
            self.service.history.record("utilisateur", user_id, None, "supprimé", "Suppression utilisateur", self.user["id"], "")
            self.show_users()
        except Exception as exc:
            self._error(exc)

    def toggle_user(self) -> None:
        user_id = self._selected_required()
        if not user_id:
            return
        row = self.db.query_one("SELECT actif FROM utilisateur WHERE id=?", (user_id,))
        new_val = 0 if row["actif"] else 1
        self.db.execute("UPDATE utilisateur SET actif=? WHERE id=?", (new_val, user_id))
        self.service.history.record("utilisateur", user_id, str(row["actif"]), str(new_val), "Activation/Désactivation utilisateur", self.user["id"], "")
        self.show_users()

    # ---------- historique ----------
    def show_history(self) -> None:
        body = self._clear("Historique", "Actions importantes et changements de statut")
        bar = self._make_button_bar(body)
        ctk.CTkLabel(bar, text="Filtre :").pack(side="left", padx=(4, 4))
        filter_entry = ctk.CTkEntry(bar, width=220, placeholder_text="action, statut, commentaire...")
        filter_entry.pack(side="left", padx=4)
        self._button(bar, "Rechercher", lambda: self._load_history(table, filter_entry.get()))
        self._button(bar, "Exporter CSV", lambda: self._export_current("historique.csv"))
        table = CardListFrame(body, [
            ("id", "ID", 50), ("date", "Date", 150), ("user", "Utilisateur", 180), ("objet", "Objet", 120),
            ("action", "Action", 190), ("old", "Ancien statut", 120), ("new", "Nouveau statut", 120), ("comment", "Commentaire", 260)
        ])
        table.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.current_table = table
        self._load_history(table, "")

    def _load_history(self, table: CardListFrame, filter_text: str) -> None:
        params: tuple[Any, ...] = ()
        where = ""
        if filter_text.strip():
            like = f"%{filter_text.strip()}%"
            where = "WHERE h.action LIKE ? OR h.commentaire LIKE ? OR h.nouveau_statut LIKE ? OR h.ancien_statut LIKE ?"
            params = (like, like, like, like)
        rows = self.db.query(f"""
            SELECT h.id, h.date_action, COALESCE(u.email,''), h.entity_type || ' #' || h.entity_id,
                   h.action, COALESCE(h.ancien_statut,''), COALESCE(h.nouveau_statut,''), COALESCE(h.commentaire,'')
            FROM historique_demande h
            LEFT JOIN utilisateur u ON u.id=h.utilisateur_id
            {where}
            ORDER BY h.id DESC
        """, params)
        table.set_rows([tuple(r) for r in rows])


def run_app() -> None:
    app = LoginWindow()
    app.mainloop()
