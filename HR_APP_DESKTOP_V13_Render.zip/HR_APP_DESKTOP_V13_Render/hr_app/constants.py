ROLE_EMPLOYE = "Employé"
ROLE_MANAGER = "Manager"
ROLE_RH = "Responsable RH"

ROLES = [ROLE_EMPLOYE, ROLE_MANAGER, ROLE_RH]

DEMANDE_TYPES = {
    "CONGE": "Congé",
    "DOCUMENT": "Document RH",
    "MATERIEL": "Matériel",
}

STATUT_CONGE = ["brouillon", "soumise", "en traitement", "approuvée", "refusée", "annulée"]

# Workflow corrigé V3 : la validation manager est préalable, la validation finale est RH.
STATUT_NOTE = ["brouillon", "soumise", "en vérification", "prévalidée manager", "validée RH", "rejetée", "remboursée"]

STATUT_DOCUMENT = ["créée", "soumise", "traitée", "prête", "rejetée", "récupérée"]

# Workflow V3 : le manager crée une demande d'attribution ; seul le RH accepte/refuse et affecte.
STATUT_MATERIEL_DEMANDE = ["créée", "soumise", "en traitement", "acceptée RH", "refusée RH", "affectée", "annulée"]

ETAT_PHYSIQUE_MATERIEL = ["en marche", "endommagé", "en maintenance"]
STATUT_MATERIEL = ["disponible", "affecté", "retourné", "en maintenance"]

# Types de congés adaptés au contexte marocain.
TYPES_CONGE_MAROC = [
    "Congé annuel",
    "Congé exceptionnel / permission d’absence",
    "Congé maladie courte durée",
    "Congé maladie moyenne durée",
    "Congé maladie longue durée",
    "Congé accident du travail",
    "Congé de maternité",
    "Congé sans solde",
]

TYPES_DOCUMENT_RH = [
    "Copie contrat de travail",
    "Bulletins de paie",
    "Attestation de travail",
    "Attestation de salaire",
    "Relevé de déclaration de salaire CNSS",
]

DOCUMENTS_UPLOAD_AUTORISES = ["Bulletins de paie"]

PERMISSIONS = [
    "consulter_tableau_bord",
    "modifier_infos_personnelles",
    "demander_conge",
    "traiter_conge",
    "demander_document",
    "traiter_document",
    "soumettre_note_frais",
    "prevalider_note_frais",
    "valider_note_frais_rh",
    "demander_attribution_materiel",
    "affecter_materiel",
    "gerer_employes",
    "gerer_utilisateurs",
    "consulter_historique",
]

ROLE_PERMISSIONS = {
    ROLE_EMPLOYE: [
        "consulter_tableau_bord",
        "modifier_infos_personnelles",
        "demander_conge",
        "demander_document",
        "soumettre_note_frais",
    ],
    # Le manager hérite des actions employé + validation préalable + demande d'attribution matériel.
    ROLE_MANAGER: [
        "consulter_tableau_bord",
        "modifier_infos_personnelles",
        "demander_conge",
        "traiter_conge",
        "demander_document",
        "soumettre_note_frais",
        "prevalider_note_frais",
        "demander_attribution_materiel",
        "consulter_historique",
    ],
    ROLE_RH: PERMISSIONS,
}
