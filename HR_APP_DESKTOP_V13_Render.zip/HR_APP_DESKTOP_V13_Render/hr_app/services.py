from __future__ import annotations

import csv
import sqlite3 as external_sqlite
import unicodedata
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from .constants import ROLE_EMPLOYE, ROLE_MANAGER, ROLE_RH, TYPES_CONGE_MAROC, TYPES_DOCUMENT_RH
from .config import STORAGE_DIR
from .db import Database, sync_leave_balances
from .security import hash_password, verify_password
from .utils import business_days_inclusive, now_str, parse_date, safe_filename, today_str


MAX_EXPENSE_AMOUNT = 10000.0
MAX_ATTACHMENT_SIZE_BYTES = 5 * 1024 * 1024
ALLOWED_ATTACHMENT_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg"}


COMPANY_LEGAL_LINES = [
    "Adresse : N° 1a 26b Porte Marrakech Massira - Marrakech-Médina (AR)",
    "RC : 155229 (Tribunal de Marrakech)",
    "ICE : 003501842000046",
    "Forme juridique : SARL",
    "Capital : 100 000 DHS",
    "contact@hy-way.org",
    "+212 6 66 88 79 56",
]


HEADER_ALIASES = {
    "matricule": {"matricule", "numero_matricule", "num_matricule", "code", "code_employe", "id_employe", "employee_id"},
    "nom": {"nom", "last_name", "lastname", "name"},
    "prenom": {"prenom", "first_name", "firstname"},
    "email": {"email", "email_professionnel", "email_pro", "mail", "adresse_email"},
    "telephone": {"telephone", "tel", "phone", "gsm", "mobile"},
    "adresse": {"adresse", "address"},
    "departement": {"departement", "service", "direction", "department", "departement_nom"},
    "poste": {"poste", "fonction", "intitule", "intitule_poste", "job", "position"},
    "date_embauche": {"date_embauche", "date_d_embauche", "embauche", "hiring_date", "date_recrutement"},
    "statut": {"statut", "status", "etat"},
    "manager_matricule": {"manager_matricule", "matricule_manager", "responsable_matricule", "superieur_matricule"},
    "manager_email": {"manager_email", "email_manager", "responsable_email", "superieur_email"},
}


def _normalize_header(value: object) -> str:
    """Normalise les noms de colonnes pour rendre l'import tolérant."""
    text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii")
    text = text.strip().lower()
    for old, new in [("'", ""), ("’", ""), (".", "_"), ("-", "_"), ("/", "_"), (" ", "_")]:
        text = text.replace(old, new)
    while "__" in text:
        text = text.replace("__", "_")
    return text.strip("_")


def _canonical_header(value: object) -> str:
    normalized = _normalize_header(value)
    for canonical, aliases in HEADER_ALIASES.items():
        if normalized in aliases:
            return canonical
    return normalized


def _clean(value: object, default: str = "") -> str:
    if value is None:
        return default
    text = str(value).strip()
    if text.lower() in {"none", "null", "nan"}:
        return default
    return text


class AuthService:
    def __init__(self, db: Database):
        self.db = db

    def authenticate(self, email: str, password: str) -> dict[str, Any] | None:
        row = self.db.query_one(
            """
            SELECT u.*, r.nom AS role_nom, e.nom AS employe_nom, e.prenom AS employe_prenom,
                   e.matricule, e.manager_id
            FROM utilisateur u
            JOIN role r ON r.id = u.role_id
            LEFT JOIN employe e ON e.id = u.employe_id
            WHERE lower(u.email) = lower(?)
            """,
            (email.strip(),),
        )
        if not row or not row["actif"]:
            return None
        if not verify_password(password.strip(), row["password_hash"]):
            return None
        self.db.execute("UPDATE utilisateur SET derniere_connexion=? WHERE id=?", (now_str(), row["id"]))
        return dict(row)

    def change_password(self, user_id: int, old_password: str, new_password: str) -> None:
        old_password = (old_password or "").strip()
        new_password = (new_password or "").strip()
        if len(new_password) < 8:
            raise ValueError("Le nouveau mot de passe doit contenir au moins 8 caractères.")
        if new_password == old_password:
            raise ValueError("Le nouveau mot de passe doit être différent de l'ancien.")
        row = self.db.query_one("SELECT password_hash FROM utilisateur WHERE id=? AND actif=1", (user_id,))
        if not row or not verify_password(old_password, row["password_hash"]):
            raise ValueError("Ancien mot de passe incorrect.")
        self.db.execute("UPDATE utilisateur SET password_hash=? WHERE id=?", (hash_password(new_password), user_id))


class HistoryService:
    def __init__(self, db: Database):
        self.db = db

    def record(self, entity_type: str, entity_id: int, old_status: str | None, new_status: str | None,
               action: str, user_id: int | None, comment: str = "") -> None:
        self.db.execute(
            """
            INSERT INTO historique_demande(entity_type, entity_id, ancien_statut, nouveau_statut, action, commentaire, utilisateur_id, date_action)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (entity_type, entity_id, old_status, new_status, action, comment, user_id, now_str()),
        )


class HRService:
    def __init__(self, db: Database):
        self.db = db
        self.history = HistoryService(db)

    def has_role(self, user: dict[str, Any], *roles: str) -> bool:
        return user.get("role_nom") in roles

    def _validate_attachment(self, file_path: str | None, required: bool = False) -> str:
        if not file_path:
            if required:
                raise ValueError("Le justificatif est obligatoire.")
            return ""
        path = Path(file_path)
        if not path.exists() or not path.is_file():
            raise ValueError("Le fichier justificatif est introuvable. Veuillez choisir un fichier valide.")
        if path.suffix.lower() not in ALLOWED_ATTACHMENT_EXTENSIONS:
            allowed = ", ".join(sorted(ALLOWED_ATTACHMENT_EXTENSIONS))
            raise ValueError(f"Type de fichier non autorisé. Formats acceptés : {allowed}.")
        if path.stat().st_size > MAX_ATTACHMENT_SIZE_BYTES:
            raise ValueError("Le fichier justificatif dépasse la taille maximale autorisée de 5 Mo.")
        return str(path)

    def employee_scope_clause(self, user: dict[str, Any], alias: str = "d") -> tuple[str, tuple[Any, ...]]:
        """Return SQL filter so an employee sees only his/her own data."""
        if user["role_nom"] == ROLE_EMPLOYE:
            return f" WHERE {alias}.employe_id=? ", (user["employe_id"],)
        return "", ()

    def sync_leave_balances(self) -> None:
        """Actualise les soldes selon les règles de congés de l'application."""
        sync_leave_balances(self.db)

    def get_leave_balance(self, employe_id: int) -> dict[str, float]:
        self.sync_leave_balances()
        row = self.db.query_one(
            "SELECT jours_acquis, jours_pris, jours_restants FROM solde_conge WHERE employe_id=? ORDER BY annee DESC LIMIT 1",
            (employe_id,),
        )
        if not row:
            return {"jours_acquis": 0.0, "jours_pris": 0.0, "jours_restants": 0.0}
        return {
            "jours_acquis": float(row["jours_acquis"] or 0),
            "jours_pris": float(row["jours_pris"] or 0),
            "jours_restants": float(row["jours_restants"] or 0),
        }

    # ---------- Congés ----------
    def create_leave_request(
        self,
        user: dict[str, Any],
        date_debut: str,
        date_fin: str,
        type_conge: str,
        motif: str,
        justificatif_path: str | None = None,
        demi_journee: bool = False,
    ) -> int:
        if type_conge not in TYPES_CONGE_MAROC:
            raise ValueError("Type de congé invalide. Choisissez un type de congé de la liste.")
        justificatif_path = self._validate_attachment(justificatif_path, required=False)
        if demi_journee:
            if date_fin != date_debut:
                raise ValueError("Pour une demi-journée, la date de début et la date de fin doivent être identiques.")
            # Valide le format de date et interdit les week-ends via le calcul existant.
            business_days_inclusive(date_debut, date_fin)
            days = 0.5
        else:
            days = float(business_days_inclusive(date_debut, date_fin))
        if days <= 0:
            raise ValueError("Les dates de congé sont invalides.")
        self._ensure_leave_conflicts_ok(user["employe_id"], date_debut, date_fin, days)
        cursor = self.db.execute(
            """
            INSERT INTO demande(employe_id, demandeur_id, type_demande, statut, motif, date_creation, date_soumission)
            VALUES (?, ?, 'CONGE', 'soumise', ?, ?, ?)
            """,
            (user["employe_id"], user["id"], motif, now_str(), now_str()),
        )
        demande_id = cursor.lastrowid
        self.db.execute(
            """
            INSERT INTO demande_conge(demande_id, date_debut, date_fin, nombre_jours, type_conge, justificatif_conge)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (demande_id, date_debut, date_fin, days, type_conge, justificatif_path or ""),
        )
        self.history.record("demande", demande_id, None, "soumise", "Soumission demande congé", user["id"], type_conge)
        emp = self.db.query_one("SELECT prenom, nom, manager_id FROM employe WHERE id=?", (user["employe_id"],))
        if emp and emp["manager_id"]:
            self.create_alert_for_employee(emp["manager_id"], "Nouvelle demande de congé", f"{emp['prenom']} {emp['nom']} a soumis une demande de congé.", "congé", "Congés")
        self.create_alert_for_role(ROLE_RH, "Nouvelle demande de congé", f"Une demande de congé est en attente de suivi RH.", "congé", "Congés")
        return demande_id

    def update_leave_status(self, demande_id: int, new_status: str, user: dict[str, Any], comment: str = "") -> None:
        demande = self.db.query_one("SELECT * FROM demande WHERE id=? AND type_demande='CONGE'", (demande_id,))
        if not demande:
            raise ValueError("Demande de congé introuvable.")
        old = demande["statut"]

        if new_status not in ("soumise", "en traitement", "approuvée", "refusée", "annulée"):
            raise ValueError("Statut de congé invalide.")
        if user["role_nom"] == ROLE_EMPLOYE:
            raise ValueError("Un employé ne peut pas traiter une demande de congé.")
        if user["role_nom"] == ROLE_MANAGER:
            if demande["employe_id"] == user["employe_id"]:
                raise ValueError("Un manager ne peut pas traiter sa propre demande de congé. Elle doit être traitée par le Responsable RH.")
            target = self.db.query_one("SELECT manager_id FROM employe WHERE id=?", (demande["employe_id"],))
            if target and target["manager_id"] not in (None, user["employe_id"]):
                raise ValueError("Le manager peut traiter uniquement les congés de son équipe.")
            if new_status not in ("en traitement", "approuvée", "refusée"):
                raise ValueError("Le manager peut uniquement traiter, approuver ou refuser une demande de congé.")
        elif user["role_nom"] != ROLE_RH:
            raise ValueError("Rôle non autorisé pour traiter les congés.")
        if new_status == "approuvée":
            self._validate_leave_before_approval(demande_id, user, comment)

        self.db.execute(
            "UPDATE demande SET statut=?, date_traitement=?, traite_par=?, commentaire_traitement=? WHERE id=?",
            (new_status, now_str(), user["id"], comment, demande_id),
        )
        # Recalcule automatiquement les droits acquis et le nombre de jours pris.
        # Cela supporte les demi-journées et évite les doubles déductions si un statut change.
        self.sync_leave_balances()
        self.recompute_leave_quota_usage()
        self.history.record("demande", demande_id, old, new_status, "Changement statut congé", user["id"], comment)
        self.create_alert_for_employee(demande["employe_id"], "Statut congé mis à jour", f"Votre demande de congé #{demande_id} est maintenant : {new_status}.", "congé", "Congés")

    # ---------- Notes de frais ----------
    def create_expense(self, user: dict[str, Any], objet: str, description: str, montant: float,
                       justificatif_path: str | None = None) -> int:
        objet = (objet or "").strip()
        if not objet:
            raise ValueError("L'objet de la note de frais est obligatoire.")
        try:
            montant = float(montant)
        except (TypeError, ValueError):
            raise ValueError("Le montant de la note de frais est invalide.")
        if montant <= 0:
            raise ValueError("Le montant doit être supérieur à 0 DH.")
        if montant > MAX_EXPENSE_AMOUNT:
            raise ValueError(f"Le montant dépasse le plafond autorisé de {MAX_EXPENSE_AMOUNT:,.0f} DH.")
        justificatif_path = self._validate_attachment(justificatif_path, required=True)
        p = Path(justificatif_path)

        cursor = self.db.execute(
            "INSERT INTO note_de_frais(employe_id, objet, description, montant, statut, date_soumission) VALUES (?, ?, ?, ?, 'soumise', ?)",
            (user["employe_id"], objet, description, montant, now_str()),
        )
        note_id = cursor.lastrowid
        self.history.record("note_de_frais", note_id, None, "soumise", "Soumission note de frais", user["id"], objet)
        emp = self.db.query_one("SELECT prenom, nom, manager_id FROM employe WHERE id=?", (user["employe_id"],))
        if emp and emp["manager_id"]:
            self.create_alert_for_employee(emp["manager_id"], "Note de frais à prévalider", f"{emp['prenom']} {emp['nom']} a soumis une note de frais.", "note de frais", "Notes de frais")
        self.db.execute(
            "INSERT INTO justificatif(note_id, nom_fichier, type_fichier, chemin_fichier, date_ajout) VALUES (?, ?, ?, ?, ?)",
            (note_id, p.name, p.suffix.lower(), str(p), now_str()),
        )
        return note_id

    def update_expense_status(self, note_id: int, new_status: str, user: dict[str, Any], comment: str = "") -> None:
        note = self.db.query_one("SELECT * FROM note_de_frais WHERE id=?", (note_id,))
        if not note:
            raise ValueError("Note de frais introuvable.")
        old = note["statut"]
        if old == new_status:
            return

        role = user["role_nom"]

        if role == ROLE_MANAGER:
            if note["employe_id"] == user["employe_id"]:
                raise ValueError("Un manager ne peut pas prévalider ou rejeter sa propre note de frais. Elle doit être traitée par le Responsable RH.")
            if new_status not in ("en vérification", "prévalidée manager", "rejetée"):
                raise ValueError("Le manager peut uniquement vérifier, prévalider ou rejeter une note de frais.")
            if new_status == "prévalidée manager" and old not in ("soumise", "en vérification"):
                raise ValueError("Seules les notes soumises ou en vérification peuvent être prévalidées par le manager.")

        if role == ROLE_RH:
            if new_status == "validée RH" and old != "prévalidée manager":
                raise ValueError("La validation finale RH exige d'abord une prévalidation du manager.")
            if new_status == "remboursée" and old != "validée RH":
                raise ValueError("Une note doit être validée par le RH avant d'être remboursée.")
            if new_status == "prévalidée manager":
                raise ValueError("La prévalidation est réservée au manager.")

        if role == ROLE_EMPLOYE:
            raise ValueError("Un employé ne peut pas modifier le statut d'une note de frais.")

        date_remb = now_str() if new_status == "remboursée" else note["date_remboursement"]
        self.db.execute(
            "UPDATE note_de_frais SET statut=?, date_traitement=?, date_remboursement=?, traite_par=?, commentaire_traitement=? WHERE id=?",
            (new_status, now_str(), date_remb, user["id"], comment, note_id),
        )
        action = "Prévalidation manager note de frais" if new_status == "prévalidée manager" else "Changement statut note de frais"
        self.history.record("note_de_frais", note_id, old, new_status, action, user["id"], comment)
        self.create_alert_for_employee(note["employe_id"], "Statut note de frais mis à jour", f"Votre note de frais #{note_id} est maintenant : {new_status}.", "note de frais", "Notes de frais")
        if new_status == "prévalidée manager":
            self.create_alert_for_role(ROLE_RH, "Note de frais à valider", f"La note de frais #{note_id} a été prévalidée par le manager.", "note de frais", "Notes de frais")

    # ---------- Documents RH ----------
    def create_document_request(self, user: dict[str, Any], type_document: str, motif: str) -> int:
        if type_document not in TYPES_DOCUMENT_RH:
            raise ValueError("Type de document invalide. Choisissez un document de la liste.")
        cursor = self.db.execute(
            """
            INSERT INTO demande(employe_id, demandeur_id, type_demande, statut, motif, date_creation, date_soumission)
            VALUES (?, ?, 'DOCUMENT', 'soumise', ?, ?, ?)
            """,
            (user["employe_id"], user["id"], motif, now_str(), now_str()),
        )
        demande_id = cursor.lastrowid
        self.db.execute(
            "INSERT INTO demande_document(demande_id, type_document) VALUES (?, ?)",
            (demande_id, type_document),
        )
        self.history.record("demande", demande_id, None, "soumise", "Soumission demande document", user["id"], type_document)
        self.create_alert_for_role(ROLE_RH, "Document RH demandé", f"Une demande de document RH est en attente : {type_document}.", "document", "Documents RH")
        return demande_id

    def update_document_status(self, demande_id: int, new_status: str, user: dict[str, Any],
                               comment: str = "", fichier: str | None = None) -> None:
        demande = self.db.query_one("SELECT * FROM demande WHERE id=? AND type_demande='DOCUMENT'", (demande_id,))
        if not demande:
            raise ValueError("Demande document introuvable.")

        allowed_statuses = {"soumise", "traitée", "prête", "rejetée", "récupérée"}
        if new_status not in allowed_statuses:
            raise ValueError("Statut document invalide.")

        role = user.get("role_nom")
        if role not in (ROLE_RH, ROLE_EMPLOYE, ROLE_MANAGER):
            raise ValueError("Rôle non autorisé.")

        # Sécurité côté service : l'interface ne suffit pas. Un employé/manager
        # ne peut marquer récupéré que SES PROPRES documents, jamais ceux d'un autre employé.
        if role in (ROLE_EMPLOYE, ROLE_MANAGER):
            if new_status != "récupérée":
                raise ValueError("Seul le RH peut traiter, préparer ou rejeter une demande de document.")
            if demande["employe_id"] != user.get("employe_id"):
                raise ValueError("Vous ne pouvez modifier que vos propres documents RH.")
            if demande["statut"] != "prête":
                raise ValueError("Le document doit être marqué prêt par le RH avant d'être récupéré.")

        # Si un fichier est fourni, il doit passer par le même contrôle que les justificatifs.
        if fichier:
            fichier = self._validate_attachment(fichier, required=True)

        old = demande["statut"]
        self.db.execute(
            "UPDATE demande SET statut=?, date_traitement=?, traite_par=?, commentaire_traitement=? WHERE id=?",
            (new_status, now_str(), user["id"], comment, demande_id),
        )
        if fichier:
            self.db.execute("UPDATE demande_document SET fichier_document=? WHERE demande_id=?", (fichier, demande_id))
        if new_status == "récupérée":
            self.db.execute("UPDATE demande_document SET document_recupere=1 WHERE demande_id=?", (demande_id,))
        elif new_status in ("soumise", "traitée", "prête", "rejetée"):
            self.db.execute("UPDATE demande_document SET document_recupere=0 WHERE demande_id=?", (demande_id,))
        self.history.record("demande", demande_id, old, new_status, "Changement statut document", user["id"], comment)
        self.create_alert_for_employee(demande["employe_id"], "Statut document RH mis à jour", f"Votre demande document #{demande_id} est maintenant : {new_status}.", "document", "Documents RH")

    # ---------- Matériel ----------
    def create_material_request(
        self,
        user: dict[str, Any],
        type_materiel: str,
        description: str,
        date_besoin: str,
        employe_id: int | None = None,
    ) -> int:
        # Employé : non autorisé. Manager : demande d'attribution. RH : peut créer aussi une demande si besoin.
        if user["role_nom"] == ROLE_EMPLOYE:
            raise ValueError("Le compte employé n'a pas accès aux demandes de matériel.")
        target_employee_id = employe_id or user["employe_id"]
        if user["role_nom"] == ROLE_MANAGER:
            target = self.db.query_one("SELECT id, manager_id FROM employe WHERE id=?", (target_employee_id,))
            if not target:
                raise ValueError("Employé cible introuvable.")
            if target_employee_id == user["employe_id"]:
                raise ValueError("La demande d'attribution doit viser un employé de votre équipe.")
            # Par sécurité, on limite le manager à son équipe directe si les managers sont renseignés.
            if target["manager_id"] is not None and target["manager_id"] != user["employe_id"]:
                raise ValueError("Le manager peut demander du matériel uniquement pour les employés de son équipe.")
        cursor = self.db.execute(
            """
            INSERT INTO demande(employe_id, demandeur_id, type_demande, statut, motif, date_creation, date_soumission)
            VALUES (?, ?, 'MATERIEL', 'soumise', ?, ?, ?)
            """,
            (target_employee_id, user["id"], description, now_str(), now_str()),
        )
        demande_id = cursor.lastrowid
        self.db.execute(
            "INSERT INTO demande_materiel(demande_id, type_materiel, description_besoin, date_besoin) VALUES (?, ?, ?, ?)",
            (demande_id, type_materiel, description, date_besoin),
        )
        self.history.record("demande", demande_id, None, "soumise", "Demande d'attribution matériel", user["id"], type_materiel)
        return demande_id

    def update_material_request_status(self, demande_id: int, new_status: str, user: dict[str, Any], comment: str = "") -> None:
        demande = self.db.query_one("SELECT * FROM demande WHERE id=? AND type_demande='MATERIEL'", (demande_id,))
        if not demande:
            raise ValueError("Demande matériel introuvable.")
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut traiter, accepter ou refuser une demande d'attribution matériel.")
        old = demande["statut"]
        self.db.execute(
            "UPDATE demande SET statut=?, date_traitement=?, traite_par=?, commentaire_traitement=? WHERE id=?",
            (new_status, now_str(), user["id"], comment, demande_id),
        )
        self.history.record("demande", demande_id, old, new_status, "Changement statut matériel", user["id"], comment)

    def assign_material(self, demande_id: int, materiel_id: int, user: dict[str, Any], comment: str = "") -> str:
        """Affecte un matériel et génère automatiquement le bon d'attribution PDF."""
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut affecter le matériel.")
        demande = self.db.query_one("SELECT * FROM demande WHERE id=? AND type_demande='MATERIEL'", (demande_id,))
        if not demande:
            raise ValueError("Demande matériel introuvable.")
        if demande["statut"] not in ("acceptée RH", "en traitement", "soumise"):
            raise ValueError("La demande doit être soumise, en traitement ou acceptée RH avant affectation.")
        materiel = self.db.query_one("SELECT * FROM materiel WHERE id=?", (materiel_id,))
        if not materiel or materiel["statut_materiel"] != "disponible":
            raise ValueError("Le matériel sélectionné n'est pas disponible.")

        cursor = self.db.execute(
            """
            INSERT INTO affectation_materiel(
                materiel_id, employe_id, demande_id, date_affectation, statut_affectation,
                confirmation_reception, date_confirmation, bon_pdf_path, bon_signe_path
            )
            VALUES (?, ?, ?, ?, 'active', 0, NULL, '', '')
            """,
            (materiel_id, demande["employe_id"], demande_id, now_str()),
        )
        affectation_id = cursor.lastrowid
        pdf_path = self.generate_material_assignment_pdf(affectation_id)
        self.db.execute("UPDATE affectation_materiel SET bon_pdf_path=? WHERE id=?", (pdf_path, affectation_id))

        self.db.execute("UPDATE materiel SET statut_materiel='affecté' WHERE id=?", (materiel_id,))
        self.db.execute("UPDATE demande_materiel SET materiel_id=? WHERE demande_id=?", (materiel_id, demande_id))
        old = demande["statut"]
        self.db.execute(
            "UPDATE demande SET statut='affectée', date_traitement=?, traite_par=?, commentaire_traitement=? WHERE id=?",
            (now_str(), user["id"], comment, demande_id),
        )
        self.history.record("demande", demande_id, old, "affectée", "Affectation matériel par RH", user["id"], comment)
        self.history.record("materiel", materiel_id, materiel["statut_materiel"], "affecté", "Matériel affecté avec bon PDF", user["id"], pdf_path)
        return pdf_path

    def generate_material_assignment_pdf(self, affectation_id: int) -> str:
        """Génère le bon d'attribution matériel avec logo et mentions juridiques H&Y Way."""
        affectation = self.db.query_one(
            """
            SELECT a.*, e.nom AS employe_nom, e.prenom AS employe_prenom, e.matricule,
                   m.designation, m.inventaire, m.categorie, d.id AS demande_id
            FROM affectation_materiel a
            JOIN employe e ON e.id=a.employe_id
            JOIN materiel m ON m.id=a.materiel_id
            LEFT JOIN demande d ON d.id=a.demande_id
            WHERE a.id=?
            """,
            (affectation_id,),
        )
        if not affectation:
            raise ValueError("Affectation matériel introuvable pour générer le bon.")

        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm
            from reportlab.pdfgen import canvas
        except ImportError as exc:  # pragma: no cover - dépendance utilisateur
            raise ValueError("La génération PDF nécessite reportlab. Lancez : pip install -r requirements.txt") from exc

        output_dir = STORAGE_DIR / "bons_attribution"
        output_dir.mkdir(parents=True, exist_ok=True)
        filename = safe_filename(
            f"bon_attribution_{affectation_id}_{affectation['matricule']}_{affectation['inventaire']}.pdf"
        )
        output_path = output_dir / filename

        c = canvas.Canvas(str(output_path), pagesize=A4)
        width, height = A4
        margin_x = 20 * mm
        y = height - 22 * mm

        logo_path = Path(__file__).resolve().parent / "assets" / "hy_way_logo.png"
        if logo_path.exists():
            try:
                c.drawImage(str(logo_path), margin_x, y - 34 * mm, width=48 * mm, height=40 * mm, preserveAspectRatio=True, mask='auto')
            except Exception:
                pass

        c.setFont("Helvetica-Bold", 18)
        c.setFillColor(colors.HexColor("#1f4e79"))
        c.drawRightString(width - margin_x, y - 5 * mm, "H&Y Way")
        c.setFont("Helvetica", 9)
        c.setFillColor(colors.black)
        c.drawRightString(width - margin_x, y - 11 * mm, "The only way to succeed")
        c.line(margin_x, y - 42 * mm, width - margin_x, y - 42 * mm)

        y -= 58 * mm
        c.setFont("Helvetica-Bold", 16)
        c.drawCentredString(width / 2, y, "BON D'ATTRIBUTION DE MATÉRIEL")
        y -= 14 * mm

        def label_value(label: str, value: str) -> None:
            nonlocal y
            c.setFont("Helvetica-Bold", 10)
            c.drawString(margin_x, y, label)
            c.setFont("Helvetica", 10)
            c.drawString(margin_x + 55 * mm, y, value or "-")
            y -= 8 * mm

        employee_name = f"{affectation['employe_prenom']} {affectation['employe_nom']}".strip()
        label_value("Nom de l'employé :", employee_name)
        label_value("Matricule :", affectation["matricule"])
        label_value("Nom du matériel attribué :", affectation["designation"])
        label_value("Numéro d'inventaire :", affectation["inventaire"])
        label_value("Date d'attribution :", affectation["date_affectation"])
        # Les champs techniques de suivi (confirmation_reception, date_confirmation,
        # bon_pdf_path, bon_signe_path) restent stockés dans l'application,
        # mais ne figurent pas sur le bon imprimable remis à l'employé.

        y -= 6 * mm
        c.setFont("Helvetica", 10)
        text = c.beginText(margin_x, y)
        text.setLeading(14)
        text.textLine("Je soussigné(e), l'employé(e) mentionné(e) ci-dessus, confirme avoir reçu le matériel indiqué")
        text.textLine("dans l'état constaté au moment de l'attribution et m'engage à en assurer une utilisation professionnelle.")
        c.drawText(text)

        y -= 34 * mm
        c.setFont("Helvetica-Bold", 10)
        c.drawString(margin_x, y, "Signature de l'employé :")
        c.rect(margin_x, y - 30 * mm, 82 * mm, 25 * mm)
        c.setFont("Helvetica", 8)
        c.drawString(margin_x, y - 34 * mm, "Date et signature précédées de la mention : Lu et approuvé")

        # Pied de page institutionnel inspiré du modèle fourni : vague légère,
        # slogan à droite et informations juridiques/contact en colonnes.
        footer_top = 70 * mm
        footer_bottom = 12 * mm
        c.saveState()
        c.setFillColor(colors.HexColor("#f5f9fc"))
        c.rect(0, 0, width, footer_top, stroke=0, fill=1)
        c.setStrokeColor(colors.HexColor("#dbeaf3"))
        c.setLineWidth(0.35)
        for offset in range(0, 18, 4):
            y_wave = footer_bottom + (18 + offset) * mm
            path = c.beginPath()
            path.moveTo(0, y_wave)
            path.curveTo(width * 0.28, y_wave + 13 * mm, width * 0.47, y_wave - 12 * mm, width * 0.72, y_wave + 5 * mm)
            path.curveTo(width * 0.86, y_wave + 15 * mm, width * 0.96, y_wave - 2 * mm, width, y_wave + 4 * mm)
            c.drawPath(path, stroke=1, fill=0)
        c.restoreState()

        c.setFont("Helvetica-Bold", 14)
        c.setFillColor(colors.HexColor("#1f4e79"))
        c.drawRightString(width - margin_x, footer_top - 16 * mm, "The only way to succeed")

        c.setFillColor(colors.HexColor("#263645"))
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(margin_x, footer_top - 18 * mm, "H&Y Way")
        c.setFont("Helvetica", 7.5)

        col1_x = margin_x
        col2_x = margin_x + 82 * mm
        col3_x = margin_x + 137 * mm
        base_y = footer_top - 27 * mm
        leading = 5 * mm

        c.drawString(col1_x, base_y, "Adresse : N° 1a 26b Porte Marrakech Massira")
        c.drawString(col1_x, base_y - leading, "Marrakech-Médina (AR)")
        c.drawString(col1_x, base_y - 2 * leading, "contact@hy-way.org")
        c.drawString(col1_x, base_y - 3 * leading, "+212 6 66 88 79 56")

        c.drawString(col2_x, base_y, "RC : 155229")
        c.drawString(col2_x, base_y - leading, "Tribunal de Marrakech")
        c.drawString(col2_x, base_y - 2 * leading, "ICE : 003501842000046")

        c.drawString(col3_x, base_y, "Forme juridique : SARL")
        c.drawString(col3_x, base_y - leading, "Capital : 100 000 DHS")

        c.setStrokeColor(colors.HexColor("#1f4e79"))
        c.setLineWidth(1)
        c.line(margin_x, footer_top - 7 * mm, width - margin_x, footer_top - 7 * mm)

        c.save()
        return str(output_path)

    def _active_material_assignment(self, materiel_id: int) -> Any:
        return self.db.query_one(
            """
            SELECT * FROM affectation_materiel
            WHERE materiel_id=? AND statut_affectation='active'
            ORDER BY id DESC LIMIT 1
            """,
            (materiel_id,),
        )

    def confirm_material_reception(self, materiel_id: int, user: dict[str, Any], signed_bon_path: str | None = None) -> None:
        """Confirme la réception du matériel et rattache éventuellement le bon signé scanné."""
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut confirmer la réception du matériel.")
        aff = self._active_material_assignment(materiel_id)
        if not aff:
            raise ValueError("Aucune affectation active trouvée pour ce matériel.")
        updates = ["confirmation_reception=1", "date_confirmation=?"]
        params: list[Any] = [now_str()]
        if signed_bon_path:
            updates.append("bon_signe_path=?")
            params.append(signed_bon_path)
        params.append(aff["id"])
        self.db.execute(f"UPDATE affectation_materiel SET {', '.join(updates)} WHERE id=?", params)
        self.history.record("materiel", materiel_id, "affecté", "réception confirmée", "Confirmation réception matériel", user["id"], signed_bon_path or "")

    def attach_signed_assignment_form(self, materiel_id: int, user: dict[str, Any], signed_bon_path: str) -> None:
        """Ajoute le bon signé scanné à l'affectation active."""
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut joindre le bon signé.")
        aff = self._active_material_assignment(materiel_id)
        if not aff:
            raise ValueError("Aucune affectation active trouvée pour ce matériel.")
        self.db.execute(
            "UPDATE affectation_materiel SET bon_signe_path=?, confirmation_reception=1, date_confirmation=COALESCE(date_confirmation, ?) WHERE id=?",
            (signed_bon_path, now_str(), aff["id"]),
        )
        self.history.record("materiel", materiel_id, "affecté", "bon signé joint", "Ajout bon d'attribution signé", user["id"], signed_bon_path)

    def return_material(self, materiel_id: int, user: dict[str, Any], etat_retour: str = "en marche", comment: str = "") -> None:
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut gérer le retour du matériel.")
        aff = self.db.query_one(
            "SELECT * FROM affectation_materiel WHERE materiel_id=? AND statut_affectation='active' ORDER BY id DESC LIMIT 1",
            (materiel_id,),
        )
        if not aff:
            raise ValueError("Aucune affectation active trouvée pour ce matériel.")
        old = self.db.query_one("SELECT statut_materiel FROM materiel WHERE id=?", (materiel_id,))["statut_materiel"]
        self.db.execute(
            "UPDATE affectation_materiel SET date_retour_effective=?, etat_retour=?, statut_affectation='retournée' WHERE id=?",
            (now_str(), etat_retour, aff["id"]),
        )
        new_status = "en maintenance" if etat_retour in ("endommagé", "en maintenance") else "disponible"
        self.db.execute("UPDATE materiel SET etat_physique=?, statut_materiel=? WHERE id=?", (etat_retour, new_status, materiel_id))
        self.history.record("materiel", materiel_id, old, new_status, "Retour matériel", user["id"], comment)

    def send_material_to_maintenance(self, materiel_id: int, user: dict[str, Any], problem: str) -> None:
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut gérer la maintenance du matériel.")
        materiel = self.db.query_one("SELECT * FROM materiel WHERE id=?", (materiel_id,))
        if not materiel:
            raise ValueError("Matériel introuvable.")
        self.db.execute(
            "INSERT INTO maintenance(materiel_id, date_demande, description_probleme, statut) VALUES (?, ?, ?, 'planifiée')",
            (materiel_id, now_str(), problem),
        )
        self.db.execute("UPDATE materiel SET etat_physique='en maintenance', statut_materiel='en maintenance' WHERE id=?", (materiel_id,))
        self.history.record("materiel", materiel_id, materiel["statut_materiel"], "en maintenance", "Déclaration maintenance", user["id"], problem)


    # ---------- Import employés ----------
    def import_employees_from_file(self, file_path: str, user: dict[str, Any]) -> dict[str, Any]:
        """Importe une liste d'employés depuis Excel, CSV ou une base SQLite externe.

        Colonnes acceptées : matricule, nom, prénom, email, téléphone, adresse,
        département, poste, date_embauche, statut, manager_matricule, manager_email.
        Les noms de colonnes sont volontairement tolérants : Email professionnel,
        département, fonction, service, etc. sont reconnus.
        """
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut importer une liste d'employés.")

        source = Path(file_path)
        if not source.exists():
            raise FileNotFoundError(file_path)

        rows = self._read_employee_rows(source)
        if not rows:
            raise ValueError("Aucune ligne d'employé trouvée dans le fichier sélectionné.")

        result: dict[str, Any] = {
            "source": source.name,
            "total_lu": len(rows),
            "crees": 0,
            "mis_a_jour": 0,
            "ignores": 0,
            "erreurs": [],
        }
        pending_managers: list[tuple[int, str, str]] = []
        current_year = int(today_str()[:4])

        for index, raw in enumerate(rows, start=2):
            row = {k: _clean(v) for k, v in raw.items()}
            matricule = row.get("matricule", "")
            nom = row.get("nom", "")
            prenom = row.get("prenom", "")
            email = row.get("email", "")

            if not matricule or not nom or not prenom or not email:
                result["ignores"] += 1
                result["erreurs"].append(
                    f"Ligne {index}: matricule, nom, prénom et email sont obligatoires."
                )
                continue
            if "@" not in email:
                result["ignores"] += 1
                result["erreurs"].append(f"Ligne {index}: email invalide ({email}).")
                continue

            departement_name = row.get("departement") or "Non renseigné"
            poste_name = row.get("poste") or "Employé"
            date_embauche = row.get("date_embauche") or today_str()
            statut = row.get("statut") or "actif"
            telephone = row.get("telephone", "")
            adresse = row.get("adresse", "")

            try:
                departement_id = self._get_or_create_department(departement_name)
                poste_id = self._get_or_create_poste(poste_name)
                existing = self.db.query_one(
                    "SELECT id FROM employe WHERE matricule=? OR lower(email_professionnel)=lower(?)",
                    (matricule, email),
                )
                if existing:
                    emp_id = existing["id"]
                    self.db.execute(
                        """
                        UPDATE employe
                        SET matricule=?, nom=?, prenom=?, telephone=?, adresse=?, email_professionnel=?,
                            date_embauche=?, statut=?, departement_id=?, poste_id=?
                        WHERE id=?
                        """,
                        (matricule, nom, prenom, telephone, adresse, email, date_embauche, statut, departement_id, poste_id, emp_id),
                    )
                    result["mis_a_jour"] += 1
                    action = "Mise à jour employé par import"
                else:
                    cursor = self.db.execute(
                        """
                        INSERT INTO employe(matricule, nom, prenom, telephone, adresse, email_professionnel,
                                            date_embauche, statut, departement_id, poste_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (matricule, nom, prenom, telephone, adresse, email, date_embauche, statut, departement_id, poste_id),
                    )
                    emp_id = cursor.lastrowid
                    self.db.execute(
                        """
                        INSERT OR IGNORE INTO solde_conge(employe_id, annee, jours_acquis, jours_pris, jours_restants)
                        VALUES (?, ?, 18, 0, 18)
                        """,
                        (emp_id, current_year),
                    )
                    result["crees"] += 1
                    action = "Création employé par import"

                pending_managers.append((emp_id, row.get("manager_matricule", ""), row.get("manager_email", "")))
                self.history.record("employe", emp_id, None, statut, action, user["id"], source.name)
            except Exception as exc:
                result["ignores"] += 1
                result["erreurs"].append(f"Ligne {index}: {exc}")

        # Deuxième passage : rattachement manager après création/mise à jour de tous les employés.
        managers_linked = 0
        for emp_id, manager_matricule, manager_email in pending_managers:
            manager_id = None
            if manager_matricule:
                manager = self.db.query_one("SELECT id FROM employe WHERE matricule=?", (manager_matricule,))
                manager_id = manager["id"] if manager else None
            if not manager_id and manager_email:
                manager = self.db.query_one(
                    "SELECT id FROM employe WHERE lower(email_professionnel)=lower(?)",
                    (manager_email,),
                )
                manager_id = manager["id"] if manager else None
            if manager_id and manager_id != emp_id:
                self.db.execute("UPDATE employe SET manager_id=? WHERE id=?", (manager_id, emp_id))
                managers_linked += 1
        result["managers_rattaches"] = managers_linked
        self.sync_leave_balances()
        return result

    def _get_or_create_department(self, name: str) -> int:
        name = _clean(name, "Non renseigné")
        row = self.db.query_one("SELECT id FROM departement WHERE lower(nom)=lower(?)", (name,))
        if row:
            return row["id"]
        self.db.execute("INSERT INTO departement(nom, description) VALUES (?, '')", (name,))
        return self.db.query_one("SELECT id FROM departement WHERE lower(nom)=lower(?)", (name,))["id"]

    def _get_or_create_poste(self, name: str) -> int:
        name = _clean(name, "Employé")
        row = self.db.query_one("SELECT id FROM poste WHERE lower(intitule)=lower(?)", (name,))
        if row:
            return row["id"]
        self.db.execute("INSERT INTO poste(intitule, description, niveau) VALUES (?, '', '')", (name,))
        return self.db.query_one("SELECT id FROM poste WHERE lower(intitule)=lower(?)", (name,))["id"]

    def _read_employee_rows(self, path: Path) -> list[dict[str, Any]]:
        suffix = path.suffix.lower()
        if suffix in {".xlsx", ".xlsm"}:
            return self._read_employee_rows_from_excel(path)
        if suffix == ".csv":
            return self._read_employee_rows_from_csv(path)
        if suffix in {".db", ".sqlite", ".sqlite3", ".bdd"}:
            return self._read_employee_rows_from_sqlite(path)
        raise ValueError("Format non supporté. Utilisez .xlsx, .xlsm, .csv, .db, .sqlite ou .sqlite3.")

    def _read_employee_rows_from_excel(self, path: Path) -> list[dict[str, Any]]:
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise ValueError("Le module openpyxl est requis pour importer Excel. Lancez : pip install -r requirements.txt") from exc

        workbook = load_workbook(path, read_only=True, data_only=True)
        sheet = workbook.active
        rows_iter = sheet.iter_rows(values_only=True)
        header = None
        for raw_header in rows_iter:
            if raw_header and any(_clean(cell) for cell in raw_header):
                header = [_canonical_header(cell) for cell in raw_header]
                break
        if not header:
            return []
        result = []
        for values in rows_iter:
            if not values or not any(_clean(cell) for cell in values):
                continue
            result.append({header[i]: values[i] if i < len(values) else "" for i in range(len(header))})
        return result

    def _read_employee_rows_from_csv(self, path: Path) -> list[dict[str, Any]]:
        content = path.read_text(encoding="utf-8-sig", errors="replace")
        sample = content[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=";,\t,")
        except csv.Error:
            dialect = csv.excel
            dialect.delimiter = ";"
        reader = csv.reader(content.splitlines(), dialect)
        header = None
        result = []
        for row in reader:
            if not row or not any(_clean(cell) for cell in row):
                continue
            if header is None:
                header = [_canonical_header(cell) for cell in row]
                continue
            result.append({header[i]: row[i] if i < len(row) else "" for i in range(len(header))})
        return result

    def _read_employee_rows_from_sqlite(self, path: Path) -> list[dict[str, Any]]:
        conn = external_sqlite.connect(path)
        conn.row_factory = external_sqlite.Row
        try:
            tables = [r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            if "employe" in tables:
                employe_columns = {row["name"] for row in conn.execute("PRAGMA table_info(employe)").fetchall()}
                internal_required = {"matricule", "nom", "prenom", "email_professionnel"}
                if internal_required.issubset(employe_columns):
                    return self._read_employee_rows_from_internal_like_sqlite(conn, tables, employe_columns)

            best_table = None
            best_score = -1
            for table in tables:
                columns = [row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()]
                normalized = {_canonical_header(c) for c in columns}
                score = sum(1 for c in ["matricule", "nom", "prenom", "email"] if c in normalized)
                if score > best_score:
                    best_score = score
                    best_table = table
            if not best_table or best_score < 2:
                raise ValueError("Aucune table d'employés reconnaissable dans la base sélectionnée.")

            db_rows = conn.execute(f"SELECT * FROM {best_table}").fetchall()
            result = []
            for row in db_rows:
                result.append({_canonical_header(key): row[key] for key in row.keys()})
            return result
        finally:
            conn.close()

    def _read_employee_rows_from_internal_like_sqlite(self, conn: external_sqlite.Connection, tables: list[str], employe_columns: set[str]) -> list[dict[str, Any]]:
        joins = ""
        select_dept = "'' AS departement"
        select_poste = "'' AS poste"
        select_manager = "'' AS manager_matricule, '' AS manager_email"
        if "departement" in tables:
            joins += " LEFT JOIN departement d ON d.id=e.departement_id"
            select_dept = "COALESCE(d.nom, '') AS departement"
        if "poste" in tables:
            joins += " LEFT JOIN poste p ON p.id=e.poste_id"
            select_poste = "COALESCE(p.intitule, '') AS poste"
        # Un alias séparé permet de récupérer le manager si la base source suit le même modèle.
        if "manager_id" in employe_columns:
            joins += " LEFT JOIN employe m ON m.id=e.manager_id"
            select_manager = "COALESCE(m.matricule, '') AS manager_matricule, COALESCE(m.email_professionnel, '') AS manager_email"

        query = f"""
            SELECT e.matricule, e.nom, e.prenom, COALESCE(e.telephone, '') AS telephone,
                   COALESCE(e.adresse, '') AS adresse, e.email_professionnel AS email,
                   COALESCE(e.date_embauche, '') AS date_embauche, COALESCE(e.statut, 'actif') AS statut,
                   {select_dept}, {select_poste}, {select_manager}
            FROM employe e
            {joins}
        """
        rows = conn.execute(query).fetchall()
        return [{key: row[key] for key in row.keys()} for row in rows]


    # ---------- Paramètres congés, quotas et alertes ----------
    def get_leave_parameters(self) -> dict[str, str]:
        rows = self.db.query("SELECT cle, valeur FROM conge_parametre ORDER BY cle")
        return {row["cle"]: row["valeur"] for row in rows}

    def set_leave_parameters(self, values: dict[str, str], user: dict[str, Any]) -> None:
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut modifier les paramètres de congés.")
        for key, value in values.items():
            self.db.execute(
                "UPDATE conge_parametre SET valeur=?, date_modification=? WHERE cle=?",
                (str(value).strip(), now_str(), key),
            )
        self.sync_leave_balances()
        self.history.record("parametre_conge", 0, None, "modifié", "Modification paramètres congés", user["id"], ", ".join(values.keys()))

    def get_departments(self) -> list[dict[str, Any]]:
        return [dict(r) for r in self.db.query("SELECT id, nom FROM departement ORDER BY nom")]

    def next_week_ranges(self, count: int = 13) -> list[tuple[str, str]]:
        today = date.today()
        monday = today - timedelta(days=today.weekday())
        weeks = []
        for i in range(count):
            start = monday + timedelta(days=i * 7)
            end = start + timedelta(days=6)
            weeks.append((start.isoformat(), end.isoformat()))
        return weeks

    def _get_leave_param_float(self, key: str, default: float) -> float:
        params = self.get_leave_parameters()
        try:
            return float(str(params.get(key, default)).replace(",", "."))
        except (TypeError, ValueError):
            return default

    def _get_leave_param_int(self, key: str, default: int) -> int:
        return int(round(self._get_leave_param_float(key, float(default))))

    def get_weekly_quotas(self, departement_id: int, weeks: list[tuple[str, str]] | None = None) -> list[dict[str, Any]]:
        weeks = weeks or self.next_week_ranges(13)
        default_quota = self._get_leave_param_int("quota_absence_hebdo_defaut", 2)
        result = []
        for start, end in weeks:
            row = self.db.query_one(
                "SELECT * FROM quota_absence_hebdo WHERE departement_id=? AND semaine_debut=? AND population='employe'",
                (departement_id, start),
            )
            if not row:
                self.db.execute(
                    "INSERT OR IGNORE INTO quota_absence_hebdo(departement_id, semaine_debut, semaine_fin, quota_max, quota_utilise, population) VALUES (?, ?, ?, ?, 0, 'employe')",
                    (departement_id, start, end, default_quota),
                )
                row = self.db.query_one(
                    "SELECT * FROM quota_absence_hebdo WHERE departement_id=? AND semaine_debut=? AND population='employe'",
                    (departement_id, start),
                )
            result.append(dict(row))
        self.recompute_leave_quota_usage(departement_id)
        return [dict(r) for r in self.db.query(
            "SELECT * FROM quota_absence_hebdo WHERE departement_id=? AND population='employe' AND semaine_debut BETWEEN ? AND ? ORDER BY semaine_debut",
            (departement_id, weeks[0][0], weeks[-1][0]),
        )]

    def set_weekly_quotas(self, departement_id: int, quota_by_week: dict[str, int], user: dict[str, Any]) -> None:
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut paramétrer les quotas de congés.")
        for start, quota in quota_by_week.items():
            start_date = parse_date(start)
            end = (start_date + timedelta(days=6)).isoformat()
            self.db.execute(
                """INSERT INTO quota_absence_hebdo(departement_id, semaine_debut, semaine_fin, quota_max, quota_utilise, population)
                   VALUES (?, ?, ?, ?, 0, 'employe')
                   ON CONFLICT(departement_id, semaine_debut, population) DO UPDATE SET quota_max=excluded.quota_max, semaine_fin=excluded.semaine_fin""",
                (departement_id, start, end, int(quota)),
            )
        self.recompute_leave_quota_usage(departement_id)
        self.history.record("quota_conge", departement_id, None, "modifié", "Modification quotas congés", user["id"], f"{len(quota_by_week)} semaine(s)")

    def _employee_role_name(self, employe_id: int) -> str:
        rows = self.db.query(
            """SELECT r.nom FROM utilisateur u JOIN role r ON r.id=u.role_id WHERE u.employe_id=? AND u.actif=1""",
            (employe_id,),
        )
        roles = {r["nom"] for r in rows}
        if ROLE_RH in roles:
            return ROLE_RH
        if ROLE_MANAGER in roles:
            return ROLE_MANAGER
        return ROLE_EMPLOYE

    def _week_ranges_for_dates(self, start: str, end: str) -> list[tuple[str, str]]:
        d1 = parse_date(start)
        d2 = parse_date(end)
        monday = d1 - timedelta(days=d1.weekday())
        weeks = []
        current = monday
        while current <= d2:
            weeks.append((current.isoformat(), (current + timedelta(days=6)).isoformat()))
            current += timedelta(days=7)
        return weeks

    def _approved_leave_count_for_week(self, departement_id: int, week_start: str, week_end: str, exclude_demande_id: int | None = None) -> int:
        rows = self.db.query(
            """
            SELECT d.id, d.employe_id
            FROM demande d
            JOIN demande_conge c ON c.demande_id=d.id
            JOIN employe e ON e.id=d.employe_id
            WHERE d.type_demande='CONGE'
              AND d.statut='approuvée'
              AND e.departement_id=?
              AND c.date_debut <= ?
              AND c.date_fin >= ?
            """,
            (departement_id, week_end, week_start),
        )
        count = 0
        for row in rows:
            if exclude_demande_id and row["id"] == exclude_demande_id:
                continue
            if self._employee_role_name(row["employe_id"]) == ROLE_EMPLOYE:
                count += 1
        return count

    def recompute_leave_quota_usage(self, departement_id: int | None = None) -> None:
        if departement_id:
            rows = self.db.query("SELECT * FROM quota_absence_hebdo WHERE departement_id=?", (departement_id,))
        else:
            rows = self.db.query("SELECT * FROM quota_absence_hebdo")
        for row in rows:
            used = self._approved_leave_count_for_week(row["departement_id"], row["semaine_debut"], row["semaine_fin"])
            self.db.execute("UPDATE quota_absence_hebdo SET quota_utilise=? WHERE id=?", (used, row["id"]))

    def _validate_leave_before_approval(self, demande_id: int, user: dict[str, Any], comment: str = "") -> None:
        row = self.db.query_one(
            """
            SELECT d.employe_id, e.departement_id, c.date_debut, c.date_fin, c.nombre_jours
            FROM demande d
            JOIN demande_conge c ON c.demande_id=d.id
            JOIN employe e ON e.id=d.employe_id
            WHERE d.id=? AND d.type_demande='CONGE'
            """,
            (demande_id,),
        )
        if not row:
            raise ValueError("Demande de congé introuvable.")
        self._ensure_leave_conflicts_ok(row["employe_id"], row["date_debut"], row["date_fin"], float(row["nombre_jours"]), demande_id)
        if self._employee_role_name(row["employe_id"]) != ROLE_EMPLOYE:
            return
        if not row["departement_id"]:
            return
        default_quota = self._get_leave_param_int("quota_absence_hebdo_defaut", 2)
        exceeded = []
        for start, end in self._week_ranges_for_dates(row["date_debut"], row["date_fin"]):
            quota = self.db.query_one(
                "SELECT * FROM quota_absence_hebdo WHERE departement_id=? AND semaine_debut=? AND population='employe'",
                (row["departement_id"], start),
            )
            if not quota:
                self.db.execute(
                    "INSERT INTO quota_absence_hebdo(departement_id, semaine_debut, semaine_fin, quota_max, quota_utilise, population) VALUES (?, ?, ?, ?, 0, 'employe')",
                    (row["departement_id"], start, end, default_quota),
                )
                quota = self.db.query_one(
                    "SELECT * FROM quota_absence_hebdo WHERE departement_id=? AND semaine_debut=? AND population='employe'",
                    (row["departement_id"], start),
                )
            used_after = self._approved_leave_count_for_week(row["departement_id"], start, end, demande_id) + 1
            if used_after > int(quota["quota_max"]):
                exceeded.append((start, int(quota["quota_max"]), used_after))
        if exceeded:
            details = "; ".join([f"semaine du {s}: quota {q}, après validation {u}" for s, q, u in exceeded])
            if user["role_nom"] == ROLE_RH:
                if not comment.strip():
                    raise ValueError("Le quota hebdomadaire est dépassé. Le RH peut dépasser le quota uniquement avec un motif obligatoire.")
                self.history.record("quota_conge", demande_id, None, "dérogation", "Dépassement quota congé", user["id"], f"{details} | Motif: {comment}")
            else:
                raise ValueError("Quota hebdomadaire dépassé pour le département. Seul le RH peut dépasser ce quota avec un motif.")

    def _ensure_leave_conflicts_ok(self, employe_id: int, date_debut: str, date_fin: str, nombre_jours: float, exclude_demande_id: int | None = None) -> None:
        balance = self.get_leave_balance(employe_id)
        # Si une ancienne demande approuvée est en cours de revalidation, on rajoute ses jours au solde disponible.
        if nombre_jours > float(balance["jours_restants"] or 0) + 0.0001:
            raise ValueError(f"Solde insuffisant : {balance['jours_restants']} jour(s) disponible(s) pour {nombre_jours} jour(s) demandés.")
        rows = self.db.query(
            """
            SELECT d.id
            FROM demande d
            JOIN demande_conge c ON c.demande_id=d.id
            WHERE d.employe_id=?
              AND d.type_demande='CONGE'
              AND d.statut='approuvée'
              AND c.date_debut <= ?
              AND c.date_fin >= ?
            """,
            (employe_id, date_fin, date_debut),
        )
        conflicts = [r["id"] for r in rows if not exclude_demande_id or r["id"] != exclude_demande_id]
        if conflicts:
            raise ValueError("Conflit détecté : l'employé a déjà une demande de congé approuvée sur cette période.")

    def create_alert(self, utilisateur_id: int, titre: str, message: str, type_alerte: str = "information", lien_module: str = "") -> None:
        self.db.execute(
            "INSERT INTO alerte_interne(utilisateur_id, titre, message, type_alerte, lien_module, lu, date_creation) VALUES (?, ?, ?, ?, ?, 0, ?)",
            (utilisateur_id, titre, message, type_alerte, lien_module, now_str()),
        )

    def create_alert_for_employee(self, employe_id: int, titre: str, message: str, type_alerte: str = "information", lien_module: str = "") -> None:
        users = self.db.query("SELECT id FROM utilisateur WHERE employe_id=? AND actif=1", (employe_id,))
        for u in users:
            self.create_alert(u["id"], titre, message, type_alerte, lien_module)

    def create_alert_for_role(self, role_name: str, titre: str, message: str, type_alerte: str = "information", lien_module: str = "") -> None:
        users = self.db.query("SELECT u.id FROM utilisateur u JOIN role r ON r.id=u.role_id WHERE r.nom=? AND u.actif=1", (role_name,))
        for u in users:
            self.create_alert(u["id"], titre, message, type_alerte, lien_module)

    def unread_alert_count(self, utilisateur_id: int) -> int:
        row = self.db.query_one("SELECT COUNT(*) AS total FROM alerte_interne WHERE utilisateur_id=? AND lu=0", (utilisateur_id,))
        return int(row["total"] if row else 0)

    def list_alerts(self, utilisateur_id: int) -> list[dict[str, Any]]:
        return [dict(r) for r in self.db.query(
            "SELECT id, date_creation, titre, message, type_alerte, CASE WHEN lu=1 THEN 'Lue' ELSE 'Non lue' END AS etat FROM alerte_interne WHERE utilisateur_id=? ORDER BY id DESC LIMIT 50",
            (utilisateur_id,),
        )]

    def mark_alerts_read(self, utilisateur_id: int) -> None:
        self.db.execute("UPDATE alerte_interne SET lu=1 WHERE utilisateur_id=?", (utilisateur_id,))

    def preview_employees_import(self, file_path: str, user: dict[str, Any]) -> dict[str, Any]:
        if user["role_nom"] != ROLE_RH:
            raise ValueError("Seul le Responsable RH peut importer une liste d'employés.")
        source = Path(file_path)
        rows = self._read_employee_rows(source)
        result: dict[str, Any] = {
            "source": source.name, "total_lu": len(rows), "a_creer": 0, "a_mettre_a_jour": 0,
            "ignores": 0, "erreurs": [], "departements_a_creer": set(), "postes_a_creer": set(),
            "managers_non_trouves": 0, "exemples": []
        }
        seen_matricules: set[str] = set()
        seen_emails: set[str] = set()
        for index, raw in enumerate(rows, start=2):
            row = {k: _clean(v) for k, v in raw.items()}
            matricule, nom, prenom, email = row.get("matricule", ""), row.get("nom", ""), row.get("prenom", ""), row.get("email", "")
            if not matricule or not nom or not prenom or not email:
                result["ignores"] += 1; result["erreurs"].append(f"Ligne {index}: matricule, nom, prénom et email obligatoires."); continue
            if "@" not in email:
                result["ignores"] += 1; result["erreurs"].append(f"Ligne {index}: email invalide ({email})."); continue
            if matricule.lower() in seen_matricules or email.lower() in seen_emails:
                result["erreurs"].append(f"Ligne {index}: doublon dans le fichier ({matricule} / {email}).")
            seen_matricules.add(matricule.lower()); seen_emails.add(email.lower())
            dept = row.get("departement") or "Non renseigné"
            poste = row.get("poste") or "Employé"
            if not self.db.query_one("SELECT id FROM departement WHERE lower(nom)=lower(?)", (dept,)):
                result["departements_a_creer"].add(dept)
            if not self.db.query_one("SELECT id FROM poste WHERE lower(intitule)=lower(?)", (poste,)):
                result["postes_a_creer"].add(poste)
            existing = self.db.query_one("SELECT id FROM employe WHERE matricule=? OR lower(email_professionnel)=lower(?)", (matricule, email))
            if existing:
                result["a_mettre_a_jour"] += 1
            else:
                result["a_creer"] += 1
            if row.get("manager_matricule") and not self.db.query_one("SELECT id FROM employe WHERE matricule=?", (row.get("manager_matricule"),)):
                result["managers_non_trouves"] += 1
            if len(result["exemples"]) < 8:
                result["exemples"].append(f"{matricule} - {prenom} {nom} - {email}")
        result["departements_a_creer"] = sorted(result["departements_a_creer"])
        result["postes_a_creer"] = sorted(result["postes_a_creer"])
        return result

    # ---------- Utilisateurs ----------
    def list_employees_without_user(self, include_employe_id: int | None = None) -> list[dict[str, Any]]:
        """Employés actifs qui ne possèdent pas encore de compte utilisateur."""
        params: list[Any] = []
        extra = ""
        if include_employe_id:
            extra = " OR e.id=?"
            params.append(include_employe_id)
        rows = self.db.query(
            f"""
            SELECT e.id, e.matricule, e.prenom || ' ' || e.nom AS nom, e.email_professionnel
            FROM employe e
            LEFT JOIN utilisateur u ON u.employe_id=e.id
            WHERE e.statut!='supprimé' AND (u.id IS NULL{extra})
            ORDER BY e.nom, e.prenom
            """,
            tuple(params),
        )
        return [dict(r) for r in rows]

    def _role_id(self, role_name: str) -> int:
        role = self.db.query_one("SELECT id FROM role WHERE nom=?", (role_name,))
        if not role:
            raise ValueError("Rôle invalide.")
        return int(role["id"])

    def _validate_user_payload(self, email: str, password: str | None, role_name: str, employe_id: int | None, exclude_user_id: int | None = None) -> int:
        email = (email or "").strip().lower()
        if "@" not in email or len(email) < 5:
            raise ValueError("Email utilisateur invalide.")
        if password is not None and len((password or "").strip()) < 6:
            raise ValueError("Le mot de passe doit contenir au moins 6 caractères.")
        role_id = self._role_id(role_name)
        if employe_id is not None:
            emp = self.db.query_one("SELECT id FROM employe WHERE id=? AND statut!='supprimé'", (employe_id,))
            if not emp:
                raise ValueError("Employé associé introuvable ou supprimé.")
            params: list[Any] = [employe_id]
            exclude = ""
            if exclude_user_id:
                exclude = " AND id!=?"
                params.append(exclude_user_id)
            if self.db.query_one(f"SELECT id FROM utilisateur WHERE employe_id=?{exclude}", tuple(params)):
                raise ValueError("Cet employé possède déjà un compte utilisateur.")
        params = [email]
        exclude = ""
        if exclude_user_id:
            exclude = " AND id!=?"
            params.append(exclude_user_id)
        if self.db.query_one(f"SELECT id FROM utilisateur WHERE lower(email)=lower(?){exclude}", tuple(params)):
            raise ValueError("Cet email utilisateur existe déjà.")
        return role_id

    def create_user(self, email: str, password: str, role_name: str, employe_id: int | None, active: bool = True) -> None:
        role_id = self._validate_user_payload(email, password, role_name, employe_id)
        self.db.execute(
            "INSERT INTO utilisateur(email, password_hash, actif, role_id, employe_id, date_creation) VALUES (?, ?, ?, ?, ?, ?)",
            (email.strip().lower(), hash_password(password.strip()), 1 if active else 0, role_id, employe_id, now_str()),
        )

    def update_user(self, user_id: int, email: str, role_name: str, employe_id: int | None, active: bool, password: str = "") -> None:
        existing = self.db.query_one("SELECT id FROM utilisateur WHERE id=?", (user_id,))
        if not existing:
            raise ValueError("Utilisateur introuvable.")
        role_id = self._validate_user_payload(email, password.strip() if password else None, role_name, employe_id, exclude_user_id=user_id)
        self.db.execute(
            "UPDATE utilisateur SET email=?, role_id=?, employe_id=?, actif=? WHERE id=?",
            (email.strip().lower(), role_id, employe_id, 1 if active else 0, user_id),
        )
        if password.strip():
            self.db.execute("UPDATE utilisateur SET password_hash=? WHERE id=?", (hash_password(password.strip()), user_id))

    def delete_user(self, user_id: int, current_user_id: int | None = None) -> None:
        if current_user_id and int(user_id) == int(current_user_id):
            raise ValueError("Vous ne pouvez pas supprimer votre propre compte connecté.")
        if not self.db.query_one("SELECT id FROM utilisateur WHERE id=?", (user_id,)):
            raise ValueError("Utilisateur introuvable.")
        self.db.execute("DELETE FROM utilisateur WHERE id=?", (user_id,))

    def create_or_get_department(self, name: str) -> int:
        name = (name or "Non renseigné").strip()
        row = self.db.query_one("SELECT id FROM departement WHERE lower(nom)=lower(?)", (name,))
        if not row:
            self.db.execute("INSERT INTO departement(nom, description) VALUES (?, '')", (name,))
            row = self.db.query_one("SELECT id FROM departement WHERE lower(nom)=lower(?)", (name,))
        return int(row["id"])

    def create_or_get_poste(self, title: str) -> int:
        title = (title or "Employé").strip()
        row = self.db.query_one("SELECT id FROM poste WHERE lower(intitule)=lower(?)", (title,))
        if not row:
            self.db.execute("INSERT INTO poste(intitule, description, niveau) VALUES (?, '', '')", (title,))
            row = self.db.query_one("SELECT id FROM poste WHERE lower(intitule)=lower(?)", (title,))
        return int(row["id"])

    def update_employee(self, employe_id: int, data: dict[str, str]) -> None:
        if not self.db.query_one("SELECT id FROM employe WHERE id=?", (employe_id,)):
            raise ValueError("Employé introuvable.")
        matricule = (data.get("matricule") or "").strip()
        nom = (data.get("nom") or "").strip()
        prenom = (data.get("prenom") or "").strip()
        email = (data.get("email") or "").strip().lower()
        if not matricule or not nom or not prenom or "@" not in email:
            raise ValueError("Matricule, nom, prénom et email valide sont obligatoires.")
        if self.db.query_one("SELECT id FROM employe WHERE matricule=? AND id!=?", (matricule, employe_id)):
            raise ValueError("Ce matricule existe déjà.")
        if self.db.query_one("SELECT id FROM employe WHERE lower(email_professionnel)=lower(?) AND id!=?", (email, employe_id)):
            raise ValueError("Cet email professionnel existe déjà.")
        dept_id = self.create_or_get_department(data.get("departement") or "Non renseigné")
        poste_id = self.create_or_get_poste(data.get("poste") or "Employé")
        statut = (data.get("statut") or "actif").strip() or "actif"
        self.db.execute(
            """
            UPDATE employe
            SET matricule=?, nom=?, prenom=?, telephone=?, adresse=?, email_professionnel=?,
                statut=?, departement_id=?, poste_id=?
            WHERE id=?
            """,
            (matricule, nom, prenom, data.get("telephone", ""), data.get("adresse", ""), email, statut, dept_id, poste_id, employe_id),
        )

    def delete_employee(self, employe_id: int, current_employe_id: int | None = None) -> str:
        if current_employe_id and int(employe_id) == int(current_employe_id):
            raise ValueError("Vous ne pouvez pas supprimer votre propre fiche employé connectée.")
        if not self.db.query_one("SELECT id FROM employe WHERE id=?", (employe_id,)):
            raise ValueError("Employé introuvable.")
        linked_tables = ["demande", "note_de_frais", "affectation_materiel", "solde_conge", "contrat"]
        has_links = False
        for table in linked_tables:
            row = self.db.query_one(f"SELECT COUNT(*) AS total FROM {table} WHERE employe_id=?", (employe_id,))
            if row and int(row["total"] or 0) > 0:
                has_links = True
                break
        self.db.execute("UPDATE utilisateur SET actif=0 WHERE employe_id=?", (employe_id,))
        if has_links:
            self.db.execute("UPDATE employe SET statut='supprimé' WHERE id=?", (employe_id,))
            return "La fiche contient un historique : elle a été archivée et le compte associé désactivé."
        self.db.execute("DELETE FROM employe WHERE id=?", (employe_id,))
        return "Employé supprimé définitivement."
