@echo off
REM Build Windows executable for SIRH H&Y Way
python -m pip install -r requirements.txt
pyinstaller --noconfirm --onefile --windowed --name SIRH_HY_Way --collect-submodules openpyxl --collect-all reportlab --add-data "hr_app\assets\hy_way_logo.png;hr_app\assets" main.py
pause
