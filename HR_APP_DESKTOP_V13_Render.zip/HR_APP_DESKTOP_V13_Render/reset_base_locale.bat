@echo off
if exist data\sirh_hy_way.sqlite3 (
    del data\sirh_hy_way.sqlite3
    echo Base locale supprimee. Elle sera recreee au prochain lancement.
) else (
    echo Aucune base locale a supprimer.
)
pause
