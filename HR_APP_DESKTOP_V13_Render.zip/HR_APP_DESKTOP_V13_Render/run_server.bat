@echo off
cd /d "%~dp0"
if "%HR_APP_API_TOKEN%"=="" (
  echo Definissez une cle API avant lancement, exemple :
  echo set HR_APP_API_TOKEN=mot_de_passe_long
  echo.
)
python server.py
pause
