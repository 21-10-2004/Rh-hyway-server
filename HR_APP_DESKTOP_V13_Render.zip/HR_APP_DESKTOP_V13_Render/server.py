"""Serveur HTTP léger pour l'application SIRH H&Y Way.

Aucune dépendance externe n'est nécessaire : uniquement la bibliothèque standard Python.
Ce serveur expose une API de contrôle et de consultation de la base SQLite centrale.
Pour l'utiliser comme serveur partagé, lancez ce fichier sur un PC/serveur qui restera allumé,
puis placez la base `data/sirh_hy_way.sqlite3` dans ce même dossier projet.

Sécurité : définissez une clé avant lancement :
Windows CMD : set HR_APP_API_TOKEN=mot_de_passe_long && python server.py
PowerShell   : $env:HR_APP_API_TOKEN="mot_de_passe_long"; python server.py
macOS/Linux  : HR_APP_API_TOKEN=mot_de_passe_long python3 server.py
"""
from __future__ import annotations

import json
import os
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from hr_app.config import DB_PATH, ensure_directories
from hr_app.db import initialize_database

HOST = os.environ.get("HR_APP_SERVER_HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT") or os.environ.get("HR_APP_SERVER_PORT", "8000"))
API_TOKEN = os.environ.get("HR_APP_API_TOKEN", "CHANGE_ME")

READABLE_TABLES = {
    "departement", "poste", "employe", "utilisateur", "role", "demande",
    "demande_conge", "demande_document", "note_de_frais", "materiel",
    "affectation_materiel", "maintenance", "historique_demande", "alerte_interne",
}


def _connect() -> sqlite3.Connection:
    ensure_directories()
    if not DB_PATH.exists():
        db = initialize_database()
        db.close()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


class Handler(BaseHTTPRequestHandler):
    server_version = "HRAppServer/1.0"

    def _json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        # /health reste public pour tester rapidement si le serveur répond.
        if self.path.startswith("/health"):
            return True
        token = self.headers.get("X-API-Token", "")
        return bool(API_TOKEN) and API_TOKEN != "CHANGE_ME" and token == API_TOKEN

    def do_GET(self) -> None:  # noqa: N802 - méthode attendue par BaseHTTPRequestHandler
        if not self._authorized():
            self._json({"ok": False, "error": "Accès refusé. Définissez HR_APP_API_TOKEN et envoyez X-API-Token."}, 401)
            return

        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self._json({
                "ok": True,
                "service": "SIRH H&Y Way API",
                "database_exists": DB_PATH.exists(),
                "database": str(DB_PATH),
                "token_configured": API_TOKEN != "CHANGE_ME",
                "cloud_ready": bool(os.environ.get("RENDER") or os.environ.get("PORT")),
            })
            return

        if parsed.path == "/api/tables":
            self._json({"ok": True, "tables": sorted(READABLE_TABLES)})
            return

        if parsed.path == "/api/table":
            params = parse_qs(parsed.query)
            table = (params.get("name") or [""])[0]
            limit_raw = (params.get("limit") or ["100"])[0]
            try:
                limit = max(1, min(int(limit_raw), 500))
            except ValueError:
                limit = 100
            if table not in READABLE_TABLES:
                self._json({"ok": False, "error": "Table non autorisée ou inexistante."}, 400)
                return
            with _connect() as conn:
                rows = [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY id DESC LIMIT ?", (limit,))]
            self._json({"ok": True, "table": table, "count": len(rows), "rows": rows})
            return

        if parsed.path == "/api/dashboard":
            with _connect() as conn:
                def count(sql: str) -> int:
                    row = conn.execute(sql).fetchone()
                    return int(row[0] if row else 0)
                payload = {
                    "employes": count("SELECT COUNT(*) FROM employe WHERE statut!='archivé'"),
                    "utilisateurs_actifs": count("SELECT COUNT(*) FROM utilisateur WHERE actif=1"),
                    "conges_soumis": count("SELECT COUNT(*) FROM demande WHERE type_demande='CONGE' AND statut='soumise'"),
                    "documents_soumis": count("SELECT COUNT(*) FROM demande WHERE type_demande='DOCUMENT' AND statut='soumise'"),
                    "notes_soumises": count("SELECT COUNT(*) FROM note_de_frais WHERE statut='soumise'"),
                }
            self._json({"ok": True, "dashboard": payload})
            return

        self._json({"ok": False, "error": "Endpoint introuvable."}, 404)

    def log_message(self, fmt: str, *args) -> None:
        print("[server]", self.address_string(), "-", fmt % args)


if __name__ == "__main__":
    ensure_directories()
    if not DB_PATH.exists():
        db = initialize_database()
        db.close()
    print(f"Serveur SIRH démarré sur http://{HOST}:{PORT}")
    print("Test local : http://127.0.0.1:%s/health" % PORT)
    if API_TOKEN == "CHANGE_ME":
        print("ATTENTION : définissez HR_APP_API_TOKEN avant d'utiliser les endpoints /api/.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
