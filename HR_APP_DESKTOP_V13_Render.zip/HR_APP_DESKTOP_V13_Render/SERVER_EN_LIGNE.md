# Serveur en ligne / réseau

Cette version ajoute un serveur HTTP léger sans nouvelle bibliothèque externe.

## Lancement

```bash
python server.py
```

Pour sécuriser l'API :

```bash
HR_APP_API_TOKEN=mot_de_passe_long python3 server.py
```

Sous Windows CMD :

```bat
set HR_APP_API_TOKEN=mot_de_passe_long
python server.py
```

## Vérification

Ouvrir :

```text
http://127.0.0.1:8000/health
```

Réponse attendue : `"ok": true`.

## Endpoints disponibles

- `GET /health` : test du serveur.
- `GET /api/tables` : liste des tables consultables, nécessite `X-API-Token`.
- `GET /api/dashboard` : indicateurs RH, nécessite `X-API-Token`.
- `GET /api/table?name=employe&limit=100` : lecture contrôlée d'une table, nécessite `X-API-Token`.

Exemple :

```bash
curl -H "X-API-Token: mot_de_passe_long" http://127.0.0.1:8000/api/dashboard
```

## Important

Ce serveur rend la base centrale consultable via API. Pour une synchronisation complète en temps réel entre plusieurs PC, il faut ensuite connecter les écrans desktop à cette API ou utiliser une base centralisée. Cette version évite d'ajouter FastAPI/Flask pour respecter la contrainte : aucun nouveau module.
